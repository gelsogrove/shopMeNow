# Secadora — códigos de pantalla y procedimientos

Esta información es **común a todas las sedes**. Los códigos de la secadora son **idénticos** a los de la lavadora (mismo sistema), pero hay diferencias operativas: la secadora se paga por **bloques de minutos** (15, 20 o 25 minutos según la sede), y se puede **alargar el tiempo** durante el ciclo añadiendo dinero en la central.

## Códigos de pantalla

Los mismos que la lavadora: `WAIT`, `SELECT`, `ON`, `T-28`, `STOP:`, `END:`, `120`, `OPEN:`, `OPEN ERROR`, `ALERT OPEN:`, `ERR-01`, `ALERT`/`BLOCK`.

Aplica los mismos procedimientos descritos en `washer.md`, con dos diferencias:

> ⚠️ **`OPEN ERROR` (puerta bloqueada al terminar, ropa atrapada dentro)** aplica EXACTAMENTE igual que en la lavadora: el secado ya terminó y la puerta no abre con la ropa (seca) dentro. Sigue el "Procedimiento PUERTA BLOQUEADA FIN DE CICLO" de `washer.md` — intento de apertura firme y, si no abre, ESCALAR con prioridad URGENTE. NUNCA ofrecer cambiar de máquina ni repetir el secado. Distinto de `OPEN:` (puerta que no cierra ANTES de empezar).
>
> 🚨 **Desambiguación**: si el cliente solo dice "la puerta no se abre" sin precisar, aplica la misma "Desambiguación PUERTA" de `washer.md` — pregunta PRIMERO si el secado ya terminó con la ropa dentro (sí → `OPEN ERROR`; aún no / no cierra para empezar → `OPEN:`) antes de elegir procedimiento. Una vez claro el código, guárdalo con `remember({displayCode})` y aplica el procedimiento; vuelve a pedir el código de pantalla si tras los intentos el cliente dice que sigue sin funcionar.

### Diferencia 1 — Alargar el tiempo de secado

Si el cliente pregunta cómo prolongar el secado → explícale que puede alargar el tiempo de secado hasta 5 minutos antes de que termine, añadiendo dinero en la central de pago.
Si añade dinero pero la secadora no acepta la prolongación → ESCALAR.

### Diferencia 2 — Abrir la puerta durante el ciclo

A diferencia de la lavadora, en la secadora **se puede abrir la puerta durante el ciclo** para sacar alguna pieza o comprobar el secado. Si el cliente lo pregunta → confirma que es seguro.

## Problemas específicos de la secadora

### "La secadora no calienta" (no genera calor — avería)

El cliente dice que la secadora gira y los minutos pasan, pero **no genera calor** y la ropa sigue mojada al terminar. Esto es una **avería de la resistencia**, no un problema de uso: NO hay autoservicio que lo resuelva, NO pidas que repita el secado ni que reparta mejor la carga.

**Es escalación DIRECTA** (no hagas troubleshooting): pide solo los datos de la recogida (sede → número de secadora → nombre) y escala con reason="dryer_no_heat". Briefing: *secadora N de <sede>, no calienta (resistencia), reembolsar el ciclo y revisar la máquina*.

### "La ropa ha salido empapada" (no centrifugado)

Esto no es un problema de la secadora: la **lavadora** no ha centrifugado correctamente. Procedimiento: explícale que la ropa muy mojada significa que la lavadora no centrifugó bien; recomiéndale lavarla de nuevo separando la carga en dos máquinas (la carga desequilibrada hace que el centrifugado salte por seguridad) y avísale de que hace falta un nuevo pago. Si quiere que reviséis el caso manualmente, ofrécele pasarlo a un operador.

Si el cliente quiere revisión manual → ESCALAR (briefing: lavadora N de <sede>, problema de centrifugado, cliente quiere compensación).

### "La ropa ha salido húmeda" (no muy mojada)

Probable problema de carga demasiado grande o mal repartida. Procedimiento: pídele que se asegure de que la carga no sea demasiado grande y reparta bien la ropa, e indícale que puede añadir más tiempo de secado en la central de pago.

Si tras eso sigue → ESCALAR.

### "La ropa ha salido quemada / con manchas / con plástico pegado"

Problemas relacionados con el cuidado de la prenda o el estado del tambor. Procedimiento: discúlpate sinceramente y explícale que este tipo de incidencias requieren una revisión manual y que la compensación no es automática, sino que depende de la valoración del caso; indícale que vas a registrar la incidencia para que un operador le contacte.

ESCALAR siempre.
