// Demowash chatbot — prompt-driven LLM with cached system prompt,
// session state, escalation by email.
//
// Two entry points:
//   - REPL/batch CLI (`npm run demo`) — local interactive testing
//   - `chatbotFn(input): ChatbotOutput` — contract expected by the host
//     Express backend when this module is loaded as `workspace.customChatbotId`
//
// The same core (assemble system prompt, call LLM, dispatch tools, persist
// state, drain patches) backs both entry points. See architecture.md.

import { readFile, readdir } from 'node:fs/promises'
import { readFileSync } from 'node:fs'
import path from 'node:path'
import process from 'node:process'
import { createInterface } from 'node:readline/promises'
import { fileURLToPath, pathToFileURL } from 'node:url'

import nodemailer from 'nodemailer'

import {
  type CustomerPatch,
  type SessionState,
  commitLanguageFromReply,
  drainPatches,
  extractLanguage,
  formatStateForPrompt,
  formatStateOneLine,
  getState,
  getTurnCount,
  incrementTurn,
  markEscalationOnce,
  registerMessageTimestamp,
  resetState,
  updateState,
} from './state.js'
import { processIncomingMessage, substitutePlaceholders } from './pii.js'
import {
  type CheckOrderStatusResult,
  lookupDemoOrderByNumber,
  lookupDemoOrdersByPhone,
} from './orders.js'

// ── Config ────────────────────────────────────────────────────────────────────

const __dirname = path.dirname(fileURLToPath(import.meta.url))
const PROMPTS_DIR = path.resolve(__dirname, 'prompts')
const SETTINGS_PATH = path.resolve(__dirname, 'settings.json')

interface Settings {
  model: string
  temperature: number
  maxTokens: number
  maxToolHops: number
  operatorBriefingLanguage: string
  operatorEmail: string
  emailFrom: string
  emailSubjectPrefix: string
  maxMessageChars: number
  maxMessagesPerMinute: number
  maxTurnsPerSession: number
  /** When true, the host may reply with audio if the customer sent audio.
   *  When false, the host always replies with text regardless of input. */
  audioOutput: boolean
  /** Per-language ElevenLabs voice IDs. Key = language code (it/es/en/…),
   *  plus a "default" used when the customer language has no entry. */
  audioVoices: Record<string, string>
  /** Public URL of the legal/privacy notice ("aviso legal") shown in the
   *  first-turn GDPR disclaimer. Environment-dependent: production points to
   *  https://www.echatbot.ai/aviso-legal (note: the www subdomain is required —
   *  the bare echatbot.ai host 404s), local dev to http://localhost:3000/aviso-legal.
   *  Overridable at runtime via the PRIVACY_POLICY_URL env var. */
  privacyPolicyUrl: string
}

const DEFAULT_SETTINGS: Settings = {
  model: 'anthropic/claude-haiku-4.5',
  temperature: 0.3,
  maxTokens: 800,
  maxToolHops: 4,
  operatorBriefingLanguage: 'es',
  operatorEmail: '',
  emailFrom: 'Demowash Bot <noreply@demowash.demo>',
  emailSubjectPrefix: '[Demowash] Incidencia',
  maxMessageChars: 2000,
  maxMessagesPerMinute: 30,
  maxTurnsPerSession: 50,
  audioOutput: false,
  audioVoices: {},
  privacyPolicyUrl: 'https://www.echatbot.ai/aviso-legal',
}

function loadSettings(): Settings {
  try {
    const raw = readFileSync(SETTINGS_PATH, 'utf8')
    const parsed = JSON.parse(raw) as Partial<Settings>
    return { ...DEFAULT_SETTINGS, ...parsed }
  } catch (err) {
    const code = (err as NodeJS.ErrnoException)?.code
    if (code !== 'ENOENT') {
      console.warn(`[warn] failed to load settings.json: ${err instanceof Error ? err.message : String(err)}`)
    }
    return DEFAULT_SETTINGS
  }
}

loadDotEnv(path.resolve(__dirname, '.env'))

// ── Local LLM mode (Ollama) ─────────────────────────────────────────────────
// Enable with:  npm run demo --local   (npm sets npm_config_local=true)
//          or:  npm run demo -- --local   /   node --import tsx agent.ts --local
// In local mode we point at Ollama's OpenAI-compatible endpoint and use a local
// model. Ollama ignores the bearer token, but the code paths below require a
// non-empty key, so we set a placeholder.
const LOCAL_MODE =
  process.argv.includes('--local') || process.env.npm_config_local === 'true'

if (LOCAL_MODE) {
  process.env.LLM_BASE_URL = process.env.LLM_BASE_URL || 'http://localhost:11434/v1'
  process.env.LLM_MODEL = process.env.LLM_MODEL || 'qwen3:14b'
  process.env.OPENROUTER_API_KEY = process.env.OPENROUTER_API_KEY || 'ollama'
}

const SETTINGS = loadSettings()
const BASE_URL = process.env.LLM_BASE_URL || 'https://openrouter.ai/api/v1'
const MODEL = process.env.LLM_MODEL || SETTINGS.model
const MAX_TOKENS = Number(process.env.LLM_MAX_TOKENS || SETTINGS.maxTokens)
const TEMPERATURE = Number(process.env.LLM_TEMPERATURE || SETTINGS.temperature)
const MAX_TOOL_HOPS = SETTINGS.maxToolHops
const OPERATOR_BRIEFING_LANGUAGE = SETTINGS.operatorBriefingLanguage
const OPERATOR_EMAIL = process.env.OPERATOR_EMAIL || SETTINGS.operatorEmail
const EMAIL_FROM = SETTINGS.emailFrom
const EMAIL_SUBJECT_PREFIX = SETTINGS.emailSubjectPrefix
const MAX_MESSAGE_CHARS = SETTINGS.maxMessageChars
const MAX_MESSAGES_PER_MINUTE = SETTINGS.maxMessagesPerMinute
const MAX_TURNS_PER_SESSION = SETTINGS.maxTurnsPerSession
const AUDIO_OUTPUT = SETTINGS.audioOutput
const AUDIO_VOICES = SETTINGS.audioVoices
const PRIVACY_POLICY_URL = process.env.PRIVACY_POLICY_URL || SETTINGS.privacyPolicyUrl

const API_KEY = process.env.OPENROUTER_API_KEY || ''
const GMAIL_USER = process.env.GMAIL_USER || ''
const GMAIL_APP_PASSWORD = process.env.GMAIL_APP_PASSWORD || ''

// ── Types ─────────────────────────────────────────────────────────────────────

interface ToolCall {
  id: string
  type: 'function'
  function: { name: string; arguments: string }
}

interface Message {
  role: 'system' | 'user' | 'assistant' | 'tool'
  content: string | null
  tool_calls?: ToolCall[]
  tool_call_id?: string
  name?: string
}

// ── Concurrency: per-sessionId async lock ─────────────────────────────────────
// Two messages from the same sessionId must be processed in series, never in
// parallel. Otherwise tool dispatch and SessionState writes race. The lock is
// a Map<sessionId, Promise> — each new turn chains onto the previous one.

const sessionLocks = new Map<string, Promise<unknown>>()

async function withSessionLock<T>(sessionId: string, fn: () => Promise<T>): Promise<T> {
  const previous = sessionLocks.get(sessionId) ?? Promise.resolve()
  const next = previous.catch(() => undefined).then(fn)
  sessionLocks.set(sessionId, next)
  try {
    return await next
  } finally {
    if (sessionLocks.get(sessionId) === next) sessionLocks.delete(sessionId)
  }
}

// ── Input sanitization (anti prompt-injection) ────────────────────────────────
// Strip control chars, zero-width, bidi-override. Cap length. Defends against
// prompt-stuffing and homograph/bidi injection payloads.

const CONTROL_CHARS_RE = /[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/g
const ZERO_WIDTH_RE = /[​-‍﻿]/g
const BIDI_RE = /[\u202A-\u202E\u2066-\u2069]/g

function sanitizeUserMessage(raw: string): string {
  let s = (raw ?? '').toString()
  s = s.replace(CONTROL_CHARS_RE, '')
  s = s.replace(ZERO_WIDTH_RE, '')
  s = s.replace(BIDI_RE, '')
  s = s.trim()
  if (s.length > MAX_MESSAGE_CHARS) {
    s = s.slice(0, MAX_MESSAGE_CHARS)
  }
  return s
}

// ── Tool schema ───────────────────────────────────────────────────────────────

const TOOLS = [
  {
    type: 'function',
    function: {
      name: 'remember',
      description:
        'Record facts about the customer so they are not re-asked. Call this WHENEVER the customer provides a new fact (name, location/laundromat, machine number, machine type, display code). Use merge semantics: only pass the fields that changed. Valid locations are documented in the prompt (LOCATIONS). Display codes are the exact strings the customer reads from the machine screen. There is NO language field: the conversation language is declared via the ⟦LANG:xx⟧ output trailer, never via this tool.',
      parameters: {
        type: 'object',
        properties: {
          name: { type: 'string', description: 'Customer full name (e.g. "Marco Rossi")' },
          location: {
            type: 'string',
            description: 'Laundromat name (canonical: Mataró, Eixample, Gràcia, Sant Cugat, Rubí, Terrassa).',
          },
          machineType: {
            type: 'string',
            enum: ['washer', 'dryer'],
            description: 'washer = lavadora/lavatrice. dryer = secadora/asciugatrice.',
          },
          machine: { type: 'integer', description: 'Machine number (e.g. 5)' },
          displayCode: {
            type: 'string',
            description: 'Exact display string (e.g. "OPEN", "WAIT", "SELECT", "ALERT"). Uppercase as shown.',
          },
        },
        additionalProperties: false,
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'request_invoice',
      description:
        'Submit a structured invoice request to the operator by email. Call this ONLY when you have collected ALL 5 fields from the customer (companyName, amount, serviceDate, email, note — note can be empty). The tool validates email format (RFC 5322) and serviceDate (accepts ISO date, DD/MM/YYYY, or natural language "oggi"/"ayer"/"today"/"yesterday"). If validation fails, the tool returns ok:false with a specific error — re-ask only the invalid field. After 3 failed attempts on the same field, escalate via escalate_to_operator with reason="invoice_request".',
      parameters: {
        type: 'object',
        properties: {
          companyName: { type: 'string', description: 'Company / business name (razón social / ragione sociale).' },
          amount: { type: 'string', description: 'Amount paid in euros (e.g. "8.50", "8,50 €", "8 euros"). Free-form.' },
          serviceDate: { type: 'string', description: 'When the service was used: ISO ("2026-05-27"), DD/MM/YYYY ("27/05/2026"), or natural ("oggi", "ayer", "today", "yesterday").' },
          email: { type: 'string', description: 'Customer email for invoice delivery.' },
          note: { type: 'string', description: 'Optional note (CIF, customer code, reference). Pass empty string if customer said "no".' },
        },
        required: ['companyName', 'amount', 'serviceDate', 'email', 'note'],
        additionalProperties: false,
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'schedule_consultation',
      description:
        'Book a franchising consultation appointment with the commercial team. Call this ONLY when the customer has selected a time slot from the list you offered (by selecting 1, 2, 3, etc.). The tool creates a real Google Calendar event, a real Zoom meeting, and sends a confirmation email. It returns calendar_link and zoom_link when available — when present, include those exact links in your confirmation message to the customer. If they are null, simply confirm the appointment by date/time without inventing links. Do NOT call this twice for the same customer.',
      parameters: {
        type: 'object',
        properties: {
          slotIndex: {
            type: 'integer',
            description: 'The index of the selected time slot (1-based, e.g. customer says "2" for the second option).',
          },
        },
        required: ['slotIndex'],
        additionalProperties: false,
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'check_order_status',
      description:
        'Look up the customer\'s TINTORERÍA (dry-cleaning) order(s) to tell them the status and when/where to pick up. The customer is identified by their PHONE automatically — do NOT ask for an order number. Call this whenever the customer asks about picking up or the status of their dry-cleaning (e.g. "when can I pick up my trousers?", "is my coat ready?"); pass NO arguments. Pass `orderNumber` ONLY in the third-party case (someone picking up for someone else, who has the receipt number). Returns { found, orders: [{ order_number, status: "ready"|"in_progress", ready_date, location, items }] }. If several orders come back, match by the garment the customer mentioned. found:false → no order: tell them to check at the sede. NEVER invent a status. Tintorería only, never laundry machines.',
      parameters: {
        type: 'object',
        properties: {
          orderNumber: {
            type: 'string',
            description: 'OPTIONAL. Only for third-party pickup: the receipt order number exactly as written (e.g. "1234", "#2001"). Omit for the normal phone-based lookup.',
          },
        },
        additionalProperties: false,
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'escalate_to_operator',
      description:
        'Send a structured briefing to the human operator by email. Call this when the procedure documented in MACHINES says ESCALAR, when the customer explicitly asks for a human, or when a problem persists after the documented steps. The summary should be a self-contained operator briefing following the template in common.md. The host will substitute placeholder PII tokens with real values from SessionState before sending. Call this EXACTLY ONCE per incident — never emit two escalate_to_operator calls in the same turn; one call is enough.',
      parameters: {
        type: 'object',
        properties: {
          reason: {
            type: 'string',
            enum: [
              'machine_broken',
              'door_persistent',
              'alarm_technical',
              'dryer_no_heat',
              'double_charge',
              'no_change',
              'invoice_request',
              'loyalty_card',
              'no_soap',
              'no_spin',
              'garment_damaged',
              'garment_lost',
              'angry_customer',
              'not_covered',
              'other',
            ],
            description: 'High-level reason code for the escalation.',
          },
          summary: {
            type: 'string',
            description:
              'Operator briefing in the language indicated by RUNTIME.operatorBriefingLanguage. Use the exact template from common.md (header, 🕒 Fecha, 📍 Sede, 🔢 Máquina, 👤 Cliente, 🌐 Idioma, 🚨 Incidencia, 📋 Resumen, ✅ Acción sugerida). Include all known facts from SESSION STATE.',
          },
        },
        required: ['reason', 'summary'],
        additionalProperties: false,
      },
    },
  },
] as const

// ── Tool dispatcher ───────────────────────────────────────────────────────────

interface ToolResult {
  ok: boolean
  [k: string]: unknown
}

// ── Injectable side-effect handlers ──────────────────────────────────────────
// The standalone module knows nothing about Prisma, Google Calendar or Zoom.
// In production the host (CustomClientChatbotService) injects a real handler
// that creates the calendar event + Zoom meeting using the workspace's stored
// connections. In REPL/batch the handler is absent → console + email only.

export interface ScheduleConsultationParams {
  workspaceId: string
  date: string // 'YYYY-MM-DD'
  time: string // 'HH:MM' 24h, interpreted in the workspace timezone (host-side)
  durationMinutes: number
  topic: string
  customerName: string
  customerEmail: string
  customerPhone?: string
  location?: string
}

export interface ScheduleConsultationResult {
  googleEventLink?: string | null
  zoomLink?: string | null
}

export type ScheduleConsultationHandler = (
  params: ScheduleConsultationParams,
) => Promise<ScheduleConsultationResult>

// Tintorería order lookup. Primary key is the customer PHONE (already known on
// WhatsApp / the demo form) → no order code needed. An order NUMBER is optional,
// only for third-party pickup. In production the host injects a real handler that
// queries the backend/POS; in REPL/batch/website-demo it is absent and
// executeTool falls back to the seeded demo store (orders.ts).
export type CheckOrderStatusHandler = (
  params: { workspaceId?: string; phone?: string; orderNumber?: string; location?: string },
) => Promise<CheckOrderStatusResult>

interface ToolContext {
  sessionId: string
  customerName?: string
  customerPhone?: string
  /** Workspace running this session — needed to resolve the calendar/Zoom
   *  connection. Present in production, absent in REPL/batch. */
  workspaceId?: string
  /** Real booking side-effect, injected by the host. Absent in REPL/batch. */
  scheduleConsultation?: ScheduleConsultationHandler
  /** Real tintorería order lookup, injected by the host. Absent in REPL/batch
   *  → falls back to the seeded demo store. */
  checkOrderStatus?: CheckOrderStatusHandler
}

async function executeTool(
  ctx: ToolContext,
  name: string,
  args: Record<string, unknown>,
): Promise<ToolResult> {
  if (name === 'remember') {
    const patch: Partial<SessionState> = {}
    if (typeof args.name === 'string') patch.name = args.name
    if (typeof args.location === 'string') patch.location = args.location
    // Normalize machineType: some model completions leak tool-call markup into
    // the value (e.g. "washer</machineType>\n</invoke>"). Match the canonical
    // token inside the raw value instead of requiring exact equality, so a
    // malformed-but-recoverable arg still sets the field (avoids losing the
    // machine type in the operator briefing).
    if (typeof args.machineType === 'string') {
      if (/\bwasher\b/.test(args.machineType)) patch.machineType = 'washer'
      else if (/\bdryer\b/.test(args.machineType)) patch.machineType = 'dryer'
    }
    if (typeof args.machine === 'number' && Number.isFinite(args.machine)) patch.machine = args.machine
    if (typeof args.displayCode === 'string') patch.displayCode = args.displayCode
    // NOTE: `language` is NOT accepted here (would resurrect the T1 empty-reply
    // bug — see iron rule #3). The LLM declares the language via the ⟦LANG:xx⟧
    // reply trailer; commitLanguageFromReply persists it AFTER the turn.
    const state = updateState(ctx.sessionId, patch)
    return { ok: true, state }
  }

  if (name === 'request_invoice') {
    const state = getState(ctx.sessionId)
    // Substitute placeholders the LLM may have used (e.g. [COMPANY_NAME] if
    // the customer's company was de-redacted in history). The real values
    // live in SessionState. PII fields (email, cif, ...) are typically
    // captured fresh in the current turn by the pre-scan, so they arrive
    // here as literal values; placeholders are mostly a defense for
    // non-PII profile fields (companyName, address) reused across turns.
    const companyName = substitutePlaceholders(
      typeof args.companyName === 'string' ? args.companyName.trim() : '',
      state,
    )
    const amount = typeof args.amount === 'string' ? args.amount.trim() : ''
    const serviceDate = typeof args.serviceDate === 'string' ? args.serviceDate.trim() : ''
    const email = substitutePlaceholders(
      typeof args.email === 'string' ? args.email.trim() : '',
      state,
    )
    const note = substitutePlaceholders(
      typeof args.note === 'string' ? args.note.trim() : '',
      state,
    )

    // Persist customer's structured invoice profile into the state so the
    // host can mirror it into Customers via patches.
    const profilePatch: Partial<SessionState> = {}
    if (companyName) profilePatch.companyName = companyName
    if (note) profilePatch.notes = note
    if (Object.keys(profilePatch).length > 0) {
      updateState(ctx.sessionId, profilePatch)
    }

    if (!companyName) return { ok: false, error: 'companyName is required' }
    if (!amount) return { ok: false, error: 'amount is required' }
    if (!serviceDate) return { ok: false, error: 'serviceDate is required' }
    if (!email) return { ok: false, error: 'email is required' }

    if (!isValidEmail(email)) {
      return { ok: false, error: `email "${email}" is not valid. Re-ask the customer for a valid email.` }
    }

    const normalizedDate = normalizeDate(serviceDate)
    if (!normalizedDate) {
      return {
        ok: false,
        error: `serviceDate "${serviceDate}" is not recognized. Accept ISO ("2026-05-27"), DD/MM/YYYY, or "today"/"yesterday"/"oggi"/"ayer". Re-ask the customer.`,
      }
    }

    const invoiceId = `INV-${Date.now().toString(36).toUpperCase()}`

    try {
      await sendInvoiceEmail({
        invoiceId,
        companyName,
        amount,
        serviceDate: normalizedDate,
        email,
        note,
        state,
        customerName: ctx.customerName,
        customerPhone: ctx.customerPhone,
      })
      return { ok: true, invoice_id: invoiceId, email_sent: !!GMAIL_USER }
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err)
      console.error(`[invoice_email_failed] ${msg}`)
      // Return ok:true so the bot can still tell the customer the request
      // is registered — operator will see the audit log entry.
      return { ok: true, invoice_id: invoiceId, email_sent: false, email_error: msg }
    }
  }

  if (name === 'escalate_to_operator') {
    const reason = typeof args.reason === 'string' ? args.reason : 'other'
    const rawSummary = typeof args.summary === 'string' ? args.summary : ''
    if (!rawSummary) {
      return { ok: false, error: 'summary is required and must be a non-empty string' }
    }
    const state = getState(ctx.sessionId)

    if (!state.name) {
      return {
        ok: false,
        error: 'missing_customer_name',
        instruction: 'Customer name is required before escalation. Ask the customer their name in their language, save it with remember({name: "..."}), then retry escalate_to_operator with the same summary.',
      }
    }

    // Idempotency: the LLM occasionally calls escalate_to_operator twice in the
    // same turn (e.g. it retries after a missing_customer_name failure but also
    // re-emits the original call). Fire the email exactly once per (session,
    // reason). A duplicate returns ok:true with already_escalated so the bot
    // still confirms to the customer, but no second operator email is sent.
    if (!markEscalationOnce(ctx.sessionId, reason)) {
      if (process.env.LLM_DEBUG === '1') {
        console.error(`[escalation_skipped_duplicate] reason=${reason}`)
      }
      return { ok: true, already_escalated: true, eta_minutes: 5 }
    }

    const ticketId = `TKT-${Date.now().toString(36).toUpperCase()}`

    // Substitute placeholders ([CUSTOMER_NAME], [CIF], ...) with real values
    // from SessionState before sending to the operator. The LLM-produced
    // summary contains placeholders because the LLM never saw real PII.
    const summary = substitutePlaceholders(rawSummary, state)

    try {
      await sendEscalationEmail({
        ticketId,
        reason,
        summary,
        state,
        customerName: ctx.customerName,
        customerPhone: ctx.customerPhone,
      })
      return { ok: true, ticket_id: ticketId, eta_minutes: 5, email_sent: !!GMAIL_USER }
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err)
      console.error(`[escalation_email_failed] ${msg}`)
      // Still return ok:true so the bot can tell the customer the case has
      // been registered — the briefing is logged for retry/audit even if
      // email failed (e.g. SMTP down). The ticket exists.
      return { ok: true, ticket_id: ticketId, eta_minutes: 5, email_sent: false, email_error: msg }
    }
  }

  if (name === 'check_order_status') {
    const orderNumber = typeof args.orderNumber === 'string' ? args.orderNumber.trim() : ''
    const state = getState(ctx.sessionId)
    // Read-only side-effect (no state mutation). Real lookup injected by the host
    // in production; REPL/batch/website-demo falls back to the seeded demo store.
    // Primary key is the customer phone (no code); orderNumber only for third-party.
    const lookup: CheckOrderStatusResult = ctx.checkOrderStatus
      ? await ctx.checkOrderStatus({
          workspaceId: ctx.workspaceId,
          phone: ctx.customerPhone,
          orderNumber: orderNumber || undefined,
          location: state.location,
        })
      : orderNumber
        ? lookupDemoOrderByNumber(orderNumber, new Date())
        : lookupDemoOrdersByPhone(new Date(), state.location)

    if (!lookup.found || lookup.orders.length === 0) {
      return {
        ok: false,
        error: orderNumber ? 'order_not_found' : 'no_orders_for_customer',
        instruction: orderNumber
          ? `No order matches "${orderNumber}". Ask the customer to re-check the receipt number. Do NOT invent a status.`
          : 'No tintorería order found for this customer. Tell them to check directly at the sede. Do NOT invent a status.',
      }
    }
    return {
      ok: true,
      orders: lookup.orders.map((o) => ({
        order_number: o.orderNumber,
        status: o.status,
        ready_date: o.readyDate,
        location: o.location,
        items: o.items,
      })),
    }
  }

  if (name === 'schedule_consultation') {
    const state = getState(ctx.sessionId)
    const slotIndex = typeof args.slotIndex === 'number' ? args.slotIndex : 0

    // Idempotency: one consultation per session. A second call must not
    // create a duplicate Calendar event / Zoom meeting / email.
    if (state.appointmentDate) {
      return {
        ok: false,
        error: 'already_booked',
        instruction: `The customer already has an appointment on ${state.appointmentDate} at ${state.appointmentTime}. Tell them to contact the team if they need to reschedule.`,
      }
    }

    if (!state.name) {
      return {
        ok: false,
        error: 'Customer name is required before scheduling. Ensure remember({name: "..."}) was called.',
      }
    }
    if (!state.email) {
      return {
        ok: false,
        error: 'Customer email is required before scheduling. Ask the customer for their email address first (the system captures it automatically when they write it), then retry.',
      }
    }

    const AVAILABLE_SLOTS = getConsultationSlots(new Date())

    if (slotIndex < 1 || slotIndex > AVAILABLE_SLOTS.length) {
      return {
        ok: false,
        error: `Invalid slot index. Valid options are 1-${AVAILABLE_SLOTS.length}.`,
      }
    }

    const selectedSlot = AVAILABLE_SLOTS[slotIndex - 1]
    const appointmentId = `APT-${Date.now().toString(36).toUpperCase()}`

    // Update state with appointment details
    const appointmentPatch: Partial<SessionState> = {
      appointmentDate: selectedSlot.date,
      appointmentTime: selectedSlot.time,
      appointmentType: 'franchising_consultation',
    }
    updateState(ctx.sessionId, appointmentPatch)

    // Real side-effects (Google Calendar event + Zoom meeting) run host-side
    // through the injected handler. Absent in REPL/batch → links stay null and
    // we fall back to a console + email confirmation without invented links.
    let calendarLink: string | null = null
    let zoomLink: string | null = null
    if (ctx.scheduleConsultation && ctx.workspaceId) {
      try {
        const booking = await ctx.scheduleConsultation({
          workspaceId: ctx.workspaceId,
          date: selectedSlot.date,
          time: selectedSlot.time,
          durationMinutes: 30,
          topic: `Consulta franchising — ${state.name}`,
          customerName: state.name,
          customerEmail: state.email,
          customerPhone: state.phone,
          location: state.location,
        })
        calendarLink = booking.googleEventLink ?? null
        zoomLink = booking.zoomLink ?? null
      } catch (err) {
        const msg = err instanceof Error ? err.message : String(err)
        console.error(`[schedule_consultation_handler_failed] ${msg}`)
      }
    }

    // Notify the admin/operator with a lead briefing (name, contacts, city,
    // machine, slot, request). Independent of the customer email — a failure
    // here must not block the booking confirmation.
    try {
      await sendConsultationOperatorBriefing({
        appointmentId,
        appointmentDate: selectedSlot.date,
        appointmentTime: selectedSlot.time,
        state,
        calendarLink,
        zoomLink,
      })
    } catch (err) {
      console.error(`[consultation_operator_email_failed] ${err instanceof Error ? err.message : String(err)}`)
    }

    try {
      await sendConsultationEmail({
        appointmentId,
        customerName: state.name,
        customerEmail: state.email,
        customerPhone: state.phone,
        appointmentDate: selectedSlot.date,
        appointmentTime: selectedSlot.time,
        state,
        calendarLink,
        zoomLink,
      })
      return {
        ok: true,
        appointment_id: appointmentId,
        date: selectedSlot.date,
        time: selectedSlot.time,
        calendar_link: calendarLink,
        zoom_link: zoomLink,
        email_sent: !!GMAIL_USER,
      }
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err)
      console.error(`[consultation_email_failed] ${msg}`)
      return {
        ok: true,
        appointment_id: appointmentId,
        date: selectedSlot.date,
        time: selectedSlot.time,
        calendar_link: calendarLink,
        zoom_link: zoomLink,
        email_sent: false,
        email_error: msg,
      }
    }
  }

  return { ok: false, error: `unknown tool: ${name}` }
}

// ── Validators (used by request_invoice tool) ────────────────────────────────

const EMAIL_RE = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/

function isValidEmail(email: string): boolean {
  if (!email || email.length > 254) return false
  return EMAIL_RE.test(email)
}

// Accept: ISO ("2026-05-27"), DD/MM/YYYY ("27/05/2026"), DD-MM-YYYY, and the
// words "today"/"yesterday" in every supported language (es, ca, en, it, fr,
// pt, de — must stay in sync with settings.enabledLanguages + de). Returns an
// ISO date string ("YYYY-MM-DD") if recognized, null otherwise.
function normalizeDate(input: string): string | null {
  const s = input.trim().toLowerCase()
  if (!s) return null

  //          en     it    es   fr            pt    ca    de
  const TODAY = /^(today|oggi|hoy|aujourd'hui|hoje|avui|heute)$/
  const YESTERDAY = /^(yesterday|ieri|ayer|hier|ontem|ahir|gestern)$/

  if (TODAY.test(s)) return new Date().toISOString().slice(0, 10)
  if (YESTERDAY.test(s)) {
    const d = new Date()
    d.setDate(d.getDate() - 1)
    return d.toISOString().slice(0, 10)
  }

  // ISO: YYYY-MM-DD
  const iso = s.match(/^(\d{4})-(\d{2})-(\d{2})$/)
  if (iso) {
    const d = new Date(`${iso[1]}-${iso[2]}-${iso[3]}T00:00:00Z`)
    if (!Number.isNaN(d.getTime())) return `${iso[1]}-${iso[2]}-${iso[3]}`
  }

  // DD/MM/YYYY or DD-MM-YYYY
  const eu = s.match(/^(\d{1,2})[/\-.](\d{1,2})[/\-.](\d{4})$/)
  if (eu) {
    const dd = eu[1].padStart(2, '0')
    const mm = eu[2].padStart(2, '0')
    const yyyy = eu[3]
    const d = new Date(`${yyyy}-${mm}-${dd}T00:00:00Z`)
    if (!Number.isNaN(d.getTime())) return `${yyyy}-${mm}-${dd}`
  }

  return null
}

// ── Email — invoice request ──────────────────────────────────────────────────

interface InvoiceParams {
  invoiceId: string
  companyName: string
  amount: string
  serviceDate: string
  email: string
  note: string
  state: SessionState
  customerName?: string
  customerPhone?: string
}

async function sendInvoiceEmail(params: InvoiceParams): Promise<void> {
  const { invoiceId, companyName, amount, serviceDate, email, note, state, customerName, customerPhone } = params

  console.error('\n══════ INVOICE REQUEST ══════')
  console.error(`Invoice ID: ${invoiceId}`)
  console.error(`To: ${OPERATOR_EMAIL || '(no operatorEmail configured)'}`)
  console.error(`Company: ${companyName}`)
  console.error(`Amount: ${amount}`)
  console.error(`Service date: ${serviceDate}`)
  console.error(`Customer email: ${email}`)
  console.error(`Note: ${note || '(none)'}`)
  console.error(`Customer (from state): ${state.name ?? customerName ?? '?'}`)
  console.error(`Customer phone: ${customerPhone ?? '?'}`)
  console.error(`Location (if known): ${state.location ?? '?'}`)
  console.error('══════════════════════════════\n')

  if (!OPERATOR_EMAIL) {
    throw new Error('OPERATOR_EMAIL not configured (settings.json or env)')
  }
  if (!GMAIL_USER || !GMAIL_APP_PASSWORD) {
    throw new Error('GMAIL_USER / GMAIL_APP_PASSWORD missing in .env (invoice request logged to console only)')
  }

  const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: { user: GMAIL_USER, pass: GMAIL_APP_PASSWORD },
  })

  const subject = `${EMAIL_SUBJECT_PREFIX.replace('Incidencia', 'Factura')} ${invoiceId} — ${companyName}`
  const textBody = [
    `Solicitud de factura: ${invoiceId}`,
    '',
    `Razón social: ${companyName}`,
    `Importe: ${amount}`,
    `Fecha del servicio: ${serviceDate}`,
    `Email del cliente: ${email}`,
    `Nota: ${note || '(ninguna)'}`,
    '',
    `Cliente: ${state.name ?? customerName ?? '?'}`,
    `Teléfono: ${customerPhone ?? '?'}`,
    `Sede (si se conoce): ${state.location ?? '?'}`,
    '',
    '— Demowash Bot',
  ].join('\n')

  await transporter.sendMail({
    from: EMAIL_FROM,
    to: OPERATOR_EMAIL,
    subject,
    text: textBody,
  })
}

// ── Email consultation scheduling ────────────────────────────────────────────

interface ConsultationParams {
  appointmentId: string
  customerName: string
  customerEmail: string
  customerPhone?: string
  appointmentDate: string
  appointmentTime: string
  state: SessionState
  /** Real Google Calendar event link, when the booking handler produced one. */
  calendarLink?: string | null
  /** Real Zoom join link, when the booking handler produced one. */
  zoomLink?: string | null
}

async function sendConsultationEmail(params: ConsultationParams): Promise<void> {
  const { appointmentId, customerName, customerEmail, customerPhone, appointmentDate, appointmentTime, state, calendarLink, zoomLink } = params

  console.error('\n══════ CONSULTATION APPOINTMENT ══════')
  console.error(`Appointment ID: ${appointmentId}`)
  console.error(`To: ${customerEmail}`)
  console.error(`Customer: ${customerName}`)
  console.error(`Phone: ${customerPhone ?? '(not provided)'}`)
  console.error(`Location (desired): ${state.location ?? '(not specified)'}`)
  console.error(`Date: ${appointmentDate}`)
  console.error(`Time: ${appointmentTime}`)
  console.error(`Zoom: ${zoomLink ?? '(not created)'}`)
  console.error(`Calendar: ${calendarLink ?? '(not created)'}`)
  console.error('════════════════════════════════════════\n')

  if (!GMAIL_USER || !GMAIL_APP_PASSWORD) {
    throw new Error('GMAIL_USER / GMAIL_APP_PASSWORD missing in .env (consultation logged to console only)')
  }

  const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: { user: GMAIL_USER, pass: GMAIL_APP_PASSWORD },
  })

  const dateObj = new Date(`${appointmentDate}T${appointmentTime}:00Z`)
  const dateStr = dateObj.toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' })
  const timeStr = appointmentTime

  const subject = `[Demowash] Franchising Consultation Confirmed — ${appointmentId}`
  const textBody = [
    `Hello ${customerName},`,
    '',
    'Your franchising consultation appointment has been confirmed! 👋',
    '',
    `📅 Date: ${dateStr}`,
    `🕐 Time: ${timeStr} (UTC)`,
    `📍 Location (desired): ${state.location ?? '(to be discussed)'}`,
    ...(zoomLink ? ['', `🔗 Zoom: ${zoomLink}`] : []),
    ...(calendarLink ? ['', `📆 Calendar: ${calendarLink}`] : []),
    '',
    'Our commercial team will discuss:',
    '- Franchising model & business structure',
    '- Startup costs & investment details',
    '- Ongoing support & training',
    '- Timeline & next steps',
    '',
    'See you soon!',
    '',
    '— Demowash Commercial Team',
  ].join('\n')

  await transporter.sendMail({
    from: EMAIL_FROM,
    to: customerEmail,
    subject,
    text: textBody,
  })
}

// ── Email consultation — admin/operator lead briefing ────────────────────────
// Sent to OPERATOR_EMAIL whenever a franchising consultation is booked, so the
// admin gets the full lead (contacts + context) without reading the chat.

interface ConsultationBriefingParams {
  appointmentId: string
  appointmentDate: string
  appointmentTime: string
  state: SessionState
  calendarLink?: string | null
  zoomLink?: string | null
}

async function sendConsultationOperatorBriefing(params: ConsultationBriefingParams): Promise<void> {
  const { appointmentId, appointmentDate, appointmentTime, state, calendarLink, zoomLink } = params

  console.error('\n══════ CONSULTATION LEAD (operator) ══════')
  console.error(`Appointment ID: ${appointmentId}`)
  console.error(`To: ${OPERATOR_EMAIL || '(no operatorEmail configured)'}`)
  console.error(`Customer: ${state.name ?? '?'}`)
  console.error(`Email: ${state.email ?? '?'}`)
  console.error(`Phone: ${state.phone ?? '?'}`)
  console.error(`City/Location: ${state.location ?? '?'}`)
  console.error(`Slot: ${appointmentDate} ${appointmentTime}`)
  console.error('══════════════════════════════════════════\n')

  if (!OPERATOR_EMAIL) {
    throw new Error('OPERATOR_EMAIL not configured (settings.json or env)')
  }
  if (!GMAIL_USER || !GMAIL_APP_PASSWORD) {
    throw new Error('GMAIL_USER / GMAIL_APP_PASSWORD missing in .env (lead briefing logged to console only)')
  }

  const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: { user: GMAIL_USER, pass: GMAIL_APP_PASSWORD },
  })

  const machineLine = state.machine
    ? `🔢 Máquina: ${state.machineType ?? ''} ${state.machine}`.trim()
    : null

  const subject = `[Demowash] Nueva consulta franchising — ${appointmentId}`
  const textBody = [
    'Nueva solicitud de consulta de franchising.',
    '',
    `🆔 Cita: ${appointmentId}`,
    `🗓️ Fecha/hora: ${appointmentDate} ${appointmentTime} (UTC)`,
    '',
    '— Cliente —',
    `👤 Nombre: ${state.name ?? '(no facilitado)'}`,
    `📧 Email: ${state.email ?? '(no facilitado)'}`,
    `📞 Teléfono: ${state.phone ?? '(no facilitado)'}`,
    `📍 Ciudad/Sede: ${state.location ?? '(no especificada)'}`,
    ...(machineLine ? [machineLine] : []),
    `🌐 Idioma: ${state.language ?? '(desconocido)'}`,
    '',
    '— Interés —',
    'Consulta de franchising (apertura de lavandería).',
    ...(zoomLink ? ['', `🔗 Zoom: ${zoomLink}`] : []),
    ...(calendarLink ? [`📆 Calendar: ${calendarLink}`] : []),
    '',
    '— Demowash Bot',
  ].join('\n')

  await transporter.sendMail({
    from: EMAIL_FROM,
    to: OPERATOR_EMAIL,
    subject,
    text: textBody,
  })
}

// ── Email escalation ──────────────────────────────────────────────────────────
// Real SMTP via Gmail App Password. Falls back to console-only briefing when
// GMAIL_USER/GMAIL_APP_PASSWORD are not set (POC / first run).

interface EscalationParams {
  ticketId: string
  reason: string
  summary: string
  state: SessionState
  customerName?: string
  customerPhone?: string
}

async function sendEscalationEmail(params: EscalationParams): Promise<void> {
  const { ticketId, reason, summary, state, customerName, customerPhone } = params

  // Always log the briefing — single source of truth for audit / fallback.
  console.error('\n══════ ESCALATION BRIEFING ══════')
  console.error(`Ticket: ${ticketId}`)
  console.error(`Reason: ${reason}`)
  console.error(`To: ${OPERATOR_EMAIL || '(no operatorEmail configured)'}`)
  console.error(`Customer (from state): ${state.name ?? customerName ?? '?'}`)
  console.error(`Phone: ${customerPhone ?? '?'}`)
  console.error(`Location: ${state.location ?? '?'}`)
  console.error(`Machine: ${state.machine ?? '?'} (${state.machineType ?? '?'})`)
  console.error(`Display: ${state.displayCode ?? '?'}`)
  console.error(`Language: ${state.language ?? '?'}`)
  console.error('---')
  console.error(summary)
  console.error('══════════════════════════════════\n')

  if (!OPERATOR_EMAIL) {
    throw new Error('OPERATOR_EMAIL not configured (settings.json or env)')
  }
  if (!GMAIL_USER || !GMAIL_APP_PASSWORD) {
    // Soft-fail in POC: log warning, don't crash. Production should make this hard.
    throw new Error('GMAIL_USER / GMAIL_APP_PASSWORD missing in .env (briefing logged to console only)')
  }

  const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: { user: GMAIL_USER, pass: GMAIL_APP_PASSWORD },
  })

  const subject = `${EMAIL_SUBJECT_PREFIX} ${ticketId} — ${state.location ?? 'sede ?'} — ${reason}`
  const textBody = [
    `Ticket: ${ticketId}`,
    `Razón: ${reason}`,
    '',
    summary,
    '',
    '— Demowash Bot',
  ].join('\n')

  await transporter.sendMail({
    from: EMAIL_FROM,
    to: OPERATOR_EMAIL,
    subject,
    text: textBody,
  })
}

// ── LLM call with system-prompt caching ───────────────────────────────────────

interface LlmResponse {
  content: string | null
  tool_calls?: ToolCall[]
  usage?: {
    prompt_tokens?: number
    completion_tokens?: number
  }
}

async function callLLM(
  cachedSystemPrompt: string,
  state: SessionState,
  history: Message[],
  operatorBriefingLanguageOverride?: string | null,
  isFirstTurn = false,
): Promise<LlmResponse> {
  if (!API_KEY) throw new Error('OPENROUTER_API_KEY missing in environment')

  const stateBlock = formatStateForPrompt(state)
  const runtimeBlock = formatRuntimeBlock(operatorBriefingLanguageOverride, isFirstTurn)

  // Cached block first (cache_control: ephemeral). State + runtime blocks are
  // appended WITHOUT cache_control so they can change per turn / per day
  // without invalidating the cache.
  const systemContent: Array<Record<string, unknown>> = [
    {
      type: 'text',
      text: cachedSystemPrompt,
      cache_control: { type: 'ephemeral' },
    },
  ]
  if (stateBlock) {
    systemContent.push({ type: 'text', text: stateBlock })
  }
  systemContent.push({ type: 'text', text: runtimeBlock })

  // Ollama's OpenAI-compatible endpoint doesn't support typed content blocks or
  // `cache_control` (an Anthropic/OpenRouter prompt-caching feature). In local
  // mode, flatten the system message to a plain string so the request is valid.
  // We also append Qwen's `/no_think` soft-switch to disable the model's hidden
  // reasoning trace (much faster for a customer-service bot). Re-enable with
  // LLM_THINK=1. Harmless on non-Qwen models (treated as plain text).
  const disableThinking = LOCAL_MODE && process.env.LLM_THINK !== '1'
  const systemMessageContent: unknown = LOCAL_MODE
    ? systemContent.map((b) => (b as { text?: string }).text ?? '').join('\n\n') +
      (disableThinking ? '\n\n/no_think' : '')
    : systemContent

  const payload = {
    model: MODEL,
    messages: [{ role: 'system', content: systemMessageContent }, ...history],
    tools: TOOLS,
    tool_choice: 'auto',
    temperature: TEMPERATURE,
    max_tokens: MAX_TOKENS,
  }

  const res = await fetch(`${BASE_URL}/chat/completions`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${API_KEY}`,
      'Content-Type': 'application/json',
      'HTTP-Referer': 'https://echatbot.ai',
      'X-Title': 'Demowash',
    },
    body: JSON.stringify(payload),
  })

  if (!res.ok) {
    const body = await res.text()
    const provider = LOCAL_MODE ? 'Ollama' : 'OpenRouter'
    throw new Error(`${provider} HTTP ${res.status}: ${body.slice(0, 500)}`)
  }

  const data = (await res.json()) as {
    choices?: Array<{ message?: { content?: string | null; tool_calls?: ToolCall[] } }>
    usage?: {
      prompt_tokens?: number
      completion_tokens?: number
      prompt_tokens_details?: { cached_tokens?: number }
      cache_creation_input_tokens?: number
      cache_read_input_tokens?: number
    }
  }

  if (process.env.LLM_DEBUG === '1' && data.usage) {
    const u = data.usage
    const cached = u.cache_read_input_tokens ?? u.prompt_tokens_details?.cached_tokens ?? 0
    const created = u.cache_creation_input_tokens ?? 0
    console.error(
      `[usage] prompt=${u.prompt_tokens ?? '?'} completion=${u.completion_tokens ?? '?'} cache_read=${cached} cache_write=${created}`,
    )
  }

  const msg = data.choices?.[0]?.message
  return {
    content: msg?.content ?? null,
    tool_calls: msg?.tool_calls,
    usage: {
      prompt_tokens: data.usage?.prompt_tokens,
      completion_tokens: data.usage?.completion_tokens,
    },
  }
}

// ── Turn pipeline ─────────────────────────────────────────────────────────────

interface TurnResult {
  reply: string
  tokensUsed: number
  escalated: boolean
  // When the LLM calls `escalate_to_operator`, this holds the briefing
  // it produced (already post-substituted with real PII values from
  // SessionState). Surfaced upward so the host can ship it to the
  // operator email — replaces the meaningless "Ticket created for
  // <uuid>" placeholder we used before.
  operatorBriefing?: string | null
}

async function agentTurnInternal(
  ctx: ToolContext,
  cachedSystemPrompt: string,
  history: Message[],
  sanitizedMessage: string,
  operatorBriefingLanguageOverride?: string | null,
): Promise<TurnResult> {
  // FIRST-TURN detection for the welcome message. The prompt (common.md) opens
  // every conversation with the localized greeting "when history.length == 0".
  // We read it HERE, before pushing the incoming message, because the host
  // rebuilds `history` from its DB each call — so the prior conversation length
  // is the single reliable signal (the in-RAM turn counter is lost on process
  // restart / cache eviction, which is exactly why the welcome was skipped).
  const isFirstTurn = history.length === 0

  history.push({ role: 'user', content: sanitizedMessage })

  let nudgedAfterEmpty = false
  let tokensUsed = 0
  let escalated = false
  // Captured when escalate_to_operator runs successfully. Appended after the
  // HUMAN_SUPPORT marker so the playground / backoffice can render the
  // briefing in an internal orange balloon (host strips it before sending to
  // the customer — see src/utils/custom-chatbot-reply.ts).
  let operatorBriefing: string | null = null

  for (let hop = 0; hop < MAX_TOOL_HOPS; hop++) {
    const state = getState(ctx.sessionId)
    const response = await callLLM(
      cachedSystemPrompt,
      state,
      history,
      operatorBriefingLanguageOverride,
      isFirstTurn,
    )
    tokensUsed +=
      (response.usage?.prompt_tokens ?? 0) + (response.usage?.completion_tokens ?? 0)

    // No tool calls → final text reply.
    if (!response.tool_calls || response.tool_calls.length === 0) {
      // The LLM appends a ⟦LANG:xx⟧ control trailer (see state.ts). Split it
      // off: `text` is the clean customer-facing reply (marker removed), `lang`
      // is the language the model says it replied in. A trailer-only completion
      // yields an empty `text` → handled by the empty-reply recovery below.
      const { reply: text, lang } = extractLanguage(response.content || '')

      // Empty-reply recovery (see architecture.md §7).
      if (!text && !nudgedAfterEmpty && hop < MAX_TOOL_HOPS - 1) {
        nudgedAfterEmpty = true
        history.push({ role: 'assistant', content: '' })
        history.push({
          role: 'user',
          content:
            '[system] Your previous reply was empty. Please respond to the customer now, in their language, following the rules in the system prompt. Remember to append the ⟦LANG:xx⟧ marker on its own line after a real reply. Do not call any more tools unless strictly necessary.',
        })
        if (process.env.LLM_DEBUG === '1') {
          console.error('[empty_reply_nudge] retrying with explicit instruction')
        }
        continue
      }

      // Commit the LLM-declared language (no-op if missing/invalid → sticky).
      commitLanguageFromReply(ctx.sessionId, lang)
      if (process.env.LLM_DEBUG === '1') {
        console.error(`[lang] declared=${lang ?? '(none → sticky)'}`)
      }

      // Persist the CLEAN reply (no trailer) to history so the marker never
      // leaks into future context windows.
      history.push({ role: 'assistant', content: text })
      if (process.env.LLM_DEBUG === '1') {
        console.error(`[state] ${formatStateOneLine(getState(ctx.sessionId))}`)
      }
      // Internal operator balloon: the escalation briefing (if any). Stripped
      // before the customer delivery by splitCustomChatbotReply (HUMAN_SUPPORT
      // marker).
      const finalReply = operatorBriefing
        ? `${text}\n\n**👤 Human Support message**\n${operatorBriefing}`
        : text
      return { reply: finalReply, tokensUsed, escalated, operatorBriefing }
    }

    // Tool calls present → execute each, append results, loop.
    history.push({
      role: 'assistant',
      content: response.content ?? null,
      tool_calls: response.tool_calls,
    })
    for (const call of response.tool_calls) {
      let args: Record<string, unknown> = {}
      try {
        args = call.function.arguments ? JSON.parse(call.function.arguments) : {}
      } catch (err) {
        args = {}
        if (process.env.LLM_DEBUG === '1') {
          console.error(
            `[tool_call_parse_error] ${call.function.name}: ${err instanceof Error ? err.message : String(err)}`,
          )
        }
      }
      if (process.env.LLM_DEBUG === '1') {
        console.error(`[tool_call] ${call.function.name}(${JSON.stringify(args)})`)
      }
      const result = await executeTool(ctx, call.function.name, args)
      if (call.function.name === 'escalate_to_operator' && result.ok) {
        escalated = true
        // Capture the substituted briefing for the internal-operator balloon.
        // The LLM produced the summary against redacted PII placeholders;
        // substitute against current SessionState before exposing it.
        const rawSummary = typeof args.summary === 'string' ? args.summary : ''
        if (rawSummary) {
          operatorBriefing = substitutePlaceholders(rawSummary, getState(ctx.sessionId))
        }
      }
      history.push({
        role: 'tool',
        tool_call_id: call.id,
        name: call.function.name,
        content: JSON.stringify(result),
      })
    }
  }

  if (process.env.LLM_DEBUG === '1') {
    console.error(`[warn] max tool hops (${MAX_TOOL_HOPS}) reached without text reply`)
  }
  return { reply: '', tokensUsed, escalated }
}

// Public per-turn entry point used by REPL/batch. Wraps with sanitize +
// rate-limit + per-session lock + turn cap. The backend integration
// (`chatbotFn`) calls this through the same wrapper.

async function agentTurn(
  ctx: ToolContext,
  cachedSystemPrompt: string,
  history: Message[],
  rawMessage: string,
  operatorBriefingLanguageOverride?: string | null,
): Promise<TurnResult> {
  const sanitized = sanitizeUserMessage(rawMessage)
  if (!sanitized) {
    return { reply: '', tokensUsed: 0, escalated: false }
  }

  const now = Date.now()
  const recentCount = registerMessageTimestamp(ctx.sessionId, now, 60_000)
  if (recentCount > MAX_MESSAGES_PER_MINUTE) {
    return {
      reply:
        'Has enviado muchos mensajes en poco tiempo. Por favor espera un momento antes de continuar.',
      tokensUsed: 0,
      escalated: false,
    }
  }

  const turnNum = incrementTurn(ctx.sessionId)
  if (turnNum > MAX_TURNS_PER_SESSION) {
    return {
      reply:
        'Esta conversación es muy larga. Por favor inicia una nueva sesión o contacta directamente con un operador.',
      tokensUsed: 0,
      escalated: false,
    }
  }

  // Language is no longer detected here. The LLM judges the customer's
  // language itself and appends a ⟦LANG:xx⟧ trailer to its reply, which is
  // extracted + committed AFTER the turn (see agentTurnInternal). The host
  // already seeded an initial language hint once (mirror:false) at invoke().

  // PII redaction (see pii.ts). Pre-scan extracts structured PII
  // (email/CIF/NIF/IBAN/card/phone) into SessionState and replaces them
  // with placeholders. De-redact uses already-known state to mask
  // re-occurrences of name/address/companyName. The cleaned text is what
  // goes into history and reaches the LLM.
  const state = getState(ctx.sessionId)
  const { cleanText, capturedKeys } = processIncomingMessage(ctx.sessionId, sanitized, state)
  if (process.env.LLM_DEBUG === '1' && capturedKeys.length > 0) {
    console.error(`[pii_redacted] ${capturedKeys.join(', ')}`)
  }

  return withSessionLock(ctx.sessionId, () =>
    agentTurnInternal(
      ctx,
      cachedSystemPrompt,
      history,
      cleanText,
      operatorBriefingLanguageOverride,
    ),
  )
}

// ── System prompt ─────────────────────────────────────────────────────────────
// Assembled at boot from prompts/common.md + prompts/franchising.md +
// prompts/faqs.md + prompts/machines/*.md + prompts/tintoria.md +
// prompts/locations/*.md. Concatenated in a fixed, deterministic order so the
// resulting blob is byte-identical across boots → cache hit always.

async function buildSystemPrompt(): Promise<string> {
  const common = await readFile(path.join(PROMPTS_DIR, 'common.md'), 'utf8')
  const franchising = await readFileOrEmpty(path.join(PROMPTS_DIR, 'franchising.md'))
  const faqs = await readFileOrEmpty(path.join(PROMPTS_DIR, 'faqs.md'))
  const tintoria = await readFileOrEmpty(path.join(PROMPTS_DIR, 'tintoria.md'))
  const machines = await loadDir(path.join(PROMPTS_DIR, 'machines'))
  const locations = await loadDir(path.join(PROMPTS_DIR, 'locations'))

  const parts: string[] = [common]

  if (franchising) {
    parts.push('', '════════ FRANCHISING CONSULTATION ════════', '', franchising)
  }

  if (faqs) {
    parts.push('', '════════ FAQS ════════', '', faqs)
  }

  if (machines.length > 0) {
    parts.push('', '════════ MACHINES ════════', '')
    for (const { name, content } of machines) {
      parts.push(`## ${name}`, '', content, '')
    }
  }

  if (tintoria) {
    parts.push('', '════════ TINTORERÍA ════════', '', tintoria)
  }

  if (locations.length > 0) {
    parts.push('', '════════ LOCATIONS ════════', '')
    for (const { name, content } of locations) {
      parts.push(`## ${name}`, '', content, '')
    }
  }

  return parts.join('\n')
}

// Demo availability: next Monday 10:00 + 15:00 and next Tuesday 11:00,
// always strictly in the future relative to `now`. In production, fetch
// real availability from the database. Used both by the RUNTIME block (so
// the model offers real dates) and by the schedule_consultation handler
// (so slotIndex resolves to the same dates the model offered).
interface ConsultationSlot {
  date: string // YYYY-MM-DD
  time: string // HH:MM
  dayName: string
}

function getConsultationSlots(now: Date): ConsultationSlot[] {
  const nextWeekday = (target: number): Date => {
    const d = new Date(now)
    let delta = (target - d.getDay() + 7) % 7
    if (delta === 0) delta = 7
    d.setDate(d.getDate() + delta)
    return d
  }
  const iso = (d: Date): string => {
    const y = d.getFullYear()
    const m = String(d.getMonth() + 1).padStart(2, '0')
    const day = String(d.getDate()).padStart(2, '0')
    return `${y}-${m}-${day}`
  }
  const monday = nextWeekday(1)
  const tuesday = nextWeekday(2)
  return [
    { date: iso(monday), time: '10:00', dayName: 'Monday' },
    { date: iso(monday), time: '15:00', dayName: 'Monday' },
    { date: iso(tuesday), time: '11:00', dayName: 'Tuesday' },
  ]
}

function formatRuntimeBlock(
  operatorBriefingLanguageOverride?: string | null,
  isFirstTurn = false,
): string {
  const now = new Date()
  const date = now.toLocaleDateString('es-ES', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
  })
  const time = now.toLocaleTimeString('es-ES', {
    hour: '2-digit',
    minute: '2-digit',
  })
  const briefingLanguage =
    (operatorBriefingLanguageOverride && operatorBriefingLanguageOverride.trim()) ||
    OPERATOR_BRIEFING_LANGUAGE
  const slots = getConsultationSlots(now)
  return [
    '',
    '═══ RUNTIME ═══',
    `Current date: ${date}`,
    `Current time: ${time}`,
    // The prompt (common.md) opens the conversation with the welcome greeting
    // when Turn == 1. Emit it explicitly so the model never has to infer it
    // from history (which the host rebuilds per call).
    `Turn: ${isFirstTurn ? 1 : 2}`,
    `Privacy policy URL: ${PRIVACY_POLICY_URL}`,
    `Operator briefing language: ${briefingLanguage}`,
    'Franchising consultation slots (offer EXACTLY these, by index — see FRANCHISING CONSULTATION block):',
    ...slots.map((s, i) => `  ${i + 1}. ${s.dayName} ${s.date} ${s.time}`),
    '',
  ].join('\n')
}

async function readFileOrEmpty(filepath: string): Promise<string> {
  try {
    return await readFile(filepath, 'utf8')
  } catch (err) {
    const code = (err as NodeJS.ErrnoException)?.code
    if (code === 'ENOENT') return ''
    throw err
  }
}

async function loadDir(dir: string): Promise<Array<{ name: string; content: string }>> {
  const files = await readdir(dir)
  const mdFiles = files.filter((f) => f.endsWith('.md')).sort()
  const out: Array<{ name: string; content: string }> = []
  for (const f of mdFiles) {
    const content = await readFile(path.join(dir, f), 'utf8')
    out.push({ name: f.replace(/\.md$/, ''), content })
  }
  return out
}

// ── Public API for backend integration ────────────────────────────────────────
// Contract expected by apps/backend/src/application/services/
// custom-client-chatbot.service.ts (CustomClientChatbotService.invoke).
// The backend loads this module via `workspace.customChatbotId` and calls
// `chatbotFn(input)`. See architecture.md §"Backend integration".

export interface HistoryEntry {
  role: 'user' | 'assistant'
  content: string
  timestamp?: string
}

export interface ChatbotInput {
  userMessage: string
  userName: string
  channel: 'whatsapp' | 'widget' | 'playground'
  config: {
    workspaceId: string
    debugChannel: boolean
    isPlayground: boolean
    /** Open ISO 2-letter language code. The bot replies in ANY language Claude supports;
     *  the deterministic detector covers a handful of common ones, the rest flow through the prompt. */
    language?: string
    /** Per-turn override for the operator briefing language only (not the
     *  customer-facing reply). Used by the playground so the flag selected
     *  in the Use Cases panel flips the language of the "Human Support
     *  message" without dragging the bot's reply into the same language. */
    operatorBriefingLanguageOverride?: string | null
    /** Real side-effect handlers injected by the host. Absent in REPL/batch. */
    handlers?: {
      scheduleConsultation?: ScheduleConsultationHandler
      checkOrderStatus?: CheckOrderStatusHandler
    }
  }
  context: {
    sessionId: string
    customerId?: string
    phoneNumber?: string
    history: HistoryEntry[]
  }
}

export interface ChatbotOutput {
  reply: string | null
  /** ISO 2-letter code of the language the bot actually replied in (declared by
   *  the LLM via the ⟦LANG:xx⟧ trailer and committed to session state). The host
   *  uses this so the deterministic welcome-video intro line matches the reply
   *  language exactly. Undefined only when no turn ran (early returns). */
  language?: string
  shouldEscalate: boolean
  escalationSummary?: string
  notificationEmails?: string
  /** When true, the host should close this chat session and stop forwarding
   *  new customer messages to the bot. Set after the bot completes an
   *  escalation flow (the operator now owns the conversation). */
  closeChat: boolean
  patches?: CustomerPatch[]
  /** Tenant audio policy from settings.json. When false the host must always
   *  reply with text; when true it may mirror the input modality (audio→audio). */
  audioOutput: boolean
  /** Per-language ElevenLabs voice IDs from settings.json (key = lang code,
   *  plus "default"). The host picks by customer language for the TTS voice. */
  audioVoices: Record<string, string>
  meta: {
    tokensUsed: number
    agentChain: string[]
  }
  error?: string
}

// Build the system prompt once at module load. Cached across all backend
// invocations because the file content doesn't change at runtime.
let cachedSystemPromptPromise: Promise<string> | null = null
function getCachedSystemPrompt(): Promise<string> {
  if (!cachedSystemPromptPromise) cachedSystemPromptPromise = buildSystemPrompt()
  return cachedSystemPromptPromise
}

export async function chatbotFn(input: ChatbotInput): Promise<ChatbotOutput> {
  try {
    if (!API_KEY) {
      return {
        reply: null,
        shouldEscalate: false,
        closeChat: false,
        audioOutput: AUDIO_OUTPUT,
        audioVoices: AUDIO_VOICES,
        meta: { tokensUsed: 0, agentChain: ['custom-demowash'] },
        error: 'llm_unavailable',
      }
    }

    const systemPrompt = await getCachedSystemPrompt()
    const sessionId = input.context.sessionId

    // 🌐 LANGUAGE = decided by the CUSTOMER'S MESSAGE, never by the phone
    // prefix. We deliberately DO NOT seed the session language from
    // input.config.language (a phone-prefix guess): seeding it makes the prompt
    // treat the language as "already established" and the bot would keep that
    // guessed language instead of detecting from what the customer actually
    // wrote (e.g. a +33 French number writing in Spanish must get a Spanish
    // reply, not English/French). With no seed, on the first turn the LLM
    // detects the language from the message (even a single word) and falls back
    // to Spanish only when the message is genuinely undecidable — see the
    // ## LANGUAGE block in formatStateForPrompt. From there the ⟦LANG:xx⟧ reply
    // trailer keeps it sticky.

    // Convert backend history → our internal Message[]. The backend may
    // have a richer history than what's in our RAM if this process just
    // restarted; we rebuild the conversation context from their record.
    const history: Message[] = input.context.history.map((h) => ({
      role: h.role,
      content: h.content,
    }))

    const ctx: ToolContext = {
      sessionId,
      customerName: input.userName,
      customerPhone: input.context.phoneNumber,
      workspaceId: input.config.workspaceId,
      scheduleConsultation: input.config.handlers?.scheduleConsultation,
      checkOrderStatus: input.config.handlers?.checkOrderStatus,
    }

    const result = await agentTurn(
      ctx,
      systemPrompt,
      history,
      input.userMessage,
      input.config.operatorBriefingLanguageOverride ?? null,
    )
    const patches = drainPatches(sessionId)

    return {
      reply: result.reply || null,
      // Language the bot replied in — declared by the LLM via ⟦LANG:xx⟧ and
      // committed to state by commitLanguageFromReply. The host uses this for
      // the welcome-video intro so it matches the reply, instead of a phone/DB
      // guess (which can disagree on first contact).
      language: getState(sessionId).language,
      shouldEscalate: result.escalated,
      // Ship the real operator briefing produced by the LLM (post-PII
      // substitution) so the email shows the structured incident summary
      // — customer name, location, machine, problem, ID — instead of an
      // opaque ticket UUID. Falls back to a session reference only when
      // the briefing is missing (defensive — should never happen if
      // escalate_to_operator ran successfully).
      escalationSummary: result.escalated
        ? result.operatorBriefing || `Session ${sessionId} escalated (no briefing captured)`
        : undefined,
      notificationEmails: result.escalated ? OPERATOR_EMAIL || undefined : undefined,
      closeChat: result.escalated,
      patches: patches.length > 0 ? patches : undefined,
      audioOutput: AUDIO_OUTPUT,
      audioVoices: AUDIO_VOICES,
      meta: {
        tokensUsed: result.tokensUsed,
        agentChain: ['custom-demowash'],
      },
    }
  } catch (err) {
    console.error(`[chatbotFn] error: ${err instanceof Error ? err.message : String(err)}`)
    return {
      reply: null,
      shouldEscalate: false,
      closeChat: false,
      audioOutput: AUDIO_OUTPUT,
      audioVoices: AUDIO_VOICES,
      meta: { tokensUsed: 0, agentChain: ['custom-demowash'] },
      error: err instanceof Error ? err.message : String(err),
    }
  }
}

// ── CLI ───────────────────────────────────────────────────────────────────────

async function runInteractive(systemPrompt: string): Promise<void> {
  const sessionId = 'cli-interactive'
  const history: Message[] = []
  const rl = createInterface({ input: process.stdin, output: process.stdout })
  console.log('Demowash chatbot — assembled prompt + state + tools + escalation.')
  console.log('Commands: /exit /quit /reset /state')
  console.log(`model=${MODEL} prompts=${PROMPTS_DIR}${LOCAL_MODE ? ` [LOCAL: ${BASE_URL}]` : ''}`)
  if (OPERATOR_EMAIL) {
    console.log(`operator email: ${OPERATOR_EMAIL} ${GMAIL_USER ? '(SMTP active)' : '(SMTP not configured — briefings logged to console)'}`)
  }
  console.log('')

  const ctx: ToolContext = { sessionId, customerName: 'CLI User' }

  while (true) {
    const input = (await rl.question('> ')).trim()
    if (!input) continue
    if (input === '/exit' || input === '/quit') break
    if (input === '/reset') {
      history.length = 0
      resetState(sessionId)
      console.log('[reset] history + state cleared')
      continue
    }
    if (input === '/state') {
      console.log(`[state] ${formatStateOneLine(getState(sessionId))} (turn ${getTurnCount(sessionId)})`)
      continue
    }
    try {
      const result = await agentTurn(ctx, systemPrompt, history, input)
      console.log(`\n${result.reply}\n`)
    } catch (err) {
      console.error(`[error] ${err instanceof Error ? err.message : String(err)}`)
      if (history.at(-1)?.role === 'user') history.pop()
    }
  }
  rl.close()
}

async function runBatch(systemPrompt: string, rawJson: string): Promise<void> {
  let plan: Array<string[] | string>
  try {
    plan = JSON.parse(rawJson)
    if (!Array.isArray(plan)) throw new Error('top-level must be an array')
  } catch (err) {
    console.error('Invalid --batch JSON:', err instanceof Error ? err.message : String(err))
    process.exit(1)
  }

  let sessionId = 'cli-batch-1'
  let history: Message[] = []
  let scenarioIdx = 0
  let ctx: ToolContext = { sessionId, customerName: 'Batch User' }

  for (const entry of plan) {
    if (entry === '/reset') {
      console.log('\n[RESET] ──────────────────────────────────────────────')
      history = []
      resetState(sessionId)
      sessionId = `cli-batch-${scenarioIdx + 1}`
      ctx = { sessionId, customerName: 'Batch User' }
      continue
    }
    if (!Array.isArray(entry)) {
      console.log(`\n[SKIP] non-array, non-reset entry: ${JSON.stringify(entry)}`)
      continue
    }
    scenarioIdx += 1
    console.log(`\n[SCENARIO ${scenarioIdx}] ═══════════════════════════════════`)
    for (let i = 0; i < entry.length; i += 1) {
      const turn = entry[i]
      console.log(`\n[USER T${i + 1}] ${turn}`)
      try {
        const result = await agentTurn(ctx, systemPrompt, history, turn)
        console.log(`[BOT T${i + 1}] ${result.reply}`)
      } catch (err) {
        console.log(`[ERROR T${i + 1}] ${err instanceof Error ? err.message : String(err)}`)
        if (history.at(-1)?.role === 'user') history.pop()
      }
    }
  }
  console.log('\n[BATCH DONE] ─────────────────────────────────────────────')
}

// ── Bootstrap ─────────────────────────────────────────────────────────────────

function loadDotEnv(envFile: string): void {
  try {
    process.loadEnvFile(envFile)
  } catch (err) {
    const code = (err as NodeJS.ErrnoException)?.code
    if (code === 'ENOENT') return
    console.warn(`[warn] failed to load ${envFile}: ${err instanceof Error ? err.message : String(err)}`)
  }
}

function findBatchArg(): string | null {
  const i = process.argv.indexOf('--batch')
  if (i === -1) return null
  return process.argv[i + 1] ?? null
}

function isDirectExecution(): boolean {
  const entry = process.argv[1]
  if (!entry) return false
  return import.meta.url === pathToFileURL(path.resolve(entry)).href
}

if (isDirectExecution()) {
  if (process.argv.includes('--debug')) process.env.LLM_DEBUG = '1'
  if (!API_KEY) {
    console.error('OPENROUTER_API_KEY missing. Set it in this folder\'s .env file.')
    process.exit(1)
  }
  const main = async () => {
    const systemPrompt = await buildSystemPrompt()
    const batch = findBatchArg()
    if (batch !== null) {
      await runBatch(systemPrompt, batch)
    } else {
      await runInteractive(systemPrompt)
    }
  }
  main().catch((err) => {
    console.error(err)
    process.exit(1)
  })
}
