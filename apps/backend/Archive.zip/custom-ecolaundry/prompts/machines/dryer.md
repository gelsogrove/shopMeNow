# Secadora — códigos de pantalla y procedimientos

Esta información es **común a todas las sedes**. Los códigos de la secadora son **idénticos** a los de la lavadora (mismo sistema), pero hay diferencias operativas: la secadora se paga por **bloques de minutos** (15, 20 o 25 minutos según la sede), y se puede **alargar el tiempo** durante el ciclo añadiendo dinero en la central.

## Códigos de pantalla

Los mismos que la lavadora: `SEL`, `PUSH PROG`, `ON`, `T-28`, `STOP:`, `END:`, `120`, `DOOR:`, `ALM DOOR:`, `001`, `ALM`/`ALN`.

Aplica los mismos procedimientos descritos en `washer.md`, con dos diferencias:

## Procedimiento de pago (antes de arrancar la secadora)

Igual que en la lavadora (ver `washer.md` → "Procedimiento de pago") hasta el paso "recoja el cambio". A partir de ahí:

5. Diríjase a la secadora y apriete el programa que desea (según etiqueta y características de la ropa).
6. La secadora empezará a funcionar.

Si no funciona tras seguir los pasos → ESCALAR.

### Diferencia 1 — Alargar el tiempo de secado

> "Puedes alargar el tiempo de secado hasta 5 minutos antes de que termine el secado, añadiendo dinero en la central de pago."

Si el cliente pregunta cómo prolongar el secado → da esta indicación.
Si añade dinero pero la secadora no acepta la prolongación → ESCALAR.

### Diferencia 2 — Abrir la puerta durante el ciclo

A diferencia de la lavadora, en la secadora **se puede abrir la puerta durante el ciclo** para sacar alguna pieza o comprobar el secado. Si el cliente lo pregunta → confirma que es seguro.

## Problemas específicos de la secadora

### "La ropa ha salido empapada" / "no centrifuga"

Esto NO es un problema de la secadora: la **lavadora** no ha centrifugado correctamente.

👉 **Procedimiento completo documentado en `washer.md` → "Síntomas SIN código de pantalla → Síntoma "no centrifuga""**. Aplícalo desde allí (no preguntes displayCode, identifica location + machine y aplica el procedimiento del síntoma).

### "La ropa ha salido húmeda" (no muy mojada)

Probable problema de carga demasiado grande o mal repartida. Procedimiento:

> "Asegúrate de que la carga no sea demasiado grande y reparte bien la ropa. Puedes añadir más tiempo de secado en la central de pago."

Si tras eso sigue → ESCALAR.

### "La ropa ha salido quemada / con manchas / con plástico pegado"

Problemas relacionados con el cuidado de la prenda o el estado del tambor. Procedimiento:

> "Lo siento mucho. Este tipo de incidencias requieren una revisión manual. La compensación no es automática, depende de la valoración del caso. Voy a registrar la incidencia para que un operador te contacte."

ESCALAR siempre.
