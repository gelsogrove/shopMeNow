# Lavadora — códigos de pantalla y procedimientos

Esta información es **común a todas las sedes**. Los códigos exactos que aparecen en la pantalla de la lavadora y cómo responder a cada uno.

## Códigos de pantalla

| Código        | Significado                                              | Acción del bot |
|---------------|----------------------------------------------------------|----------------|
| `SEL`         | La máquina está pendiente de selección                   | Preguntar si el cliente ha completado el pago. Si SÍ → ESCALAR. Si NO → indicar cerrar la puerta y dirigirse a la caja para pagar. |
| `PUSH PROG`   | Hay que pulsar el programa elegido                       | Indicar que pulse firmemente el botón del programa (60° / 40° / 30° / *). |
| `ON`          | Máquina activada correctamente, ciclo en curso           | Confirmar que todo está bien y esperar al final. |
| `T-28` (mins) | Tiempo aproximado restante del ciclo                     | Solo informativo, indicar que es la cuenta atrás. |
| `STOP:`       | La máquina está desaguando                               | Pedir que espere unos segundos hasta `END`. |
| `END:`        | Lavado terminado, puede abrir la puerta                  | Cierre amable: "Puede abrir la puerta". |
| `120`         | Cuenta atrás final del ciclo                             | Indicar que el ciclo está terminando y esperar `END`. |
| `DOOR:`       | La puerta no está bien cerrada                           | Procedimiento DOOR (ver abajo). |
| `ALM DOOR:`   | Posible problema de cierre o prenda atrapada             | Primero tratar como DOOR. Si persiste → ESCALAR + reportar a técnico. |
| `001`         | Selección del programa antes del pago                    | Procedimiento 001 (ver abajo). |
| `ALM`/`ALN`   | Fallo técnico de la máquina                              | Procedimiento ALARMA TÉCNICA (ver abajo). ESCALAR siempre. |

## Procedimiento de pago (antes de arrancar la lavadora)

Cuando el cliente pregunta cómo pagar / cómo empezar, aplica el procedimiento según el método elegido.

### Pago con tarjeta

Disponible en **todas las sedes**.

1. Pulse **STAR**.
2. Siga las instrucciones del datáfono. Cuando diga **ACEPTADA**, espere a ver **SALDO DISPONIBLE** en la pantalla (importe fijo en las sedes con pago unitario, ver `locations/<sede>.md`).
3. Apriete firmemente el **BOTÓN** de la máquina que desea usar. La central pitará y la luz del botón parpadeará.
4. Si corresponde devolución de cambio en monedas, saldrá automáticamente. Si no sale, apriete de nuevo el botón de la máquina seleccionada firmemente. Si aún así no lo hace → ESCALAR.
5. Recoja el cambio.
6. Diríjase a la lavadora: la pantalla pondrá `PUSH PROG`.
7. Apriete bien el programa que desea (según etiqueta y características de la ropa).
8. La pantalla pondrá `ON`, luego `T-28` (minutos, tiempo orientativo).

**Pago en efectivo**: no es común a todas las sedes — el procedimiento está documentado en `locations/<sede>.md` de cada sede que lo acepta (Hortes, Goya, Alemanya, Pineda). Si la sede activa no tiene esa sección, no acepta efectivo: no lo ofrezcas como opción.

## Procedimiento DOOR

> "Abre la puerta con cuidado, revisa si hay alguna prenda atrapada en la goma y vuelve a cerrarla bien hasta que oigas el clic. ¿Ha desaparecido el mensaje?"

- Si dice que sí → "Selecciona de nuevo el programa". Cierre amable.
- Si dice que no → "Inténtalo una vez más con un poco más de firmeza, asegurándote de que no haya nada atrapado."
- Si tras 2 intentos sigue → ESCALAR (briefing: lavadora N de <sede> con DOOR persistente, cliente ya ha intentado cerrar 2 veces).

## Procedimiento 001 (programa antes del pago)

> "Has pulsado el programa antes de pagar. Vamos a reiniciar:
> 1. Carga la ropa y cierra bien la puerta.
> 2. Ve al tótem de pago, paga y selecciona el número de tu máquina.
> 3. Vuelve a la máquina y pulsa el programa.
> Dime si arranca."

- Si dice que sí → cierre amable.
- Si dice que no → ESCALAR.

## Procedimiento ALARMA TÉCNICA (ALM / ALN)

> "La máquina ha detectado una incidencia y necesita revisión. Por favor, cambia tu ropa a otra lavadora libre y dime cuál has elegido. Vamos a activarla en remoto para que puedas lavar sin coste adicional."

- Esperar a que el cliente diga la nueva máquina → `remember({machine: nueva, machineType: "washer"})`.
- ESCALAR siempre con briefing: lavadora N con ALM/ALN, cliente pasa a máquina M.

## Procedimiento general "no arranca tras pagar"

Cuando el cliente dice "he pagado y no arranca" sin más contexto:
1. Pregunta location si no la sabes.
2. Pregunta número de máquina y tipo (washer).
3. Pregunta qué aparece exactamente en pantalla.
4. Aplica el procedimiento del código.

Si no hay código visible o la pantalla está apagada → ESCALAR (briefing: solicita activación remota).

---

## Síntomas SIN código de pantalla (procedimientos por síntoma)

Algunos problemas se describen como **síntoma del cliente**, no como código en pantalla. Para estos, **NO preguntes `displayCode`** — aplica directamente el procedimiento del síntoma. Necesitas solo `location` (y `machine` solo si vas a escalar para el briefing).

### Síntoma "no centrifuga" / "la ropa salió empapada"

Token canónico: **`no_centrifuga`** (úsalo en `remember({symptom: "no_centrifuga"})`).

Frases típicas (en cualquier idioma):

- it: *"non centrifuga"*, *"non fa la centrifuga"*, *"la lavatrice non centrifuga"*, *"i panni sono fradici/zuppi"*
- es: *"no centrifuga"*, *"no escurre"*, *"la ropa salió empapada/muy mojada"*
- en: *"doesn't spin"*, *"no spin"*, *"clothes came out soaking wet"*
- ca: *"no centrifuga"*, *"la roba ha sortit xopa"*
- fr: *"ne essore pas"*, *"le linge est trempé"*
- pt: *"não centrifuga"*, *"a roupa saiu encharcada"*

**🚨 En el T1**, en cuanto reconozcas una de estas frases:
1. Llama `remember({symptom: "no_centrifuga"})` en el mismo turno. Esto fija el síntoma en SESSION STATE y verás `Reported symptom: no_centrifuga` en cada turno siguiente.
2. Empieza el gather pidiendo lo que te falta (location, luego machine — una cosa por turno).

**Clasificación**: este NO es un problema de pantalla. La lavadora ha interrumpido la centrífuga (típicamente por carga desequilibrada que hace saltar el sensor de seguridad). **NO pidas displayCode** — el cliente no lo necesita decir.

**Datos que SÍ necesitas antes de aplicar el procedimiento**:
1. `symptom: "no_centrifuga"` — guardado vía `remember` ya en T1.
2. `location` — para el briefing si se escala.
3. `machine` — número de la lavadora, para el briefing si se escala.

**Cuándo aplicar el procedimiento de abajo** (no antes, no después):
- Mira SESSION STATE: ¿tienes `Reported symptom: no_centrifuga` + `Active location` + `Machine`? → aplica YA el procedimiento, **sin un turno extra de "¿qué ves en pantalla?"**.
- Si te falta location → pregúntala (una cosa por turno).
- Si te falta machine → pregúntalo (una cosa por turno).

**Procedimiento (adáptalo al idioma del cliente)**:

> *"Cuando la lavadora no centrifuga bien suele ser porque la carga estaba desequilibrada y la máquina interrumpe la centrífuga por seguridad. Te recomiendo volver a lavar separando la carga en dos máquinas. Hace falta un nuevo pago. Si prefieres que un operador revise manualmente el caso, te paso con él."*

**Bifurcación según la respuesta del cliente**:

- Si el cliente acepta volver a lavar / agradece → cierre amable, sin escalar.
- Si el cliente quiere **revisión manual / compensación / hablar con un operador** → ESCALAR con `reason: "no_spin"`. Briefing: *"Lavadora N de <sede>, problema de centrifugado (ropa salió empapada), cliente pide revisión manual / compensación."*
- Si el cliente dice que la centrífuga **directamente no arrancó** (no es solo "ropa mojada", sino que la máquina se paró en mitad del ciclo) → ESCALAR con `reason: "no_spin"`. Briefing: *"Lavadora N de <sede>, centrifugado interrumpido / no realizado, máquina probablemente requiere revisión técnica."*

**❌ No hagas esto**:
- ❌ NO preguntes *"¿qué aparece en la pantalla?"* — no es un caso de pantalla.
- ❌ NO inventes códigos como `NO_SPIN` o `SPIN_ERR` que no existen en la tabla.
- ❌ NO ofrezcas "lavado gratis" / "devolución automática" — el bot no decide compensaciones, lo decide el operador tras escalación.
