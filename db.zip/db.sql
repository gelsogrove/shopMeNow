--
-- PostgreSQL database dump
--

\restrict 8TF43pPyANHAPOQiP0Kj2eR7EU8stHHT8pzI3fgYZUdOBtTjNfdrkPmHiwJU0D2

-- Dumped from database version 18.1 (Debian 18.1-1.pgdg13+2)
-- Dumped by pg_dump version 18.1 (Debian 18.1-1.pgdg13+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

-- *not* creating schema, since initdb creates it


--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS '';


--
-- Name: AgentType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."AgentType" AS ENUM (
    'ROUTER',
    'OPERATOR',
    'PRODUCT_SEARCH',
    'CART_MANAGEMENT',
    'ORDER_TRACKING',
    'CUSTOMER_SUPPORT',
    'INFO_AGENT',
    'SUMMARY_AGENT',
    'PROFILE_MANAGEMENT',
    'NOTIFICATIONS',
    'CONVERSATION_HISTORY',
    'SAFETY_TRANSLATION',
    'SECURITY',
    'TRANSLATION',
    'CUSTOM'
);


--
-- Name: AttachmentKind; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."AttachmentKind" AS ENUM (
    'IMAGE',
    'DOCUMENT',
    'AUDIO'
);


--
-- Name: BillingType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."BillingType" AS ENUM (
    'MONTHLY_CHANNEL',
    'MESSAGE',
    'NEW_CUSTOMER',
    'NEW_ORDER',
    'PUSH_CAMPAIGN',
    'FEEDBACK',
    'ORDER_REVIEW',
    'CAMPAIGN_LINK'
);


--
-- Name: CampaignFrequency; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."CampaignFrequency" AS ENUM (
    'ONCE',
    'WEEKLY',
    'BIWEEKLY',
    'MONTHLY',
    'BIMONTHLY',
    'QUARTERLY',
    'SEMIANNUAL',
    'ANNUAL',
    'ON_STAY_END'
);


--
-- Name: CampaignTargetType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."CampaignTargetType" AS ENUM (
    'ALL',
    'MANUAL',
    'TAGS',
    'SELECTED'
);


--
-- Name: ChannelMode; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ChannelMode" AS ENUM (
    'ECOMMERCE',
    'INFORMATIONAL',
    'FLOW',
    'PRO_LOCO'
);


--
-- Name: ChannelType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ChannelType" AS ENUM (
    'WHATSAPP',
    'WIDGET',
    'TELEGRAM',
    'MESSENGER',
    'LINE'
);


--
-- Name: ConfigType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ConfigType" AS ENUM (
    'PRICE',
    'FLAG',
    'LIMIT',
    'TEXT'
);


--
-- Name: InvitationStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."InvitationStatus" AS ENUM (
    'PENDING',
    'ACCEPTED',
    'CANCELLED',
    'EXPIRED'
);


--
-- Name: InvoiceStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."InvoiceStatus" AS ENUM (
    'DRAFT',
    'PENDING',
    'PAID',
    'FAILED',
    'CANCELLED'
);


--
-- Name: ItemType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ItemType" AS ENUM (
    'PRODUCT',
    'SERVICE'
);


--
-- Name: MessageDirection; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."MessageDirection" AS ENUM (
    'INBOUND',
    'OUTBOUND'
);


--
-- Name: MessageType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."MessageType" AS ENUM (
    'TEXT',
    'IMAGE',
    'DOCUMENT',
    'LOCATION',
    'CONTACT'
);


--
-- Name: OrderStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."OrderStatus" AS ENUM (
    'PENDING',
    'CONFIRMED',
    'PROCESSING',
    'SHIPPED',
    'DELIVERED',
    'CANCELLED'
);


--
-- Name: PayPalStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."PayPalStatus" AS ENUM (
    'DISCONNECTED',
    'CONNECTED'
);


--
-- Name: PayPalTransactionStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."PayPalTransactionStatus" AS ENUM (
    'SUCCESS',
    'FAILED'
);


--
-- Name: PaymentMethod; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."PaymentMethod" AS ENUM (
    'CREDIT_CARD',
    'DEBIT_CARD',
    'BANK_TRANSFER',
    'PAYPAL',
    'CASH_ON_DELIVERY',
    'CRYPTO'
);


--
-- Name: PaymentStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."PaymentStatus" AS ENUM (
    'PENDING',
    'COMPLETED',
    'FAILED',
    'REFUNDED',
    'PARTIALLY_PAID'
);


--
-- Name: PlanType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."PlanType" AS ENUM (
    'FREE_TRIAL',
    'BASIC',
    'PREMIUM',
    'ENTERPRISE'
);


--
-- Name: ProductStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ProductStatus" AS ENUM (
    'ACTIVE',
    'INACTIVE',
    'DRAFT',
    'OUT_OF_STOCK'
);


--
-- Name: PushCampaignBillingStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."PushCampaignBillingStatus" AS ENUM (
    'PENDING',
    'PARTIAL',
    'BILLED',
    'FAILED'
);


--
-- Name: PushCampaignChannel; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."PushCampaignChannel" AS ENUM (
    'WHATSAPP'
);


--
-- Name: PushCampaignRecipientStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."PushCampaignRecipientStatus" AS ENUM (
    'PENDING',
    'SENT',
    'FAILED',
    'SKIPPED'
);


--
-- Name: PushCampaignStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."PushCampaignStatus" AS ENUM (
    'DRAFT',
    'SCHEDULED',
    'RUNNING',
    'PAUSED',
    'COMPLETED',
    'FAILED',
    'CANCELLED'
);


--
-- Name: RegistrationStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."RegistrationStatus" AS ENUM (
    'NEW',
    'PENDING_APPROVAL',
    'ACTIVE'
);


--
-- Name: SearchConversationState; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."SearchConversationState" AS ENUM (
    'ACTIVE',
    'COMPLETED',
    'ABANDONED',
    'EXPIRED'
);


--
-- Name: SubscriptionStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."SubscriptionStatus" AS ENUM (
    'ACTIVE',
    'PAUSE_PENDING',
    'PAUSED',
    'PAYMENT_FAILED',
    'CANCELLED'
);


--
-- Name: SupportIssueType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."SupportIssueType" AS ENUM (
    'ACCOUNT_ISSUE',
    'PLAN_AND_BILLING',
    'WHATSAPP',
    'WIDGET',
    'SALES_AGENT',
    'SUPPORT',
    'OTHER'
);


--
-- Name: SupportSenderType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."SupportSenderType" AS ENUM (
    'CUSTOMER',
    'ADMIN'
);


--
-- Name: SupportTicketStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."SupportTicketStatus" AS ENUM (
    'PENDING',
    'IN_PROGRESS',
    'CLOSED'
);


--
-- Name: TouristContentType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."TouristContentType" AS ENUM (
    'RESTAURANT',
    'HOTEL',
    'EXCURSION',
    'REFUGE',
    'EVENT',
    'APARTMENT',
    'SPORTS_FACILITY',
    'SKI_FACILITY',
    'CHURCH',
    'CASTLE',
    'VIEWPOINT',
    'VENUE'
);


--
-- Name: TransactionType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."TransactionType" AS ENUM (
    'MESSAGE',
    'NEW_ORDER',
    'PUSH_NOTIFICATION',
    'APPOINTMENT_REMINDER',
    'RECHARGE',
    'MONTHLY_FEE',
    'UPGRADE_FEE',
    'ADJUSTMENT',
    'INITIAL_CREDIT',
    'BONUS',
    'INVOICE_PAID'
);


--
-- Name: UserRole; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."UserRole" AS ENUM (
    'ADMIN',
    'OWNER',
    'MEMBER'
);


--
-- Name: UserStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."UserStatus" AS ENUM (
    'ACTIVE',
    'INACTIVE'
);


--
-- Name: WorkspaceStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."WorkspaceStatus" AS ENUM (
    'ACTIVE',
    'INACTIVE',
    'SUSPENDED'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Billing; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Billing" (
    id text NOT NULL,
    "workspaceId" text NOT NULL,
    "customerId" text,
    amount numeric(10,2) NOT NULL,
    type public."BillingType" NOT NULL,
    description text NOT NULL,
    "userQuery" text,
    "previousTotal" numeric(10,2) DEFAULT 0 NOT NULL,
    "currentCharge" numeric(10,2) DEFAULT 0 NOT NULL,
    "newTotal" numeric(10,2) DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: Certification; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Certification" (
    id text NOT NULL,
    name text NOT NULL,
    "workspaceId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: ProductCategory; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ProductCategory" (
    "productId" text NOT NULL,
    "categoryId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: ProductCertification; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ProductCertification" (
    "productId" text NOT NULL,
    "certificationId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: ProductCharacteristic; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ProductCharacteristic" (
    id text NOT NULL,
    "productId" text NOT NULL,
    name text NOT NULL,
    value text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: ProductType; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ProductType" (
    "productId" text NOT NULL,
    "typeId" text NOT NULL
);


--
-- Name: ShortUrls; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ShortUrls" (
    id text NOT NULL,
    "shortCode" character varying(10) NOT NULL,
    "originalUrl" text NOT NULL,
    "workspaceId" text NOT NULL,
    clicks integer DEFAULT 0 NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "expiresAt" timestamp(3) without time zone,
    "lastAccessedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: Type; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Type" (
    id text NOT NULL,
    name text NOT NULL,
    "workspaceId" text NOT NULL,
    price numeric(10,2) DEFAULT 0 NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: UserWorkspace; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."UserWorkspace" (
    "userId" text NOT NULL,
    "workspaceId" text NOT NULL,
    role text DEFAULT 'ADMIN'::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: Workspace; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Workspace" (
    id text NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    "whatsappPhoneNumber" text,
    "whatsappApiKey" text,
    "whatsappPhoneNumberId" text,
    "whatsappVerifyToken" text,
    "notificationEmail" text,
    "webhookUrl" text,
    "webhookSecret" text,
    "webhookTimeout" integer DEFAULT 10000,
    language text DEFAULT 'ENG'::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedAt" timestamp(3) without time zone,
    currency text DEFAULT 'EUR'::text NOT NULL,
    "defaultLanguage" text DEFAULT 'en'::text NOT NULL,
    "channelStatus" boolean DEFAULT true NOT NULL,
    description text,
    "messageLimit" integer DEFAULT 50 NOT NULL,
    url text,
    "welcomeMessage" text DEFAULT 'Welcome! I''m {{chatbotName}}, your digital assistant. How can I help you today?'::text,
    "enableWelcomeMessage" boolean DEFAULT true NOT NULL,
    "sessionResetTimeout" integer DEFAULT 3600 NOT NULL,
    "wipMessage" text DEFAULT 'Work in progress. Please contact us later.'::text,
    "afterRegistrationMessages" text DEFAULT 'Thank you for registering, {{customerName}}! How can I help you today? Would you like to see your orders? The offers? Or do you need other information?'::text,
    "debugMode" boolean DEFAULT false NOT NULL,
    "apiKey" text,
    metadata jsonb,
    "allowedExternalLinks" text[] DEFAULT ARRAY[]::text[],
    "logoUrl" text,
    "logoKey" text,
    "websiteUrl" text,
    "widgetLogoUrl" text,
    "widgetLogoKey" text,
    "widgetTitle" text,
    "widgetLanguage" text DEFAULT 'en'::text,
    "widgetPrimaryColor" text DEFAULT '#22c55e'::text,
    "widgetTextColor" text DEFAULT '#0f172a'::text,
    "widgetIcon" text DEFAULT 'chat'::text,
    "widgetUseChannelLogo" boolean DEFAULT false NOT NULL,
    "widgetAutoSuggestionsEnabled" boolean DEFAULT false NOT NULL,
    "widgetQuickReplies" text[] DEFAULT ARRAY[]::text[],
    "widgetSuggestionsModel" text,
    "channelType" public."ChannelType" DEFAULT 'WHATSAPP'::public."ChannelType" NOT NULL,
    "enableWhatsapp" boolean DEFAULT true NOT NULL,
    "enableWidget" boolean DEFAULT false NOT NULL,
    "channelMode" public."ChannelMode" DEFAULT 'INFORMATIONAL'::public."ChannelMode" NOT NULL,
    "enableCalendarBooking" boolean DEFAULT false NOT NULL,
    "hasSalesAgents" boolean DEFAULT false NOT NULL,
    "hasHumanSupport" boolean DEFAULT true NOT NULL,
    "hasProductCatalog" boolean DEFAULT true NOT NULL,
    "hasCart" boolean DEFAULT true NOT NULL,
    "hasOrderTracking" boolean DEFAULT true NOT NULL,
    "needRegistration" boolean DEFAULT true NOT NULL,
    "humanSupportInstructions" text,
    "operatorContactMethod" text DEFAULT 'email'::text,
    "operatorEmail" text,
    "operatorWhatsappNumber" text,
    "toneOfVoice" text DEFAULT 'friendly'::text,
    "whatsappProvider" text DEFAULT 'wasender'::text NOT NULL,
    "metaPhoneNumberId" text,
    "metaAccessToken" text,
    "webhookVerifyToken" text,
    "ultraMsgInstanceId" text,
    "ultraMsgToken" text,
    "ultraMsgApiUrl" text,
    "wasenderSessionId" text,
    "wasenderApiKey" text,
    "wasenderSessionStatus" text,
    "wasenderPhoneNumber" text,
    "wasenderQrString" text,
    "wasenderQrGeneratedAt" timestamp(3) without time zone,
    "wasenderIsActive" boolean DEFAULT false NOT NULL,
    "botIdentityResponse" text,
    "customAiRules" text,
    address text,
    "chatbotName" text DEFAULT 'Assistente'::text,
    "businessType" text DEFAULT 'other'::text,
    "customChatbotId" text,
    "registrationPage" text,
    "requireManualApproval" boolean DEFAULT false NOT NULL,
    "approvalMessage" text,
    "translateProductNames" boolean DEFAULT false NOT NULL,
    "translateCategoryNames" boolean DEFAULT false NOT NULL,
    "translateServiceNames" boolean DEFAULT true NOT NULL,
    "catalogBaseLanguage" text DEFAULT 'it'::text NOT NULL,
    "ownerId" text,
    timezone text DEFAULT 'Europe/Rome'::text,
    "appointmentReminder24hEnabled" boolean DEFAULT true NOT NULL,
    "appointmentReminder24hMessage" text DEFAULT 'Hi {{customerName}}, reminder: your {{appointmentType}} appointment is tomorrow {{appointmentDate}} at {{appointmentTime}}. Confirm your presence?'::text,
    "appointmentReminder1hEnabled" boolean DEFAULT true NOT NULL,
    "appointmentReminder1hMessage" text DEFAULT 'Hi {{customerName}}, your {{appointmentType}} appointment starts in 1 hour at {{appointmentTime}}. See you soon!'::text,
    "appointmentReminder30mEnabled" boolean DEFAULT false NOT NULL,
    "appointmentReminder30mMessage" text DEFAULT 'Hi {{customerName}}, your {{appointmentType}} appointment starts in 30 minutes at {{appointmentTime}}. We''re waiting for you!'::text,
    "appointmentReminderChannel" text DEFAULT 'whatsapp'::text NOT NULL,
    "appointmentReminderHours" integer[] DEFAULT ARRAY[24, 1],
    "minBookingBufferHours" integer DEFAULT 12 NOT NULL,
    "zoomAccessToken" text,
    "zoomRefreshToken" text,
    "zoomConnected" boolean DEFAULT false NOT NULL,
    "zoomUserId" text,
    "customChatbotMaxTokens" integer,
    "audioOutput" boolean DEFAULT false NOT NULL,
    "audioVoices" jsonb,
    "operatorEmails" text[] DEFAULT '{}'::text[] NOT NULL,
    "operatorWhatsappNumbers" text[] DEFAULT '{}'::text[] NOT NULL,
    "operatorDeliveryMode" text DEFAULT 'all'::text,
    "faqsEnabled" boolean DEFAULT true NOT NULL,
    "flowsEnabled" boolean DEFAULT true NOT NULL,
    "escalationTrigger" text,
    "customChatbotSystemPrompt" text,
    "enabledLanguages" text[] DEFAULT ARRAY[]::text[] NOT NULL,
    "termsAndConditions" text,
    "translateCustomerMessages" boolean DEFAULT true NOT NULL,
    "frustrationTriggers" text,
    "customChatbotModel" text,
    "customChatbotTemperature" double precision,
    "customChatbotOperatorBriefingLanguage" text,
    "customChatbotOperatorEmail" text,
    "customChatbotEmailFrom" text,
    "customChatbotEmailSubjectPrefix" text,
    "customChatbotAudioOutput" boolean,
    "customChatbotAudioVoices" jsonb,
    "welcomeBackMessage" text DEFAULT 'Welcome back, {{customerName}}! How can I help you today?'::text,
    "humanSupportMessage" text DEFAULT 'Hi {{customerName}}, I''m putting you in touch with our operator as soon as possible.'::text,
    "customChatbotAdvancedSettings" jsonb,
    "speechToTextEnabled" boolean DEFAULT false NOT NULL,
    "taxRate" numeric(5,4) DEFAULT 0.22 NOT NULL,
    "wasenderWebhookSecret" text,
    "securityBlockedMessage" text,
    "videoUrl" text,
    "widgetErrorMessage" text
);


--
-- Name: _OfferCategories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."_OfferCategories" (
    "A" text NOT NULL,
    "B" text NOT NULL
);


--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


--
-- Name: admin_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.admin_sessions (
    id text NOT NULL,
    "sessionId" character varying(64) NOT NULL,
    "userId" text NOT NULL,
    "workspaceId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "lastActivityAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "ipAddress" character varying(45),
    "userAgent" text,
    "isActive" boolean DEFAULT true NOT NULL
);


--
-- Name: agent_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_configs (
    id text NOT NULL,
    "workspaceId" text NOT NULL,
    name text NOT NULL,
    type public."AgentType" NOT NULL,
    description text,
    icon text,
    "systemPrompt" text NOT NULL,
    model text DEFAULT 'openai/gpt-4o-mini'::text NOT NULL,
    temperature double precision DEFAULT 0.7 NOT NULL,
    "maxTokens" integer DEFAULT 4096 NOT NULL,
    "order" integer DEFAULT 0 NOT NULL,
    "availableFunctions" jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: agent_conversation_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_conversation_logs (
    id text NOT NULL,
    "workspaceId" text NOT NULL,
    "customerId" text NOT NULL,
    "conversationId" text NOT NULL,
    "messageId" text NOT NULL,
    step integer NOT NULL,
    "agentType" text NOT NULL,
    "agentAction" text NOT NULL,
    "inputMessage" text NOT NULL,
    "agentPrompt" text,
    "llmModel" text,
    "llmResponse" text NOT NULL,
    confidence double precision,
    reasoning text,
    "tokensUsed" integer,
    "executionTimeMs" integer,
    "functionsCalled" jsonb,
    "hasError" boolean DEFAULT false NOT NULL,
    "errorMessage" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: appointments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.appointments (
    id text NOT NULL,
    "workspaceId" text NOT NULL,
    "customerId" text NOT NULL,
    "serviceId" text NOT NULL,
    "startTime" timestamp(3) without time zone NOT NULL,
    "endTime" timestamp(3) without time zone NOT NULL,
    timezone text DEFAULT 'Europe/Rome'::text NOT NULL,
    "googleEventId" text,
    "googleEventLink" text,
    "googleCalendarId" text,
    "zoomLink" text,
    "zoomMeetingId" text,
    status text DEFAULT 'confirmed'::text NOT NULL,
    "cancelledAt" timestamp(3) without time zone,
    "cancellationReason" text,
    "cancelledBy" text,
    "customerName" text,
    "customerPhone" text,
    "customerEmail" text,
    "customerNotes" text,
    "adminNotes" text,
    "bookedVia" text DEFAULT 'whatsapp'::text NOT NULL,
    "reminder24hSentAt" timestamp(3) without time zone,
    "reminder1hSentAt" timestamp(3) without time zone,
    "reminder30mSentAt" timestamp(3) without time zone,
    "reminderChannel" text,
    "reminderBilledAt" timestamp(3) without time zone,
    "reminderBillingTotal" numeric(10,2) DEFAULT 0,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: authentication_attempts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.authentication_attempts (
    id text NOT NULL,
    "userId" text,
    email text NOT NULL,
    "attemptType" text NOT NULL,
    success boolean NOT NULL,
    "failureReason" text,
    "ipAddress" character varying(45),
    "userAgent" text,
    metadata jsonb,
    "timestamp" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: billing_transactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.billing_transactions (
    id text NOT NULL,
    "userId" text NOT NULL,
    "workspaceId" text,
    type public."TransactionType" NOT NULL,
    amount numeric(10,2) NOT NULL,
    "balanceAfter" numeric(10,2) NOT NULL,
    description text NOT NULL,
    "referenceId" text,
    "referenceType" text,
    metadata jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: blackout_periods; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.blackout_periods (
    id text NOT NULL,
    "workspaceId" text NOT NULL,
    "startDate" timestamp(3) without time zone NOT NULL,
    "endDate" timestamp(3) without time zone NOT NULL,
    reason text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: cart_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cart_items (
    id text NOT NULL,
    "itemType" public."ItemType" DEFAULT 'PRODUCT'::public."ItemType" NOT NULL,
    quantity integer NOT NULL,
    notes text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "cartId" text NOT NULL,
    "productId" text,
    "serviceId" text
);


--
-- Name: carts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.carts (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "customerId" text NOT NULL,
    "workspaceId" text NOT NULL
);


--
-- Name: categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categories (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "workspaceId" text NOT NULL,
    slug text NOT NULL
);


--
-- Name: chat_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chat_sessions (
    id text NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    context jsonb DEFAULT '{}'::jsonb,
    "startedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "endedAt" timestamp(3) without time zone,
    "escalatedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedAt" timestamp(3) without time zone,
    "workspaceId" text NOT NULL,
    "customerId" text NOT NULL,
    "isAnonymous" boolean DEFAULT false NOT NULL,
    "visitorId" text,
    "expiresAt" timestamp(3) without time zone,
    channel text DEFAULT 'whatsapp'::text NOT NULL,
    "isPlayground" boolean DEFAULT false NOT NULL,
    title text,
    feedback text,
    "sortOrder" integer
);


--
-- Name: conversation_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.conversation_messages (
    id text NOT NULL,
    "workspaceId" text NOT NULL,
    "customerId" text NOT NULL,
    "conversationId" text NOT NULL,
    role text NOT NULL,
    content text NOT NULL,
    "agentType" text,
    "functionName" text,
    "functionArguments" jsonb,
    "tokensUsed" integer,
    "debugInfo" text,
    "deliveredAt" timestamp(3) without time zone,
    "deliveryStatus" text DEFAULT 'not_queued'::text NOT NULL,
    reaction text,
    "whatsappMessageId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: credit_notes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.credit_notes (
    id text NOT NULL,
    "creditNoteCode" text NOT NULL,
    "orderId" text NOT NULL,
    amount numeric(10,2) NOT NULL,
    reason text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "createdById" text
);


--
-- Name: customer_feedback; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.customer_feedback (
    id text NOT NULL,
    "workspaceId" text NOT NULL,
    "customerId" text NOT NULL,
    rating integer,
    comment text,
    "stayKey" text,
    "arrivalDate" text,
    "departureDate" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: customers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.customers (
    id text NOT NULL,
    name text NOT NULL,
    email text,
    phone text,
    "customId" text,
    address text,
    company text,
    discount double precision DEFAULT 0,
    language text DEFAULT 'en'::text,
    currency text DEFAULT 'EUR'::text,
    notes text,
    tags text[] DEFAULT ARRAY[]::text[],
    "serviceIds" text[] DEFAULT ARRAY[]::text[],
    "isBlacklisted" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedAt" timestamp(3) without time zone,
    "isActive" boolean DEFAULT false NOT NULL,
    "registrationStatus" public."RegistrationStatus" DEFAULT 'NEW'::public."RegistrationStatus" NOT NULL,
    "workspaceId" text NOT NULL,
    last_privacy_version_accepted text,
    privacy_accepted_at timestamp(3) without time zone,
    push_notifications_consent boolean DEFAULT false NOT NULL,
    push_notifications_consent_at timestamp(3) without time zone,
    "activeChatbot" boolean DEFAULT true NOT NULL,
    "operatorRequestedAt" timestamp(3) without time zone,
    "originChannel" text,
    "operatorQueuePosition" integer,
    "operatorQueueEnteredAt" timestamp(3) without time zone,
    "invoiceAddress" jsonb,
    "salesId" text,
    "maxActiveAppointments" integer DEFAULT 5,
    "lastAppointmentDate" timestamp(3) without time zone,
    "stayProfile" jsonb,
    "feedbackRating" integer,
    "feedbackComment" text,
    "feedbackAt" timestamp(3) without time zone
);


--
-- Name: demorobot_assets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.demorobot_assets (
    id text NOT NULL,
    "flowCategoryId" text CONSTRAINT "demorobot_assets_robotModelId_not_null" NOT NULL,
    type text NOT NULL,
    url text NOT NULL,
    title text NOT NULL,
    summary text,
    language text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: demorobot_flow_edges; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.demorobot_flow_edges (
    id text NOT NULL,
    "sourceNodeId" text NOT NULL,
    "targetNodeId" text,
    label text NOT NULL,
    "triggersEscalation" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "targetFlowId" text
);


--
-- Name: demorobot_flow_node_attachments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.demorobot_flow_node_attachments (
    "nodeId" text NOT NULL,
    "assetId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: demorobot_flow_nodes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.demorobot_flow_nodes (
    id text NOT NULL,
    "flowId" text NOT NULL,
    question text NOT NULL,
    "positionX" double precision DEFAULT 0 NOT NULL,
    "positionY" double precision DEFAULT 0 NOT NULL,
    "fieldKey" text,
    "fieldType" text,
    "terminalType" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: demorobot_flows; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.demorobot_flows (
    id text NOT NULL,
    "workspaceId" text NOT NULL,
    "flowCategoryId" text,
    title text NOT NULL,
    description text,
    keywords text[] DEFAULT ARRAY[]::text[] NOT NULL,
    "retrievalDocument" text NOT NULL,
    embedding double precision[] DEFAULT ARRAY[]::double precision[] NOT NULL,
    "compiledPrompt" text NOT NULL,
    hash text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "isProtected" boolean DEFAULT false NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL
);


--
-- Name: faqs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.faqs (
    id text NOT NULL,
    "workspaceId" text NOT NULL,
    question text NOT NULL,
    answer text NOT NULL,
    keywords text[],
    category text,
    "order" integer DEFAULT 0 NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: flow_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.flow_categories (
    id text CONSTRAINT robot_models_id_not_null NOT NULL,
    "workspaceId" text CONSTRAINT "robot_models_workspaceId_not_null" NOT NULL,
    name text CONSTRAINT robot_models_name_not_null NOT NULL,
    slug text CONSTRAINT robot_models_slug_not_null NOT NULL,
    description text,
    "lookupRules" jsonb DEFAULT '{}'::jsonb CONSTRAINT "robot_models_lookupRules_not_null" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP CONSTRAINT "robot_models_createdAt_not_null" NOT NULL,
    "updatedAt" timestamp(3) without time zone CONSTRAINT "robot_models_updatedAt_not_null" NOT NULL
);


--
-- Name: flow_node_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.flow_node_configs (
    id text NOT NULL,
    "workspaceId" text NOT NULL,
    "flowKey" text NOT NULL,
    "flowLabel" text NOT NULL,
    "systemPrompt" text DEFAULT ''::text NOT NULL,
    model text DEFAULT 'openai/gpt-4o-mini'::text NOT NULL,
    temperature double precision DEFAULT 0.3 NOT NULL,
    "maxTokens" integer DEFAULT 2048 NOT NULL,
    "availableFunctions" jsonb DEFAULT '[]'::jsonb NOT NULL,
    flows jsonb DEFAULT '{}'::jsonb NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: gdpr_content; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.gdpr_content (
    id text NOT NULL,
    "workspaceId" text NOT NULL,
    gdpr_ita text NOT NULL,
    gdpr_esp text NOT NULL,
    gdpr_eng text NOT NULL,
    gdpr_prt text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: google_calendar_connections; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.google_calendar_connections (
    id text NOT NULL,
    "workspaceId" text NOT NULL,
    "calendarId" text DEFAULT 'primary'::text NOT NULL,
    "accessToken" text NOT NULL,
    "refreshToken" text NOT NULL,
    "tokenExpiry" timestamp(3) without time zone NOT NULL,
    scope text[] DEFAULT ARRAY['https://www.googleapis.com/auth/calendar'::text],
    "connectedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "lastSyncAt" timestamp(3) without time zone,
    "isActive" boolean DEFAULT true NOT NULL,
    "errorMessage" text
);


--
-- Name: invoice_adjustments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.invoice_adjustments (
    id text NOT NULL,
    "invoiceId" text NOT NULL,
    "userId" text NOT NULL,
    amount numeric(10,2) NOT NULL,
    reason text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "createdById" text,
    "createdByEmail" text
);


--
-- Name: invoice_credit_notes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.invoice_credit_notes (
    id text NOT NULL,
    "invoiceId" text NOT NULL,
    "userId" text NOT NULL,
    amount numeric(10,2) NOT NULL,
    reason text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "createdById" text,
    "createdByEmail" text
);


--
-- Name: invoice_year_sequences; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.invoice_year_sequences (
    year integer NOT NULL,
    last_value integer DEFAULT 0 NOT NULL
);


--
-- Name: languages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.languages (
    id text NOT NULL,
    name text NOT NULL,
    code text NOT NULL,
    "isDefault" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "workspaceId" text NOT NULL
);


--
-- Name: late_cancellation_attempts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.late_cancellation_attempts (
    id text NOT NULL,
    "workspaceId" text NOT NULL,
    "customerId" text NOT NULL,
    "serviceId" text NOT NULL,
    "googleEventId" text,
    "scheduledStartTime" timestamp(3) without time zone NOT NULL,
    "attemptedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "tooLateThreshold" integer NOT NULL
);


--
-- Name: merchant_pushes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.merchant_pushes (
    id text NOT NULL,
    "workspaceId" text NOT NULL,
    "merchantId" text NOT NULL,
    title text NOT NULL,
    text text NOT NULL,
    "photoUrl" text,
    "videoUrl" text,
    location text,
    description text,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedAt" timestamp(3) without time zone,
    "photoBase64" text
);


--
-- Name: merchant_quota_topups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.merchant_quota_topups (
    id text NOT NULL,
    "workspaceId" text NOT NULL,
    "merchantId" text NOT NULL,
    amount integer NOT NULL,
    note text,
    "createdByUserId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: merchants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.merchants (
    id text NOT NULL,
    "workspaceId" text NOT NULL,
    name text NOT NULL,
    description text,
    location text,
    "billingName" text,
    "vatNumber" text,
    "taxCode" text,
    "sdiCode" text,
    pec text,
    "billingAddress" text,
    "billingCity" text,
    "billingZip" text,
    "billingProvince" text,
    "billingCountry" text DEFAULT 'IT'::text,
    "isActive" boolean DEFAULT true NOT NULL,
    "quotaRemaining" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedAt" timestamp(3) without time zone
);


--
-- Name: message_attachments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.message_attachments (
    id text NOT NULL,
    "conversationMessageId" text NOT NULL,
    "workspaceId" text NOT NULL,
    kind public."AttachmentKind" NOT NULL,
    url text NOT NULL,
    "storageKey" text NOT NULL,
    "mimeType" text NOT NULL,
    filename text,
    "sizeBytes" integer NOT NULL,
    width integer,
    height integer,
    "waMediaId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.messages (
    id text NOT NULL,
    direction public."MessageDirection" NOT NULL,
    content text NOT NULL,
    type public."MessageType" DEFAULT 'TEXT'::public."MessageType" NOT NULL,
    status text DEFAULT 'sent'::text NOT NULL,
    "aiGenerated" boolean DEFAULT false NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb,
    read boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedAt" timestamp(3) without time zone,
    "chatSessionId" text NOT NULL,
    "functionCallsDebug" text,
    "processingSource" text,
    "translatedQuery" text,
    "processedPrompt" text,
    "debugInfo" text,
    "whatsappStatus" text,
    "whatsappError" text,
    "whatsappMessageId" text,
    "sentBy" text
);


--
-- Name: messages_archive; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.messages_archive (
    id text NOT NULL,
    "originalId" text NOT NULL,
    direction public."MessageDirection" NOT NULL,
    content text NOT NULL,
    type public."MessageType" DEFAULT 'TEXT'::public."MessageType" NOT NULL,
    status text DEFAULT 'sent'::text NOT NULL,
    "aiGenerated" boolean DEFAULT false NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb,
    read boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "archivedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "chatSessionId" text NOT NULL,
    "workspaceId" text NOT NULL,
    "customerId" text NOT NULL,
    "functionCallsDebug" text,
    "processingSource" text,
    "translatedQuery" text,
    "processedPrompt" text,
    "debugInfo" text,
    "whatsappStatus" text,
    "whatsappError" text,
    "whatsappMessageId" text,
    "sentBy" text
);


--
-- Name: monthly_invoices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.monthly_invoices (
    id text NOT NULL,
    "userId" text NOT NULL,
    "invoiceNumber" text,
    "periodStart" timestamp(3) without time zone NOT NULL,
    "periodEnd" timestamp(3) without time zone NOT NULL,
    "periodMonth" integer NOT NULL,
    "periodYear" integer NOT NULL,
    "subscriptionAmount" numeric(10,2) NOT NULL,
    "creditUsage" numeric(10,2) NOT NULL,
    "creditDebt" numeric(10,2) DEFAULT 0 NOT NULL,
    "creditNotesTotal" numeric(10,2) DEFAULT 0 NOT NULL,
    "subtotalAmount" numeric(10,2) DEFAULT 0 NOT NULL,
    "taxRate" numeric(5,4) DEFAULT 0.22 NOT NULL,
    "taxAmount" numeric(10,2) DEFAULT 0 NOT NULL,
    "totalAmount" numeric(10,2) NOT NULL,
    status public."InvoiceStatus" DEFAULT 'DRAFT'::public."InvoiceStatus" NOT NULL,
    "paidAt" timestamp(3) without time zone,
    "paypalTransactionId" text,
    "paymentRetryCount" integer DEFAULT 0 NOT NULL,
    "adminNotes" text,
    "adminMarkedById" text,
    "adminMarkedAt" timestamp(3) without time zone,
    "planType" public."PlanType" NOT NULL,
    "itemsBreakdown" jsonb NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: offers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.offers (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    "discountPercent" double precision NOT NULL,
    "startDate" timestamp(3) without time zone NOT NULL,
    "endDate" timestamp(3) without time zone NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "categoryId" text,
    "workspaceId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: onboarding_questionnaires; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.onboarding_questionnaires (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "fullName" text,
    email text,
    phone text,
    company text,
    "stepIndustry" text,
    "stepGoal" text,
    "stepHumanSupport" text,
    "stepPushMarketing" text,
    "stepReminders" text,
    "stepWidget" text,
    "stepSalesAgents" text,
    "stepEcommerce" text,
    "stepEcommercePlatform" text,
    "stepIntegrations" text,
    "stepPrivacy" text,
    "stepOnPremise" text,
    "stepHelpful" text,
    "stepInterest" text,
    "stepOther" text,
    "stepDemo" text,
    lang text,
    "wantsContact" boolean DEFAULT false NOT NULL,
    "stepChannel" text,
    "stepTimeSaving" text,
    "stepDocuments" text,
    "stepIntegration" text,
    "stepHandoff" text,
    "stepMarketing" text,
    status text DEFAULT 'NEW'::text NOT NULL,
    "adminNotes" text
);


--
-- Name: order_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.order_items (
    id text NOT NULL,
    "itemType" public."ItemType" DEFAULT 'PRODUCT'::public."ItemType" NOT NULL,
    quantity integer DEFAULT 1 NOT NULL,
    "unitPrice" numeric(10,2) NOT NULL,
    "totalPrice" numeric(10,2) NOT NULL,
    "productVariant" jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedAt" timestamp(3) without time zone,
    "orderId" text NOT NULL,
    "productId" text,
    "serviceId" text
);


--
-- Name: orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.orders (
    id text NOT NULL,
    "orderCode" text NOT NULL,
    status public."OrderStatus" DEFAULT 'PENDING'::public."OrderStatus" NOT NULL,
    "paymentMethod" public."PaymentMethod",
    "paymentStatus" public."PaymentStatus" DEFAULT 'PENDING'::public."PaymentStatus",
    "totalAmount" numeric(10,2) NOT NULL,
    "shippingAmount" numeric(10,2) DEFAULT 0,
    "taxAmount" numeric(10,2) DEFAULT 0,
    "shippingAddress" jsonb,
    "billingAddress" jsonb,
    notes text,
    "discountCode" text,
    "discountAmount" numeric(10,2) DEFAULT 0,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedAt" timestamp(3) without time zone,
    "billedAt" timestamp(3) without time zone,
    "customerId" text NOT NULL,
    "workspaceId" text NOT NULL,
    "trackingNumber" text,
    "invoiceUrl" text,
    "invoiceKey" text,
    "invoiceDate" timestamp(3) without time zone
);


--
-- Name: password_resets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.password_resets (
    id text NOT NULL,
    "userId" text NOT NULL,
    token text NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "usedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: payment_details; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payment_details (
    id text NOT NULL,
    provider text NOT NULL,
    status text DEFAULT 'PENDING'::text NOT NULL,
    amount numeric(10,2) NOT NULL,
    currency text DEFAULT 'EUR'::text NOT NULL,
    "providerResponse" jsonb DEFAULT '{}'::jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "orderId" text NOT NULL
);


--
-- Name: paypal_transactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.paypal_transactions (
    id text NOT NULL,
    "userId" text NOT NULL,
    "invoiceId" text,
    amount numeric(10,2) NOT NULL,
    currency text DEFAULT 'EUR'::text NOT NULL,
    status public."PayPalTransactionStatus" NOT NULL,
    notes text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "adminUserId" text,
    "paypalOrderId" text
);


--
-- Name: paypal_webhook_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.paypal_webhook_events (
    id text NOT NULL,
    "eventId" text NOT NULL,
    "eventType" text,
    "receivedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: plan_configurations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.plan_configurations (
    id text NOT NULL,
    "planType" public."PlanType" NOT NULL,
    "displayName" text NOT NULL,
    "monthlyFee" numeric(10,2) NOT NULL,
    "maxChannels" integer NOT NULL,
    "maxProducts" integer NOT NULL,
    "maxCustomers" integer NOT NULL,
    max_team_members integer,
    "messageCost" numeric(10,2) NOT NULL,
    "orderCost" numeric(10,2) NOT NULL,
    "pushCost" numeric(10,2) NOT NULL,
    "reminderCost" numeric(10,2) DEFAULT 0.50 NOT NULL,
    "lowBalanceThreshold" numeric(10,2) NOT NULL,
    "trialDays" integer DEFAULT 0 NOT NULL,
    "initialCredit" numeric(10,2) DEFAULT 0 NOT NULL,
    features jsonb,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: platform_config; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.platform_config (
    id text NOT NULL,
    type public."ConfigType" NOT NULL,
    key text NOT NULL,
    value text NOT NULL,
    "originalValue" text,
    description text,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: playground_comments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.playground_comments (
    id text NOT NULL,
    "todoId" text NOT NULL,
    "commentText" text NOT NULL,
    "createdBy" text NOT NULL,
    color text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "authorKind" text DEFAULT 'STAFF'::text NOT NULL
);


--
-- Name: playground_todos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.playground_todos (
    id text NOT NULL,
    "workspaceId" text NOT NULL,
    "dialogId" text,
    "messageType" text,
    "messageContent" text,
    "chatbotResponse" text,
    "commentTitle" text NOT NULL,
    priority text DEFAULT 'MEDIUM'::text NOT NULL,
    status text DEFAULT 'TODO'::text NOT NULL,
    "position" integer DEFAULT 0 NOT NULL,
    "createdBy" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "authorKind" text DEFAULT 'STAFF'::text NOT NULL
);


--
-- Name: products; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.products (
    id text NOT NULL,
    name text NOT NULL,
    sku text,
    description text,
    formato text,
    price numeric(10,2) NOT NULL,
    stock integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "workspaceId" text NOT NULL,
    slug text NOT NULL,
    link character varying(120),
    status public."ProductStatus" DEFAULT 'ACTIVE'::public."ProductStatus" NOT NULL,
    "imageUrl" text[] DEFAULT ARRAY[]::text[],
    "imageKey" text,
    type text DEFAULT 'Temperatura ambiente'::text NOT NULL,
    region text,
    allergens text[] DEFAULT ARRAY[]::text[]
);


--
-- Name: push_campaign_recipients; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.push_campaign_recipients (
    id text NOT NULL,
    "campaignId" text NOT NULL,
    "workspaceId" text NOT NULL,
    "customerId" text,
    phone text NOT NULL,
    status public."PushCampaignRecipientStatus" DEFAULT 'PENDING'::public."PushCampaignRecipientStatus" NOT NULL,
    "errorCode" text,
    "errorMessage" text,
    "sentAt" timestamp(3) without time zone,
    "messageId" text,
    "priceCharged" numeric(10,2) DEFAULT 0 NOT NULL,
    "isBlacklisted" boolean DEFAULT false NOT NULL,
    "isBlocked" boolean DEFAULT false NOT NULL,
    "isFake" boolean DEFAULT false NOT NULL,
    "optOutAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "stayKey" text
);


--
-- Name: push_campaigns; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.push_campaigns (
    id text NOT NULL,
    "workspaceId" text NOT NULL,
    "createdByUserId" text,
    name text NOT NULL,
    status public."PushCampaignStatus" DEFAULT 'DRAFT'::public."PushCampaignStatus" NOT NULL,
    channel public."PushCampaignChannel" DEFAULT 'WHATSAPP'::public."PushCampaignChannel" NOT NULL,
    frequency public."CampaignFrequency" DEFAULT 'ONCE'::public."CampaignFrequency" NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "targetingType" public."CampaignTargetType" DEFAULT 'ALL'::public."CampaignTargetType" NOT NULL,
    "targetCustomerIds" text[] DEFAULT ARRAY[]::text[],
    "tagId" text,
    message text,
    "sendAt" timestamp(3) without time zone,
    "nextRunAt" timestamp(3) without time zone,
    "lastRunAt" timestamp(3) without time zone,
    "templateId" text,
    "templateLocale" text,
    "bodyPreview" text,
    "targetTags" text[] DEFAULT ARRAY[]::text[],
    "mediaUrl" text,
    "expectedRecipients" integer DEFAULT 0 NOT NULL,
    "actualSent" integer DEFAULT 0 NOT NULL,
    "actualFailed" integer DEFAULT 0 NOT NULL,
    "actualSkipped" integer DEFAULT 0 NOT NULL,
    "costPerMessage" numeric(10,2) DEFAULT 1.00 NOT NULL,
    "billingStatus" public."PushCampaignBillingStatus" DEFAULT 'PENDING'::public."PushCampaignBillingStatus" NOT NULL,
    "throttlePerSecond" integer DEFAULT 10 NOT NULL,
    "batchSize" integer DEFAULT 50 NOT NULL,
    "lastError" text,
    metadata jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "merchantId" text,
    "merchantPushId" text,
    "validFrom" timestamp(3) without time zone,
    "validTo" timestamp(3) without time zone,
    "sendWindowStart" integer DEFAULT 8 NOT NULL,
    "sendWindowEnd" integer DEFAULT 19 NOT NULL,
    "mediaBase64" text,
    "isSystem" boolean DEFAULT false NOT NULL,
    "stayEndSendHour" integer DEFAULT 10 NOT NULL,
    "stayEndDelayDays" integer DEFAULT 1 NOT NULL
);


--
-- Name: registration_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.registration_tokens (
    id text NOT NULL,
    token text NOT NULL,
    "phoneNumber" text NOT NULL,
    "workspaceId" text NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "usedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: reminder_locks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reminder_locks (
    id text NOT NULL,
    "workspaceId" text NOT NULL,
    "appointmentId" text NOT NULL,
    "googleEventId" text,
    "reminderType" text NOT NULL,
    "lockKey" text NOT NULL,
    "sentAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: sales; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sales (
    id text NOT NULL,
    "firstName" text NOT NULL,
    "lastName" text NOT NULL,
    email text NOT NULL,
    phone text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "workspaceId" text NOT NULL
);


--
-- Name: scheduler_job_status; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.scheduler_job_status (
    id text NOT NULL,
    "jobName" text NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "lastRunAt" timestamp(3) without time zone,
    "lastStatus" text DEFAULT 'NEVER_RUN'::text NOT NULL,
    "lastError" text,
    "lastDuration" integer,
    "nextRunAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: search_conversations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.search_conversations (
    id text NOT NULL,
    "sessionId" text NOT NULL,
    "workspaceId" text NOT NULL,
    "customerId" text NOT NULL,
    state public."SearchConversationState" DEFAULT 'ACTIVE'::public."SearchConversationState" NOT NULL,
    "activeAgent" public."AgentType",
    "lastQuery" text,
    "lastResponse" text,
    metadata jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: secure_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.secure_tokens (
    id text NOT NULL,
    token text NOT NULL,
    type text NOT NULL,
    "workspaceId" text NOT NULL,
    "userId" text,
    "phoneNumber" text,
    payload jsonb,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "usedAt" timestamp(3) without time zone,
    "ipAddress" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "customerId" text
);


--
-- Name: services; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.services (
    id text NOT NULL,
    code text NOT NULL,
    name text NOT NULL,
    description text NOT NULL,
    price numeric(10,2) NOT NULL,
    currency text DEFAULT 'EUR'::text NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "workspaceId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    duration integer DEFAULT 60 NOT NULL,
    "imageUrl" text[] DEFAULT ARRAY[]::text[],
    "imageKey" text,
    "enableForBooking" boolean DEFAULT false NOT NULL,
    "bufferTime" integer DEFAULT 0 NOT NULL,
    color text DEFAULT '#3b82f6'::text NOT NULL
);


--
-- Name: soft_delete_audit_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.soft_delete_audit_logs (
    id text NOT NULL,
    "workspaceId" text NOT NULL,
    "entityType" text NOT NULL,
    "deletedIds" text[],
    "deletedIdCount" integer NOT NULL,
    reason text,
    "deletedByUserId" text,
    "deletedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: support_attachments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.support_attachments (
    id text NOT NULL,
    "messageId" text NOT NULL,
    filename text NOT NULL,
    url text NOT NULL,
    "storageKey" text NOT NULL,
    "mimeType" text NOT NULL,
    size integer NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: support_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.support_messages (
    id text NOT NULL,
    "ticketId" text NOT NULL,
    "senderId" text NOT NULL,
    "senderType" public."SupportSenderType" NOT NULL,
    content text NOT NULL,
    "isRead" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: support_tickets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.support_tickets (
    id text NOT NULL,
    "ticketCode" text NOT NULL,
    "userId" text NOT NULL,
    "workspaceId" text,
    "issueType" public."SupportIssueType" NOT NULL,
    subject text NOT NULL,
    status public."SupportTicketStatus" DEFAULT 'PENDING'::public."SupportTicketStatus" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "closedAt" timestamp(3) without time zone
);


--
-- Name: tourist_apartments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tourist_apartments (
    id text NOT NULL,
    "workspaceId" text NOT NULL,
    name text NOT NULL,
    description text,
    category text,
    location text,
    "streetNumber" text,
    phone text,
    mobile text,
    email text,
    rooms integer,
    beds integer,
    bathrooms integer,
    link text,
    "videoUrl" text,
    "order" integer DEFAULT 0 NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: tourist_castles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tourist_castles (
    id text NOT NULL,
    "workspaceId" text NOT NULL,
    name text NOT NULL,
    description text,
    century text,
    "visitInfo" text,
    location text,
    phone text,
    link text,
    "videoUrl" text,
    "order" integer DEFAULT 0 NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: tourist_churches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tourist_churches (
    id text NOT NULL,
    "workspaceId" text NOT NULL,
    name text NOT NULL,
    description text,
    century text,
    style text,
    location text,
    phone text,
    link text,
    "videoUrl" text,
    "order" integer DEFAULT 0 NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: tourist_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tourist_events (
    id text NOT NULL,
    "workspaceId" text NOT NULL,
    title text NOT NULL,
    description text,
    location text,
    "startDate" timestamp(3) without time zone,
    "endDate" timestamp(3) without time zone,
    price text,
    "ticketInfo" text,
    link text,
    "ticketLink" text,
    "videoUrl" text,
    "order" integer DEFAULT 0 NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: tourist_excursions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tourist_excursions (
    id text NOT NULL,
    "workspaceId" text NOT NULL,
    name text NOT NULL,
    description text,
    difficulty text,
    duration text,
    location text,
    link text,
    "videoUrl" text,
    "order" integer DEFAULT 0 NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    season text
);


--
-- Name: tourist_hotels; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tourist_hotels (
    id text NOT NULL,
    "workspaceId" text NOT NULL,
    name text NOT NULL,
    description text,
    stars integer,
    location text,
    phone text,
    link text,
    "videoUrl" text,
    "order" integer DEFAULT 0 NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: tourist_photos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tourist_photos (
    id text NOT NULL,
    "workspaceId" text NOT NULL,
    "contentType" public."TouristContentType" NOT NULL,
    "contentId" text NOT NULL,
    "imageBase64" text NOT NULL,
    caption text,
    "order" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: tourist_refuges; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tourist_refuges (
    id text NOT NULL,
    "workspaceId" text NOT NULL,
    name text NOT NULL,
    description text,
    "climbTime" text,
    difficulty text,
    "openFrom" text,
    "openTo" text,
    location text,
    phone text,
    link text,
    "videoUrl" text,
    "order" integer DEFAULT 0 NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    email text
);


--
-- Name: tourist_restaurants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tourist_restaurants (
    id text NOT NULL,
    "workspaceId" text NOT NULL,
    name text NOT NULL,
    description text,
    "cuisineType" text,
    "celiacFriendly" boolean DEFAULT false NOT NULL,
    "needsReservation" boolean DEFAULT false NOT NULL,
    location text,
    phone text,
    link text,
    "videoUrl" text,
    "order" integer DEFAULT 0 NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: tourist_ski_facilities; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tourist_ski_facilities (
    id text NOT NULL,
    "workspaceId" text NOT NULL,
    name text NOT NULL,
    description text,
    "slopeType" text,
    location text,
    link text,
    "videoUrl" text,
    "order" integer DEFAULT 0 NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: tourist_sports_facilities; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tourist_sports_facilities (
    id text NOT NULL,
    "workspaceId" text NOT NULL,
    name text NOT NULL,
    description text,
    sport text,
    location text,
    link text,
    "videoUrl" text,
    "order" integer DEFAULT 0 NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    season text
);


--
-- Name: tourist_venues; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tourist_venues (
    id text NOT NULL,
    "workspaceId" text NOT NULL,
    name text NOT NULL,
    description text,
    "venueType" text,
    "openingHours" text,
    location text,
    phone text,
    link text,
    "videoUrl" text,
    "order" integer DEFAULT 0 NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: tourist_viewpoints; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tourist_viewpoints (
    id text NOT NULL,
    "workspaceId" text NOT NULL,
    name text NOT NULL,
    description text,
    altitude integer,
    access text,
    difficulty text,
    location text,
    link text,
    "videoUrl" text,
    "order" integer DEFAULT 0 NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: two_factor_reset_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.two_factor_reset_tokens (
    id text NOT NULL,
    "userId" text NOT NULL,
    token character varying(36) NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "usedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "createdByAdminId" text NOT NULL,
    "passwordAttempts" integer DEFAULT 0 NOT NULL,
    "lockedUntil" timestamp(3) without time zone
);


--
-- Name: usage; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.usage (
    id text NOT NULL,
    "workspaceId" text NOT NULL,
    "clientId" text NOT NULL,
    price numeric(10,4) DEFAULT 0.005 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id text NOT NULL,
    email text NOT NULL,
    "passwordHash" text,
    "firstName" text,
    "lastName" text,
    status public."UserStatus" DEFAULT 'ACTIVE'::public."UserStatus" NOT NULL,
    "lastLogin" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedAt" timestamp(3) without time zone,
    role public."UserRole" DEFAULT 'MEMBER'::public."UserRole" NOT NULL,
    "isPlatformAdmin" boolean DEFAULT false NOT NULL,
    "isDeveloperUser" boolean DEFAULT false NOT NULL,
    "twoFactorSecret" text,
    "twoFactorEnabled" boolean DEFAULT false NOT NULL,
    "twoFactorEnabledAt" timestamp(3) without time zone,
    "recoveryCodes" text[] DEFAULT ARRAY[]::text[],
    "authProvider" text DEFAULT 'email'::text NOT NULL,
    "profilePicture" text,
    logo text,
    "linkedProviders" jsonb DEFAULT '[]'::jsonb,
    "gdprAccepted" timestamp(3) without time zone,
    "phoneNumber" text,
    language text DEFAULT 'ENG'::text NOT NULL,
    "companyName" text,
    "vatNumber" text,
    website text,
    "billingPhone" text,
    "billingAddress" text,
    "planType" public."PlanType" DEFAULT 'FREE_TRIAL'::public."PlanType" NOT NULL,
    "creditBalance" numeric(10,2) DEFAULT 19.00 NOT NULL,
    "trialEndsAt" timestamp(3) without time zone,
    "planStartedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "nextBillingDate" timestamp(3) without time zone,
    "lowBalanceNotifiedAt" timestamp(3) without time zone,
    "subscriptionStatus" public."SubscriptionStatus" DEFAULT 'ACTIVE'::public."SubscriptionStatus" NOT NULL,
    "pausedAt" timestamp(3) without time zone,
    "pauseRequestedAt" timestamp(3) without time zone,
    "pendingPlanType" public."PlanType",
    "pendingPlanEffectiveDate" timestamp(3) without time zone,
    "lastPaymentFailedAt" timestamp(3) without time zone,
    "paymentFailureCount" integer DEFAULT 0 NOT NULL,
    "paypalStatus" public."PayPalStatus" DEFAULT 'DISCONNECTED'::public."PayPalStatus" NOT NULL,
    "isPaymentConnected" boolean DEFAULT false NOT NULL,
    "paypalClientId" text,
    "paypalMerchantId" text,
    "paypalEmail" text,
    "paypalEnvironment" text,
    "paypalConnectedAt" timestamp(3) without time zone,
    "paypalAccessTokenEncrypted" text,
    "paypalRefreshTokenEncrypted" text,
    "paypalTokenExpiresAt" timestamp(3) without time zone,
    "paypalTokenScope" text,
    "paypalSubscriptionId" text,
    "paypalPlanId" text,
    "paypalSubscriptionStatus" text,
    "paypalNextBillingTime" timestamp(3) without time zone,
    "paypalLastPaymentTime" timestamp(3) without time zone,
    "paypalFailedPaymentsCount" integer DEFAULT 0 NOT NULL,
    "paypalCyclesCompleted" integer DEFAULT 0 NOT NULL,
    "paypalOutstandingBalance" numeric(10,2) DEFAULT 0 NOT NULL,
    "paypalSubscriptionApprovedAt" timestamp(3) without time zone,
    "isDemoUser" boolean DEFAULT false NOT NULL,
    "taxRate" numeric(5,4) DEFAULT 0.22 NOT NULL,
    "trialExpiringNotifiedAt" timestamp(3) without time zone
);


--
-- Name: whatsapp_queue; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.whatsapp_queue (
    id text NOT NULL,
    "workspaceId" text NOT NULL,
    "customerId" text NOT NULL,
    "phoneNumber" text NOT NULL,
    "messageContent" text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    "errorMessage" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "deliveredAt" timestamp(3) without time zone,
    "conversationMessageId" text,
    "pushCampaignId" text,
    "pushCampaignRecipientId" text,
    channel text DEFAULT 'whatsapp'::text NOT NULL,
    "visitorId" text,
    "isAnonymous" boolean DEFAULT false NOT NULL,
    "expiresAt" timestamp(3) without time zone,
    "responsePayload" jsonb,
    "pollingAttempts" integer DEFAULT 0 NOT NULL,
    "lastPolledAt" timestamp(3) without time zone,
    "isPlayground" boolean DEFAULT false NOT NULL,
    "skipSecurityCheck" boolean DEFAULT false NOT NULL,
    "retryCount" integer DEFAULT 0 NOT NULL,
    "maxRetries" integer DEFAULT 3 NOT NULL,
    "nextRetryAt" timestamp(3) without time zone,
    "mediaUrl" text
);


--
-- Name: whatsapp_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.whatsapp_settings (
    id text NOT NULL,
    "phoneNumber" text NOT NULL,
    "apiKey" text NOT NULL,
    "appName" text,
    "appSecret" text,
    "webhookUrl" text,
    "webhookId" text NOT NULL,
    "webhookToken" text NOT NULL,
    "businessAccountId" text,
    settings jsonb DEFAULT '{}'::jsonb,
    "adminEmail" text,
    "smtpHost" text DEFAULT 'smtp.ethereal.email'::text,
    "smtpPort" integer DEFAULT 587,
    "smtpSecure" boolean DEFAULT false,
    "smtpUser" text,
    "smtpPass" text,
    "smtpFrom" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "workspaceId" text NOT NULL,
    gdpr text
);


--
-- Name: whatsapp_webhook_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.whatsapp_webhook_events (
    id text NOT NULL,
    "workspaceId" text NOT NULL,
    "externalMessageId" text NOT NULL,
    channel text DEFAULT 'whatsapp'::text NOT NULL,
    "receivedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: workspace_business_hours; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workspace_business_hours (
    id text NOT NULL,
    "workspaceId" text NOT NULL,
    "dayOfWeek" integer NOT NULL,
    "startTime" text NOT NULL,
    "endTime" text NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL
);


--
-- Name: workspace_calling_functions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workspace_calling_functions (
    id text NOT NULL,
    "workspaceId" text NOT NULL,
    "functionName" text NOT NULL,
    description text,
    "responseInstructions" text,
    parameters jsonb,
    "isSystemFunction" boolean DEFAULT false NOT NULL,
    "executionType" text DEFAULT 'WEBHOOK'::text NOT NULL,
    "attachedLlm" text,
    "attachedFlowKey" text,
    "webhookUrl" text,
    "credentialsMapping" jsonb,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: workspace_environment_variables; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workspace_environment_variables (
    id text NOT NULL,
    "workspaceId" text NOT NULL,
    "variableName" text NOT NULL,
    "encryptedValue" text NOT NULL,
    nonce text NOT NULL,
    description text,
    "createdBy" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: workspace_invitations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workspace_invitations (
    id text NOT NULL,
    email text NOT NULL,
    "firstName" text,
    "lastName" text,
    "workspaceId" text NOT NULL,
    "tokenHash" text NOT NULL,
    "invitedById" text NOT NULL,
    status public."InvitationStatus" DEFAULT 'PENDING'::public."InvitationStatus" NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "acceptedAt" timestamp(3) without time zone
);


--
-- Data for Name: Billing; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Billing" (id, "workspaceId", "customerId", amount, type, description, "userQuery", "previousTotal", "currentCharge", "newTotal", "createdAt") FROM stdin;
\.


--
-- Data for Name: Certification; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Certification" (id, name, "workspaceId", "createdAt", "updatedAt") FROM stdin;
09d6065a-66ba-4cbe-882b-d67727b27c32	Bio	bellitalia-vip-ecommerce	2026-06-13 22:14:26.681	2026-06-13 22:14:26.681
79fbfe27-1ce9-4049-91a5-ee8e1c686ed7	Vegan	bellitalia-vip-ecommerce	2026-06-13 22:14:26.683	2026-06-13 22:14:26.683
d842ad3d-2eae-4608-ac8c-fedba98dec57	Gluten-Free	bellitalia-vip-ecommerce	2026-06-13 22:14:26.684	2026-06-13 22:14:26.684
cf8dc141-5eef-41c6-a8b1-5808250ae707	Halal	bellitalia-vip-ecommerce	2026-06-13 22:14:26.684	2026-06-13 22:14:26.684
d51ff34b-29c5-429b-84f8-3a61ec44f7e6	Whole-Grain	bellitalia-vip-ecommerce	2026-06-13 22:14:26.685	2026-06-13 22:14:26.685
e0a85d97-ebae-4bce-b7c3-326031c7f824	DOP	bellitalia-vip-ecommerce	2026-06-13 22:14:26.686	2026-06-13 22:14:26.686
f338754e-26e4-4d53-b6ea-2042f265211a	IGP	bellitalia-vip-ecommerce	2026-06-13 22:14:26.687	2026-06-13 22:14:26.687
3eea84eb-b988-4704-ad8a-6f0f502746f5	IGT	bellitalia-vip-ecommerce	2026-06-13 22:14:26.687	2026-06-13 22:14:26.687
\.


--
-- Data for Name: ProductCategory; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."ProductCategory" ("productId", "categoryId", "createdAt") FROM stdin;
\.


--
-- Data for Name: ProductCertification; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."ProductCertification" ("productId", "certificationId", "createdAt") FROM stdin;
\.


--
-- Data for Name: ProductCharacteristic; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."ProductCharacteristic" (id, "productId", name, value, "createdAt") FROM stdin;
\.


--
-- Data for Name: ProductType; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."ProductType" ("productId", "typeId") FROM stdin;
\.


--
-- Data for Name: ShortUrls; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."ShortUrls" (id, "shortCode", "originalUrl", "workspaceId", clicks, "isActive", "expiresAt", "lastAccessedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Type; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Type" (id, name, "workspaceId", price, "isActive", "createdAt", "updatedAt") FROM stdin;
1fbce604-75f0-4008-80e3-706fc489dd97	Temperatura Ambiente	bellitalia-vip-ecommerce	8.00	t	2026-06-13 22:14:26.689	2026-06-13 22:14:26.689
394183eb-c9a2-4874-821d-231e5b65be4c	Refrigerato	bellitalia-vip-ecommerce	12.00	t	2026-06-13 22:14:26.69	2026-06-13 22:14:26.69
c22d2931-d33b-4d0d-bcac-25f708e0b3d8	Congelato	bellitalia-vip-ecommerce	15.00	t	2026-06-13 22:14:26.691	2026-06-13 22:14:26.691
\.


--
-- Data for Name: UserWorkspace; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."UserWorkspace" ("userId", "workspaceId", role, "createdAt") FROM stdin;
fd566368-a330-47b4-9b11-3e44622cba2e	bellitalia-vip-ecommerce	SUPER_ADMIN	2026-06-13 22:14:26.275
fd566368-a330-47b4-9b11-3e44622cba2e	bellitalia-info-workspace	SUPER_ADMIN	2026-06-13 22:14:26.288
fd566368-a330-47b4-9b11-3e44622cba2e	echatbot-hq-support	SUPER_ADMIN	2026-06-13 22:14:26.493
\.


--
-- Data for Name: Workspace; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Workspace" (id, name, slug, "whatsappPhoneNumber", "whatsappApiKey", "whatsappPhoneNumberId", "whatsappVerifyToken", "notificationEmail", "webhookUrl", "webhookSecret", "webhookTimeout", language, "createdAt", "updatedAt", "deletedAt", currency, "defaultLanguage", "channelStatus", description, "messageLimit", url, "welcomeMessage", "enableWelcomeMessage", "sessionResetTimeout", "wipMessage", "afterRegistrationMessages", "debugMode", "apiKey", metadata, "allowedExternalLinks", "logoUrl", "logoKey", "websiteUrl", "widgetLogoUrl", "widgetLogoKey", "widgetTitle", "widgetLanguage", "widgetPrimaryColor", "widgetTextColor", "widgetIcon", "widgetUseChannelLogo", "widgetAutoSuggestionsEnabled", "widgetQuickReplies", "widgetSuggestionsModel", "channelType", "enableWhatsapp", "enableWidget", "channelMode", "enableCalendarBooking", "hasSalesAgents", "hasHumanSupport", "hasProductCatalog", "hasCart", "hasOrderTracking", "needRegistration", "humanSupportInstructions", "operatorContactMethod", "operatorEmail", "operatorWhatsappNumber", "toneOfVoice", "whatsappProvider", "metaPhoneNumberId", "metaAccessToken", "webhookVerifyToken", "ultraMsgInstanceId", "ultraMsgToken", "ultraMsgApiUrl", "wasenderSessionId", "wasenderApiKey", "wasenderSessionStatus", "wasenderPhoneNumber", "wasenderQrString", "wasenderQrGeneratedAt", "wasenderIsActive", "botIdentityResponse", "customAiRules", address, "chatbotName", "businessType", "customChatbotId", "registrationPage", "requireManualApproval", "approvalMessage", "translateProductNames", "translateCategoryNames", "translateServiceNames", "catalogBaseLanguage", "ownerId", timezone, "appointmentReminder24hEnabled", "appointmentReminder24hMessage", "appointmentReminder1hEnabled", "appointmentReminder1hMessage", "appointmentReminder30mEnabled", "appointmentReminder30mMessage", "appointmentReminderChannel", "appointmentReminderHours", "minBookingBufferHours", "zoomAccessToken", "zoomRefreshToken", "zoomConnected", "zoomUserId", "customChatbotMaxTokens", "audioOutput", "audioVoices", "operatorEmails", "operatorWhatsappNumbers", "operatorDeliveryMode", "faqsEnabled", "flowsEnabled", "escalationTrigger", "customChatbotSystemPrompt", "enabledLanguages", "termsAndConditions", "translateCustomerMessages", "frustrationTriggers", "customChatbotModel", "customChatbotTemperature", "customChatbotOperatorBriefingLanguage", "customChatbotOperatorEmail", "customChatbotEmailFrom", "customChatbotEmailSubjectPrefix", "customChatbotAudioOutput", "customChatbotAudioVoices", "welcomeBackMessage", "humanSupportMessage", "customChatbotAdvancedSettings", "speechToTextEnabled", "taxRate", "wasenderWebhookSecret", "securityBlockedMessage", "videoUrl", "widgetErrorMessage") FROM stdin;
bellitalia-info-workspace	BellItalia	bell-italia	+34654728752	\N	\N	\N	info@bellitalia.com	\N	\N	10000	ENG	2026-06-13 22:14:26.282	2026-06-13 22:14:26.282	\N	EUR	en	t	Italian Gourmet Food - Information Channel	50	https://bellitalia.com	Welcome to BellItalia! Ask me anything about our products and services.	t	3600	Sorry, I'm currently being improved. Please try again later.	Thank you for registering, {{customerName}}! How can I help you today? Would you like to see your orders? The offers? Or do you need other information?	f	\N	\N	{}	\N	\N	\N	\N	\N	\N	en	#22c55e	#0f172a	chat	f	f	{}	\N	WHATSAPP	t	f	INFORMATIONAL	f	f	t	f	f	f	t	Ciao {{nameUser}}, mi sto mettendo in contatto con il nostro operatore. Ti rispondera' al piu' presto. Disattivo il chatbot finche' non ricevi assistenza.	EMAIL	\N	\N	PROFESSIONAL	meta	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	I'm the BellItalia assistant, here to provide information about our Italian gourmet products and services! 📚	# Communication Style\n\n- Keep sentences SHORT - avoid long text blocks\n- Greet the user often using their name: {{customerName}}\n- Use emoticons to make tone friendly 😊\n- When appropriate, end with a question to keep conversation flowing\n- For lists, ALWAYS use bullet points\n- If there's a link, add a line break after it\n- For important concepts, use **bold**\n- For SUPER important concepts, use **BOLD AND UPPERCASE**\n\n# Example Communication\n"Hi {{customerName}}! 👋\n\nHere's the information you requested:\nhttps://echatbot.ai/info/products\n\n**Key Features:**\n• Feature 1\n• Feature 2\n\n**IMPORTANT: Limited time offer**\n\nWould you like details about something specific?"	\N	Marco	food	\N	\N	f	\N	f	f	t	it	fd566368-a330-47b4-9b11-3e44622cba2e	Europe/Rome	t	Hi {{customerName}}, reminder: your {{appointmentType}} appointment is tomorrow {{appointmentDate}} at {{appointmentTime}}. Confirm your presence?	t	Hi {{customerName}}, your {{appointmentType}} appointment starts in 1 hour at {{appointmentTime}}. See you soon!	f	Hi {{customerName}}, your {{appointmentType}} appointment starts in 30 minutes at {{appointmentTime}}. We're waiting for you!	whatsapp	{24,1}	12	\N	\N	f	\N	\N	f	\N	{}	{}	all	t	t	\N	\N	{}	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	Welcome back, {{customerName}}! How can I help you today?	Hi {{customerName}}, I'm putting you in touch with our operator as soon as possible.	\N	f	0.2200	\N	\N	\N	\N
echatbot-hq-support	eChatbot HQ	echatbot-hq	+34654728753	\N	\N	\N	hello@echatbot.ai	\N	\N	10000	ENG	2026-06-13 22:14:26.484	2026-06-13 22:14:26.484	\N	EUR	en	t	eChatbot Enterprise Support - product education channel	50	https://www.echatbot.ai	Hi! I'm your eChatbot product assistant. Ask me anything about plans, integrations or onboarding. 🚀	t	3600	Our assistants are being updated. If you need immediate help please write to support@echatbot.ai.	Thank you for registering, {{customerName}}! How can I help you today? Would you like to see your orders? The offers? Or do you need other information?	f	\N	\N	{}	\N	\N	\N	\N	\N	\N	en	#22c55e	#0f172a	chat	f	f	{}	\N	WHATSAPP	t	f	INFORMATIONAL	f	f	t	f	f	f	t	Ciao {{nameUser}}, ti metto subito in contatto con un consulente eChatbot. Riceverai risposta entro 15 minuti da {{agentName}} (tel: {{agentPhone}} / email: {{agentEmail}}).	EMAIL	\N	\N	PROFESSIONAL	meta	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	I'm the eChatbot product specialist. Automate sales, support, and campaigns on WhatsApp — in one platform. 💼 How can I help you today?	# Communication Style\n\n- Keep sentences SHORT - avoid long text blocks\n- Greet the user often using their name: {{customerName}}\n- Use emoticons to make tone friendly 😊\n- When appropriate, end with a question to keep conversation flowing\n- For lists, ALWAYS use bullet points\n- If there's a link, add a line break after it\n- For important concepts, use **bold**\n- For SUPER important concepts, use **BOLD AND UPPERCASE**\n\n# Custom Features & Enterprise Requests\n\nWhen a customer asks about:\n- **Custom integrations** (CRM, ERP, third-party APIs)\n- **Personalized features** or platform modifications\n- **Enterprise-specific needs** not covered by standard plans\n\n**ALWAYS respond:**\n"Le customizzazioni fanno parte del piano Enterprise 🏢\n\nPer fornirti un preventivo accurato, ti chiedo di inviare una email a support@echatbot.ai con:\n• Descrizione dettagliata della customizzazione richiesta\n• Specifiche tecniche (API, formati dati, autenticazione)\n• Piano mensile attuale o desiderato\n• Consumo mensile stimato (numero messaggi/utenti)\n\nCalcoleremo: prezzo piano mensile + consumo mensile + preventivo customizzazioni.\n\n**RESPONSE TIME: 24-48 hours** 📧"\n\n# Example Communication\n"Hi {{customerName}}! 💼\n\nHere's our documentation:\nhttps://echatbot.ai/docs\n\n**Quick Links:**\n• Getting started\n• API reference\n• Pricing plans\n\nCan I help with anything else?"	\N	Sofia	technology	\N	\N	f	\N	f	f	t	it	fd566368-a330-47b4-9b11-3e44622cba2e	Europe/Rome	t	Hi {{customerName}}, reminder: your {{appointmentType}} appointment is tomorrow {{appointmentDate}} at {{appointmentTime}}. Confirm your presence?	t	Hi {{customerName}}, your {{appointmentType}} appointment starts in 1 hour at {{appointmentTime}}. See you soon!	f	Hi {{customerName}}, your {{appointmentType}} appointment starts in 30 minutes at {{appointmentTime}}. We're waiting for you!	whatsapp	{24,1}	12	\N	\N	f	\N	\N	f	\N	{}	{}	all	t	t	\N	\N	{}	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	Welcome back, {{customerName}}! How can I help you today?	Hi {{customerName}}, I'm putting you in touch with our operator as soon as possible.	\N	f	0.2200	\N	\N	\N	\N
bellitalia-vip-ecommerce	BellItalia VIP	bell-italia-vip	+34654728751	\N	\N	\N	info@bellitalia.com	\N	\N	10000	ENG	2026-06-13 22:14:26.265	2026-06-13 22:14:26.859	\N	EUR	en	t	Italian Gourmet Food E-commerce - VIP Channel	50	https://bellitalia.com/vip	Ciao, piacere di conoscerti! 👋\nMi chiamo SofIA e sono l'assistenza virtuale di BellItalia.\nSiamo un importatore di prodotti italiani.\n\nCome posso aiutarti oggi?\nStai cercando un prodotto in particolare oppure hai una domanda specifica da farmi?\n\nCon questo servizio puoi:\n• chiedere informazioni su un ordine\n• effettuare un ordine\n• cercare un prodotto\n• farmi una domanda\n• scaricare una fattura\n• sapere dove si trova il tuo ordine\n• verificare la disponibilità dei prodotti in tempo reale\n\nSono qui per aiutarti 😊	t	3600	Sorry, I'm currently being improved. Please try again later.	Thank you for registering, {{customerName}}! How can I help you today? Would you like to see your orders? The offers? Or do you need other information?	f	\N	\N	{}	\N	\N	\N	\N	\N	\N	en	#22c55e	#0f172a	chat	f	f	{}	\N	WHATSAPP	t	f	ECOMMERCE	f	t	t	t	t	t	t	Hello {{nameUser}}, I'm connecting you with our agent {{agentName}}. They will contact you as soon as possible (phone: {{agentPhone}} / email: {{agentEmail}}). We're disabling the chatbot until you receive a response. Thank you for your patience! 🤝	EMAIL	\N	\N	FRIENDLY	meta	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	I'm the BellItalia VIP virtual assistant, here to help you discover and purchase authentic Italian gourmet products! 🇮🇹	# Communication Style\n\n- Keep sentences SHORT - avoid long text blocks\n- Greet the user often using their name: {{customerName}}\n- Use emoticons to make tone friendly 😊\n- When appropriate, end with a question to keep conversation flowing\n- For lists, ALWAYS use bullet points\n- If there's a link, add a line break after it\n- For important concepts, use **bold**\n- For SUPER important concepts, use **BOLD AND UPPERCASE**\n\n# Example Communication\n"Hi {{customerName}}! 👋\n\nHere's your order:\nhttps://echatbot.ai/order/123\n\n**Total: €45.50**\n\n**PAYMENT DUE: 3 DAYS**\n\nNeed anything else?"	\N	Sofia	food	\N	https://bellitalia.com/registrati	f	\N	f	f	t	it	fd566368-a330-47b4-9b11-3e44622cba2e	Europe/Rome	t	Ciao {{customerName}}, ti ricordo appuntamento di {{appointmentType}} il giorno: {{appointmentDate}} alle ore: {{appointmentTime}}\n\nConfermi la tua presenza?	t	Ciao {{customerName}}, tra 1 ora inizia il tuo appuntamento di {{appointmentType}} alle {{appointmentTime}}. Ti aspettiamo!	f	Ciao {{customerName}}, tra 30 minuti inizia il tuo appuntamento di {{appointmentType}} alle {{appointmentTime}}. Ci vediamo!	whatsapp	{24,1}	12	\N	\N	f	\N	\N	f	\N	{}	{}	all	t	t	\N	\N	{}	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	Welcome back, {{customerName}}! How can I help you today?	Hi {{customerName}}, I'm putting you in touch with our operator as soon as possible.	\N	f	0.2200	\N	\N	\N	\N
cmqcx3fcx0000cgng9dml0qbh	DemoHouse	demohouse	\N	\N	\N	\N	\N	\N	\N	10000	ENG	2026-06-13 22:18:52.161	2026-08-31 08:32:39.916	\N	EUR	es	t	\N	50	\N	Welcome! I'm {{chatbotName}}, your digital assistant. How can I help you today?	t	3600	Work in progress. Please contact us later.	Thank you for registering, {{customerName}}! How can I help you today? Would you like to see your orders? The offers? Or do you need other information?	f	\N	\N	{}	\N	\N	\N	\N	\N	\N	en	#22c55e	#0f172a	chat	f	f	{}	\N	WHATSAPP	f	t	PRO_LOCO	f	f	t	t	t	t	t	\N	email	echatbotai@gmail.com	\N	friendly	wasender	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	DemoCasa	real_estate	demorealestate	\N	f	\N	f	f	t	it	fd566368-a330-47b4-9b11-3e44622cba2e	Europe/Rome	t	Hi {{customerName}}, reminder: your {{appointmentType}} appointment is tomorrow {{appointmentDate}} at {{appointmentTime}}. Confirm your presence?	t	Hi {{customerName}}, your {{appointmentType}} appointment starts in 1 hour at {{appointmentTime}}. See you soon!	f	Hi {{customerName}}, your {{appointmentType}} appointment starts in 30 minutes at {{appointmentTime}}. We're waiting for you!	whatsapp	{24,1}	12	\N	\N	f	\N	\N	f	\N	{}	{}	all	t	t	\N	\N	{}	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	Welcome back, {{customerName}}! How can I help you today?	Hi {{customerName}}, I'm putting you in touch with our operator as soon as possible.	\N	f	0.2200	\N	\N	\N	\N
\.


--
-- Data for Name: _OfferCategories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."_OfferCategories" ("A", "B") FROM stdin;
\.


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
1fb23da5-d45f-439b-a8ee-64885da8c958	f28e4bfbd5421ae965d76553f7ff9aa6ccaef01b13d50353af646ddcda1a598d	2026-08-03 14:54:18.445251+00	20260731110000_add_frustration_triggers	\N	\N	2026-08-03 14:54:18.443147+00	1
5056e8a5-3e4e-4c74-9925-cad4c16fd8df	d204b560594369392deeecd5f93f36f909b7169447a55e4c041b6f103ff5d45a	2026-06-13 22:14:19.192362+00	0_init	\N	\N	2026-06-13 22:14:19.078112+00	1
fb9414a8-94b6-4777-8ea1-e1fda650dcaf	manual	2026-06-14 14:44:15.653523+00	20260614120000_consolidate_welcome_video_url	\N	\N	2026-06-14 14:44:15.653523+00	1
7391fc4a-c111-4c46-aa5d-6be4747ce6fa	9166d4b8cde269172881b9e19aab134bc550bd320594a7bbd6ec953ee1876307	2026-06-15 07:27:38.117215+00	20260614130000_rename_democasa_to_demohouse	\N	\N	2026-06-15 07:27:38.111703+00	1
ac8587d1-894d-4228-8704-f08dabd1ba2f	174d2e4b855749b259e6049cb48a465a14cbe7a12021595a950db9cd661becf9	2026-06-15 07:27:38.120208+00	20260615120000_drop_welcome_video_url	\N	\N	2026-06-15 07:27:38.117995+00	1
65234034-88d9-46da-b122-d3f653425f96	df112511913bc08f6894a584f90072a64bb4ad9be7f24b46807ceed94017ea59	2026-07-31 18:15:28.276933+00	20260730233335_fix_seed_rumore_no_branches		\N	2026-07-31 18:15:28.276933+00	0
7a84c932-b5de-46c9-be14-546af82dcc0d	manual	2026-07-31 18:18:45.223704+00	20260731140000_add_custom_chatbot_runtime_settings	\N	\N	2026-07-31 18:18:45.223704+00	1
02d395bc-5557-4c1d-8d14-bbdd8c3d69b5	manual	2026-07-31 18:47:53.990121+00	20260731150000_add_multi_operator_and_faq_toggle	\N	\N	2026-07-31 18:47:53.990121+00	1
eb7c3658-0f8a-4127-8d4a-8680fa6ad065	2dbdb03a54a8b3c5398b79fd885c4a8cebdf3752534fce3c5898748c65e86808	2026-08-03 14:54:18.45127+00	20260731120000_add_custom_chatbot_operational_overrides	\N	\N	2026-08-03 14:54:18.446006+00	1
259b69cf-f8a9-4a33-85ac-ab1463cd190d	3ec0b1a21a4423cc13578a41d97f6bfd32afe6a9b7b74b2f0ad1d7b818c31b61	2026-08-03 14:54:18.39686+00	20260615130000_rename_demohouse_to_demorealestate	\N	\N	2026-08-03 14:54:18.393294+00	1
b7438fa0-e529-4569-95f7-8e5713a6516e	3c87349124e6ef1138791810e8c54f6506dd9243e96460d19664a7c7ac074483	2026-08-03 14:54:18.424303+00	20260731000000_add_demorobot_flow_chatbot	\N	\N	2026-08-03 14:54:18.397536+00	1
ee6373bc-5184-4094-8f77-1ad8ef2ae3b7	b7f1e2464f75bc533eb3a04f56d35a752ddf57686306bb3d93162ce80ac30f8f	2026-08-05 12:44:35.49308+00	20260805140000_add_flow_edge_target_flow	\N	\N	2026-08-05 12:44:35.48759+00	1
8c5dd103-df53-4f5e-9ca0-29dd26ce6d2e	5e94ced7fbf662bb41e2b3defe61dcf3fa10e41a8ee0e315ff99e1a0fbe66436	2026-08-03 14:54:18.42839+00	20260731010000_seed_demorobot_dev_data	\N	\N	2026-08-03 14:54:18.425309+00	1
50255b53-0ee7-4dba-b287-27b5ac4f04d1	5e7e5ee5d54dbe0d557362c7cc727d7a1bcab22e78cb7028660cbd83014c95e1	2026-08-03 14:54:18.454734+00	20260731130000_rename_robot_model_to_flow_category	\N	\N	2026-08-03 14:54:18.452066+00	1
3e2150c8-7dfd-4963-93d8-6b670f17c359	567f0d5f0d56f727a8770c045cb8ec39129de5cfadab9ef985cb58dce7f12c0f	2026-08-03 14:54:18.430985+00	20260731080923_add_custom_chatbot_system_prompt	\N	\N	2026-08-03 14:54:18.42903+00	1
e7fd9211-101f-4c68-a03e-cb858f094c46	3c59bbede43b3e9d7466373bb85447db6a8813f6959df7d3b9214f8faf36d4b7	2026-08-03 14:54:18.433489+00	20260731083924_fix_seed_serial_prefix	\N	\N	2026-08-03 14:54:18.431665+00	1
02d51315-d07e-4c03-8f29-db9d81ba9acb	49163aa8a37a725d1076a3088fba90c38298d292b69261b4329888ecd67a5d80	2026-08-03 14:54:18.436918+00	20260731095439_add_enabled_languages	\N	\N	2026-08-03 14:54:18.434195+00	1
df390afa-7d60-4010-9a68-a8bc083d780b	09b08778be61cd835f0af5b863bf9397c3bfd687810fc5c585ad720b50236091	2026-08-03 14:54:18.457424+00	20260731160000_add_flow_human_prompt	\N	\N	2026-08-03 14:54:18.455335+00	1
438f7771-eeea-42ed-8a74-b64ee36c63dc	b17bf0c7110faa70c8954f6c4dadf3898ec9a33ab6cb818bc4cf46ca861f10d4	2026-08-03 14:54:18.43919+00	20260731100032_add_terms_and_conditions	\N	\N	2026-08-03 14:54:18.437512+00	1
aee83cef-49ed-4241-a75f-80e760e43c3b	f490240633afdc7b7f3fe251280b009936add29a7a2bfb35532c3165b7c476d2	2026-08-03 14:54:18.442414+00	20260731100314_add_translate_customer_messages	\N	\N	2026-08-03 14:54:18.439788+00	1
27ce72de-55cf-4546-9439-06b9c68e8268	f14b71013eac51fd55d61c8622a3627bff4c4bd465de58f54a7126767a4ab934	2026-08-05 12:44:35.495886+00	20260805150000_drop_flow_human_prompt	\N	\N	2026-08-05 12:44:35.493648+00	1
c7ecb0a8-292a-437f-9beb-0d553daae3e7	0373feaa6a3b8acd35e4ee77a87daf4c38090b943a26b13873c29624defee081	2026-08-03 14:54:18.460881+00	20260801170000_realign_workspace_toggle_columns	\N	\N	2026-08-03 14:54:18.458121+00	1
6f3a8d2f-805b-45f2-b086-2eb6b8cf78a5	3da8aaa110b019c23bc4b5cf49007251e2967af6dc7baf7ce14d5503fcb11a9f	2026-08-03 14:54:18.463958+00	20260802090000_add_welcome_back_and_human_support_messages	\N	\N	2026-08-03 14:54:18.461497+00	1
14b087f8-ae55-4b6e-b443-e50cdcb5a3df	14fcf75fa3165c0db1b597809f92174d4715452f4c54bcba7e6fba1ea35d7989	2026-08-07 19:18:39.365485+00	20260807130000_kanban_author_kind	\N	\N	2026-08-07 19:18:39.358898+00	1
79cdb169-0b1a-466f-b830-e4b687150265	020cbdba924b6e232bbd4acf7f8849fdb0094060cca0d4956b45e7b19eae8d86	2026-08-03 20:50:36.281164+00	20260803210000_add_custom_chatbot_advanced_settings	\N	\N	2026-08-03 20:50:36.276893+00	1
66a2e375-d6c8-41dc-8ee1-d4ce787776f4	38612900885a437ad6de09aa3144c92856442b9e0dd1650c01e1b16f2a877d55	2026-08-06 14:08:29.596286+00	20260806100000_add_speech_to_text_enabled	\N	\N	2026-08-06 14:08:29.589729+00	1
1b0acf81-3397-4a09-95a3-d06001ef2728	0b1638757f1833cc927814decf64a1691350d7895c5d8fa997c375f708e919a1	2026-08-05 12:44:35.487031+00	20260805120000_add_flow_is_protected	\N	\N	2026-08-05 12:44:35.4809+00	1
db8b7279-a9d8-42d4-81bb-765048a5bf1d	b5cd45ea511ebc3bbbeb4c92eafe9dfa0b5cbb05027d8f2299c62f002fcef225	2026-08-07 18:42:54.378765+00	20260807100000_add_widget_allowed_domains	\N	\N	2026-08-07 18:42:54.373973+00	1
80913110-36e3-4c79-a275-3a9e52b24a97	66d919cce559031a94c5104f557aba0f777c842ac91549200f74466b55559081	2026-08-07 18:42:54.382994+00	20260807120000_kanban_priority_to_english	\N	\N	2026-08-07 18:42:54.37936+00	1
3fcc94a0-bce6-415d-80e3-b6f3d48a2c4d	0876fd419b6a631e3fa5380eea6c31fe17f0bc1ab3a518fae16229bb909e5461	2026-08-07 19:39:34.753444+00	20260807140000_drop_widget_allowed_domains	\N	\N	2026-08-07 19:39:34.748016+00	1
091e78b2-950f-4dbd-890e-e7f3595f8100	5ece6a511f237cccc2c2afb6e7ba278cba0e115d9c541541a5f9e6a9dba2f31c	2026-08-16 16:13:13.529177+00	20260816190000_add_whatsapp_queue_retry_fields		\N	2026-08-16 16:13:13.529177+00	0
6c73a698-8d59-4c74-b9cb-b75324f28c57	5fef4093b17ea023bed657cfd222d7924a831a95fd370e92791408fd817c388c	2026-08-07 22:44:59.651749+00	20260808100000_kanban_standalone_cards	\N	\N	2026-08-07 22:44:59.64455+00	1
8b7a5b13-24fe-4bf8-9f91-c7401fd94fd4	347783ace7c518be95feffbd219a61103355c73c1c825b4243111653ad8b2d30	2026-08-08 08:20:13.610597+00	20260808000000_drop_unused_tables		\N	2026-08-08 08:20:13.610597+00	0
44859939-a083-4fef-bfc8-cf15d6f4625e	e7fce2b03760521ec259a3aaeddf2e52d6d11860c3995d406695175f4b6dac5d	2026-08-16 16:15:44.131504+00	20260816191000_add_wasender_webhook_secret		\N	2026-08-16 16:15:44.131504+00	0
2be93957-618b-455d-8c4d-a7ff06ff8863	3944f921b0a73ff96f32b66c0a4dbc8564cb11c0c8696b7f2c9567325a9d9825	2026-08-16 16:40:11.709068+00	20260816193000_add_security_blocked_message		\N	2026-08-16 16:40:11.709068+00	0
2cef7110-ff51-4bf0-9e7a-ca633a2d52a5	de28796b7503bfd9e1e6648096d1f7a221619b65d46e89bd7c1c9f9cca5cd6b0	\N	20260812000000_baseline	A migration failed to apply. New migrations cannot be applied before the error is recovered from. Read more about how to resolve migration issues in a production database: https://pris.ly/d/migrate-resolve\n\nMigration name: 20260812000000_baseline\n\nDatabase error code: 42710\n\nDatabase error:\nERROR: type "AttachmentKind" already exists\n\nDbError { severity: "ERROR", parsed_severity: Some(Error), code: SqlState(E42710), message: "type \\"AttachmentKind\\" already exists", detail: None, hint: None, position: None, where_: None, schema: None, table: None, column: None, datatype: None, constraint: None, file: Some("typecmds.c"), line: Some(1211), routine: Some("DefineEnum") }\n\n   0: sql_schema_connector::apply_migration::apply_script\n           with migration_name="20260812000000_baseline"\n             at schema-engine/connectors/sql-schema-connector/src/apply_migration.rs:113\n   1: schema_commands::commands::apply_migrations::Applying migration\n           with migration_name="20260812000000_baseline"\n             at schema-engine/commands/src/commands/apply_migrations.rs:95\n   2: schema_core::state::ApplyMigrations\n             at schema-engine/core/src/state.rs:255	2026-08-27 23:10:24.826362+00	2026-08-12 21:41:17.626203+00	0
be64d937-9030-4212-84d4-bedc57d0ce57	de28796b7503bfd9e1e6648096d1f7a221619b65d46e89bd7c1c9f9cca5cd6b0	2026-08-27 23:10:24.830864+00	20260812000000_baseline		\N	2026-08-27 23:10:24.830864+00	0
9ea5f507-2bcd-4068-a774-d90df1751a24	aa9e83339d03c8adf44fad6338962f276eee9786576811684315cb4d6af63c6d	2026-08-31 22:56:29.814635+00	20260831190000_add_merchant_advertising	\N	\N	2026-08-31 22:56:29.811153+00	1
6ea623da-821b-4c28-b334-1d5daf28666b	b2e51cd416743700d571d43c216be0014a5f8fa2f7aef57fd316c079fb13804b	2026-08-27 23:10:25.457402+00	20260816175917_drop_translate_operator_messages	\N	\N	2026-08-27 23:10:25.448172+00	1
c7e10e12-4e9c-4e83-b5f2-30509bbe7c9c	0ff0141d500109821e05a9cf6fef1aa19b4d87e7aad729a86d26a97646788f9b	2026-08-27 23:10:25.4652+00	20260816200000_add_flow_is_active	\N	\N	2026-08-27 23:10:25.457939+00	1
8cdb6cfc-a9db-47af-82fb-9c341fe2eaaf	d52c8992f5129fa2ca48bd25dce97ff7d2226150d18e66079f3e737ab7442a29	2026-08-27 23:10:25.468999+00	20260823100000_add_customer_stay_profile_and_feedback	\N	\N	2026-08-27 23:10:25.465835+00	1
8556e98e-6648-46fa-b43b-0fc6273752b2	e32ade8c30961d8821c7782a34e49d914356b587bb055ba613b1cb86068d85fd	2026-08-31 22:56:29.816892+00	20260901090000_add_push_media	\N	\N	2026-08-31 22:56:29.815145+00	1
d9c7d3b0-a3d3-45a4-ae54-bf1fbf326c69	d52371142e598aee189d5c89a0c756b5410cb650e25c68568c07aee57a1bfcf5	2026-08-27 23:10:25.471442+00	20260824204720_add_workspace_video_url	\N	\N	2026-08-27 23:10:25.469572+00	1
016b446b-9666-412d-9a29-e9454f9664c3	50b9d526dc3d74dd1c51172adf8240964704d445b4401856a1b4d2b031297c53	2026-08-31 07:49:53.937202+00	20260831094943_add_pro_loco_channel_mode	\N	\N	2026-08-31 07:49:53.932356+00	1
aff8d907-f5c3-4213-b835-f5bb90e873b3	33fb4d73e12025eacc62ce8a0c9ba9cc2ffe52fd28e88cf55b1405912bf1593d	2026-09-14 12:44:48.076838+00	20260914100000_add_invoice_year_sequences	\N	\N	2026-09-14 12:44:48.074013+00	1
ea0fa7da-0621-45e6-a5d2-a1a600d0a750	1ae908f3985a37ce4064aa3f3eb3e2d00dc78fda0d0b48798f791d30c655d805	2026-08-31 07:57:10.448296+00	20260831095644_add_tourist_content_tables	\N	\N	2026-08-31 07:57:10.428057+00	1
738e47d1-be33-41f7-9482-9095e93ed58f	7bfc8fdfb5a2e39625493152a1dcbdcc6352abd2f5052bfd5e96828d8beb76f3	2026-08-31 22:56:29.819019+00	20260901110000_add_campaign_send_window	\N	\N	2026-08-31 22:56:29.817422+00	1
3b3ffac5-375e-4a21-9f65-c756e95b1e47	5986f9de4a8789786b13be4cabc63811bb0cd5a6c1eee8930e0df702057f884c	2026-08-31 08:01:13.403735+00	20260831100057_add_tourist_events_and_photo_gallery	\N	\N	2026-08-31 08:01:13.389079+00	1
e6ba1336-fe2d-4d75-b957-741a3a342b92	fbbae28c7b9c1172f96bebfcd7e2b14acbe04eba07e38defb41a087a3546ad3e	2026-08-31 13:56:21.121351+00	20260831140000_add_tourist_apartments_and_refuge_email	\N	\N	2026-08-31 13:56:21.107609+00	1
697867b0-eaa6-4422-90a6-1b2ddbb9aecc	2e627d84120a03934529d419339d2390dcd400a8569ac144925000e2c533ac27	2026-09-14 16:55:39.181405+00	20260914140000_add_stay_end_feedback	\N	\N	2026-09-14 16:55:39.181405+00	1
af997bc7-de77-4d97-8166-59be07d7312c	035e63f78fe75fc991f88ef31917803328b441ee7d78d6238eef10531ea81f5f	2026-08-31 22:56:29.810524+00	20260831180000_add_widget_error_message	\N	\N	2026-08-31 22:56:29.807282+00	1
2cd93a3a-6566-4888-837f-125ea1526b8d	e932cc78e805a9c3e98dc4da07f4d195cb90d7759a2fe82899d76835a8938d4d	2026-08-31 22:56:29.820841+00	20260901120000_add_campaign_media_base64	\N	\N	2026-08-31 22:56:29.819516+00	1
b56756ec-2113-4ae7-800f-8441f1485de6	186dc01b929e0e656003023a9da697538286b193b5bfdc51005e524915d849b7	2026-08-31 22:56:29.831756+00	20260901130000_add_sports_and_ski_facilities	\N	\N	2026-08-31 22:56:29.82138+00	1
085a4e19-28c4-4654-b4c3-c25090e30c38	ca23eda6c794dbdb7d0ef653c8ec473c6bfeae0dd6eb531451da25d2b4ad5a5e	2026-08-31 23:08:58.691721+00	20260901140000_add_season_to_excursions_and_sports	\N	\N	2026-08-31 23:08:58.688394+00	1
683b9f85-33d4-4b4d-8d72-98052c67f4a4	b1564c873f25c926c343b9619d1b80283c398b43fefd613b79dddebfe51db1e3	2026-09-14 12:44:48.073372+00	20260914100000_add_churches_castles_viewpoints_venues	\N	\N	2026-09-14 12:44:47.983937+00	1
\.


--
-- Data for Name: admin_sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.admin_sessions (id, "sessionId", "userId", "workspaceId", "createdAt", "expiresAt", "lastActivityAt", "ipAddress", "userAgent", "isActive") FROM stdin;
cmqdtz4d30000dlng96c6iv8l	f05afea8-4a74-4bcc-8358-3e16ce9e65d7	fd566368-a330-47b4-9b11-3e44622cba2e	\N	2026-06-14 13:39:18.614	2026-06-14 14:39:18.613	2026-06-14 13:39:18.613	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	f
cmtad038u0000b1ngab51e9s5	fc237338-38e0-407a-b6f9-2c3945f989bc	fd566368-a330-47b4-9b11-3e44622cba2e	\N	2026-08-26 17:19:58.83	2026-08-26 19:19:58.827	2026-08-26 17:19:58.827	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	t
\.


--
-- Data for Name: agent_configs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agent_configs (id, "workspaceId", name, type, description, icon, "systemPrompt", model, temperature, "maxTokens", "order", "availableFunctions", "createdAt", "updatedAt") FROM stdin;
0c874abd-7646-4ceb-b066-7bf3fee96f04	bellitalia-vip-ecommerce	Router Agent	ROUTER	Pure orchestration: intent classification, context interpretation for short responses (with CONFERMA keyword), and FAQ handling	GitBranch		mistralai/mistral-large	0	500	0	["productSearchAgent", "cartManagementAgent", "orderTrackingAgent", "customerSupportAgent", "profileManagementAgent", "fetchWebsitePage"]	2026-06-13 22:14:26.341	2026-06-13 22:14:26.341
4b792598-1d0f-4a7e-b38f-74ffbc20df2e	bellitalia-vip-ecommerce	Operator Message	OPERATOR	Human operator manual message bypass (no LLM processing, direct to customer)	User		mistralai/mistral-large	0	100	0	null	2026-06-13 22:14:26.344	2026-06-13 22:14:26.344
07272911-4b93-4eed-a301-0b25185e16b9	bellitalia-vip-ecommerce	Product Search Agent	PRODUCT_SEARCH	Specialist in product search with progressive filtering strategy (Regola 11): guides customers from categories to specific products	Search		mistralai/mistral-large	0.2	2048	1	["getProductDetails", "getServiceDetails", "searchProductForStatistic"]	2026-06-13 22:14:26.346	2026-06-13 22:14:26.346
7792c965-d3ad-4c7e-9963-eff498888a06	bellitalia-vip-ecommerce	Cart Management Agent	CART_MANAGEMENT	Specialist in cart operations: add/remove products, repeat orders, manage quantities	ShoppingCart		mistralai/mistral-large	0.2	2048	2	["addItemToCart", "viewCart", "updateCartItem", "removeFromCart", "clearCart"]	2026-06-13 22:14:26.349	2026-06-13 22:14:26.349
0a10608c-bc0d-4b56-93a8-c538d5fb91d4	bellitalia-vip-ecommerce	Order Tracking Agent	ORDER_TRACKING	Specialist in order tracking, history, invoices, and delivery status	Package		mistralai/mistral-large	0.2	2048	3	["getLinkOrderByCode", "repeatOrder", "getOrderDetails", "confirmOrder", "showCheckout"]	2026-06-13 22:14:26.351	2026-06-13 22:14:26.351
27ddc0f8-02a1-49e7-84c9-30bbc3aad129	bellitalia-vip-ecommerce	Customer Support Agent	CUSTOMER_SUPPORT	Specialist in customer support, human escalation, complaints, and urgent issues	Headset		mistralai/mistral-large	0.2	2048	4	["contactOperator"]	2026-06-13 22:14:26.352	2026-06-13 22:14:26.352
21f2cfde-39f3-4b91-a679-2c307d480c43	bellitalia-vip-ecommerce	Summary Agent	SUMMARY_AGENT	Specialist in creating concise conversation summaries for support team email notifications	FileText		mistralai/mistral-large	0.2	500	5	[]	2026-06-13 22:14:26.354	2026-06-13 22:14:26.354
5db8fb57-c932-4d6e-b04a-e508b777938d	bellitalia-vip-ecommerce	Profile Management Agent	PROFILE_MANAGEMENT	Specialist in managing customer profile information and notification preferences (enable/disable push notifications)	User		mistralai/mistral-large	0.2	500	6	["getProfileLink", "contactOperator"]	2026-06-13 22:14:26.356	2026-06-13 22:14:26.356
a612e4ac-7a93-49b3-8472-3bb3f018d3d6	bellitalia-vip-ecommerce	Notifications Agent	NOTIFICATIONS	Specialist in push notification campaigns, announcements, and broadcast messages	Bell		mistralai/mistral-large	0.3	1000	7	null	2026-06-13 22:14:26.358	2026-06-13 22:14:26.358
58c7b9a2-b04c-4e75-9e97-f36fd7bdcad6	bellitalia-vip-ecommerce	Safety + Translation	TRANSLATION	Final layer: translates response to customer's language (IT/EN/ES/PT), blocks profanity and spam, validates external links	Globe	You are a SECURITY and TRANSLATION filter for WhatsApp e-commerce messages.\n\nYour job is CRITICAL:\n1. Translate the message to the target language\n2. Filter and block ANY inappropriate content\n\n## SECURITY FILTERING - Block ANY of these:\n\n**Profanity (Italian)**:\ncazzo, troia, puttana, stronzo, stronza, minchia, vaffanculo, coglione, fica, pene, pompino, scopare, fottere, frocio, zoccola\n\n**Profanity (Spanish)**:\nputa, cabrón, mierda, coño, polla, verga, pendejo, maricón, chupame, follar, joder, zorra, gilipollas\n\n**Profanity (Portuguese)**:\nputa, porra, caralho, foda, foder, buceta, piroca, merda, viado, vadia, arrombado\n\n**Profanity (English)**:\nfuck, pussy, bitch, dick, shit, cock, blowjob, anal, porn\n\n**Spam/Scam**:\nclick here, promo code, discount code, free gift, urgent, bitcoin, crypto, referral bonus, click now, claim now\n\n**Phishing**:\n.ru, .tk, .xyz, .onion, telegram link, t.me, password, otp, codice segreto, verify account\n\n**Adult Content**:\nnude, xxx, webcam, onlyfans, porn link, sexo gratis\n\n## LINK VALIDATION\nOnly allow links from these trusted domains:\n{ALLOWED_LINKS}\n\nAny other external links should be flagged as potentially dangerous.\n\n## TRANSLATION RULES\n- Keep formatting (emojis, line breaks)\n- Maintain professional, friendly tone\n- Use "{CUSTOMER_NAME}" as the customer name in greetings\n- Preserve prices and numbers exactly\n- Keep Italian product names in Italian (unless translateProductNames is enabled)\n- Keep brand names unchanged\n\n## NEVER TRANSLATE PLANS\nCRITICAL: The following subscription plan names MUST remain EXACTLY as written, in UPPERCASE:\n- FREE_TRIAL\n- BASIC\n- STARTER\n- PREMIUM\n- ENTERPRISE\n\nThese are technical identifiers used throughout the system. Never translate, modify, or lowercase them.\nExamples of CORRECT usage:\n- "Ofrecemos planes PREMIUM y ENTERPRISE" (Spanish) ✅\n- "We offer STARTER, PREMIUM and ENTERPRISE plans" (English) ✅  \n- "I nostri piani sono BASIC, PREMIUM e ENTERPRISE" (Italian) ✅\n\nExamples of WRONG usage:\n- "planes Premium y Empresarial" ❌ (translated)\n- "piani premium e enterprise" ❌ (lowercased)\n- "Starter, Premium, Enterprise" ❌ (not uppercase)\n\n## REPLACEMENT\nIf you detect inappropriate content, replace with:\n- IT: "Ciao {CUSTOMER_NAME}! Scopri le nostre ultime novità. Contattaci per maggiori informazioni!"\n- EN: "Hello {CUSTOMER_NAME}! Discover our latest products. Contact us for more information!"\n- ES: "¡Hola {CUSTOMER_NAME}! Descubre nuestras últimas novedades. ¡Contáctanos para más información!"\n- PT: "Olá {CUSTOMER_NAME}! Descubra nossas novidades. Entre em contato para mais informações!"\n\n## OUTPUT FORMAT - Return ONLY valid JSON:\n{\n  "translatedText": "The translated and filtered text",\n  "safe": true,\n  "blockedReason": null\n}\n\nIf blocked:\n{\n  "translatedText": "[replacement message in target language]",\n  "safe": false,\n  "blockedReason": "profanity|spam|phishing|adult|dangerous_link"\n}\n\nIMPORTANT: Return ONLY the JSON object, no markdown, no extra text.\n\n---\nTARGET LANGUAGE: {TARGET_LANGUAGE}\nMESSAGE TO PROCESS:\n{MESSAGE}	mistralai/mistral-large	0.3	1000	8	null	2026-06-13 22:14:26.36	2026-06-13 22:14:26.36
fb9dedbe-faea-4ff9-af5f-41ab10a50e0e	bellitalia-vip-ecommerce	Conversation History Layer	CONVERSATION_HISTORY	Humanization layer: transforms technical responses into natural, contextual messages with greetings, offers suggestions, and personality	MessageCircle		mistralai/mistral-large	0.7	500	9	null	2026-06-13 22:14:26.362	2026-06-13 22:14:26.362
7313c788-129b-4fc2-a31d-57f18ce6000e	bellitalia-vip-ecommerce	Security Agent	SECURITY	Security validation: detects dangerous content, SQL injection, XSS, offensive language. Blocks unsafe messages completely (no send, shows 🚫 icon)	Shield		mistralai/mistral-large	0	500	98	[]	2026-06-13 22:14:26.363	2026-06-13 22:14:26.363
0a94dc10-c47e-4b6a-a1b0-1989763fe6da	bellitalia-info-workspace	Router Agent	ROUTER	Pure orchestration: intent classification, context interpretation for short responses (with CONFERMA keyword), and FAQ handling	GitBranch		mistralai/mistral-large	0	500	0	["productSearchAgent", "cartManagementAgent", "orderTrackingAgent", "customerSupportAgent", "profileManagementAgent", "fetchWebsitePage"]	2026-06-13 22:14:26.371	2026-06-13 22:14:26.371
9c8cf1c6-963a-4b75-b2de-8c10a1af03a3	bellitalia-info-workspace	Operator Message	OPERATOR	Human operator manual message bypass (no LLM processing, direct to customer)	User		mistralai/mistral-large	0	100	0	null	2026-06-13 22:14:26.373	2026-06-13 22:14:26.373
98f637b9-f587-4837-93ee-02444f64a383	bellitalia-info-workspace	Customer Support Agent	CUSTOMER_SUPPORT	Specialist in customer support, human escalation, complaints, and urgent issues	Headset		mistralai/mistral-large	0.2	2048	4	["contactOperator"]	2026-06-13 22:14:26.375	2026-06-13 22:14:26.375
25a1a1df-1ce9-4dde-9f23-fd03cd1cced3	bellitalia-info-workspace	Summary Agent	SUMMARY_AGENT	Specialist in creating concise conversation summaries for support team email notifications	FileText		mistralai/mistral-large	0.2	500	5	[]	2026-06-13 22:14:26.376	2026-06-13 22:14:26.376
b7fba3cd-5efb-4379-912c-fc57bccc35a7	bellitalia-info-workspace	Profile Management Agent	PROFILE_MANAGEMENT	Specialist in managing customer profile information and notification preferences (enable/disable push notifications)	User		mistralai/mistral-large	0.2	500	6	["getProfileLink", "contactOperator"]	2026-06-13 22:14:26.378	2026-06-13 22:14:26.378
f62d8d52-5d01-45b5-b64f-8c6b9d553fae	bellitalia-info-workspace	Notifications Agent	NOTIFICATIONS	Specialist in push notification campaigns, announcements, and broadcast messages	Bell		mistralai/mistral-large	0.3	1000	7	null	2026-06-13 22:14:26.379	2026-06-13 22:14:26.379
79802213-88ef-4654-9b99-375df63f6dfa	bellitalia-info-workspace	Safety + Translation	TRANSLATION	Final layer: translates response to customer's language (IT/EN/ES/PT), blocks profanity and spam, validates external links	Globe	You are a SECURITY and TRANSLATION filter for WhatsApp e-commerce messages.\n\nYour job is CRITICAL:\n1. Translate the message to the target language\n2. Filter and block ANY inappropriate content\n\n## SECURITY FILTERING - Block ANY of these:\n\n**Profanity (Italian)**:\ncazzo, troia, puttana, stronzo, stronza, minchia, vaffanculo, coglione, fica, pene, pompino, scopare, fottere, frocio, zoccola\n\n**Profanity (Spanish)**:\nputa, cabrón, mierda, coño, polla, verga, pendejo, maricón, chupame, follar, joder, zorra, gilipollas\n\n**Profanity (Portuguese)**:\nputa, porra, caralho, foda, foder, buceta, piroca, merda, viado, vadia, arrombado\n\n**Profanity (English)**:\nfuck, pussy, bitch, dick, shit, cock, blowjob, anal, porn\n\n**Spam/Scam**:\nclick here, promo code, discount code, free gift, urgent, bitcoin, crypto, referral bonus, click now, claim now\n\n**Phishing**:\n.ru, .tk, .xyz, .onion, telegram link, t.me, password, otp, codice segreto, verify account\n\n**Adult Content**:\nnude, xxx, webcam, onlyfans, porn link, sexo gratis\n\n## LINK VALIDATION\nOnly allow links from these trusted domains:\n{ALLOWED_LINKS}\n\nAny other external links should be flagged as potentially dangerous.\n\n## TRANSLATION RULES\n- Keep formatting (emojis, line breaks)\n- Maintain professional, friendly tone\n- Use "{CUSTOMER_NAME}" as the customer name in greetings\n- Preserve prices and numbers exactly\n- Keep Italian product names in Italian (unless translateProductNames is enabled)\n- Keep brand names unchanged\n\n## NEVER TRANSLATE PLANS\nCRITICAL: The following subscription plan names MUST remain EXACTLY as written, in UPPERCASE:\n- FREE_TRIAL\n- BASIC\n- STARTER\n- PREMIUM\n- ENTERPRISE\n\nThese are technical identifiers used throughout the system. Never translate, modify, or lowercase them.\nExamples of CORRECT usage:\n- "Ofrecemos planes PREMIUM y ENTERPRISE" (Spanish) ✅\n- "We offer STARTER, PREMIUM and ENTERPRISE plans" (English) ✅  \n- "I nostri piani sono BASIC, PREMIUM e ENTERPRISE" (Italian) ✅\n\nExamples of WRONG usage:\n- "planes Premium y Empresarial" ❌ (translated)\n- "piani premium e enterprise" ❌ (lowercased)\n- "Starter, Premium, Enterprise" ❌ (not uppercase)\n\n## REPLACEMENT\nIf you detect inappropriate content, replace with:\n- IT: "Ciao {CUSTOMER_NAME}! Scopri le nostre ultime novità. Contattaci per maggiori informazioni!"\n- EN: "Hello {CUSTOMER_NAME}! Discover our latest products. Contact us for more information!"\n- ES: "¡Hola {CUSTOMER_NAME}! Descubre nuestras últimas novedades. ¡Contáctanos para más información!"\n- PT: "Olá {CUSTOMER_NAME}! Descubra nossas novidades. Entre em contato para mais informações!"\n\n## OUTPUT FORMAT - Return ONLY valid JSON:\n{\n  "translatedText": "The translated and filtered text",\n  "safe": true,\n  "blockedReason": null\n}\n\nIf blocked:\n{\n  "translatedText": "[replacement message in target language]",\n  "safe": false,\n  "blockedReason": "profanity|spam|phishing|adult|dangerous_link"\n}\n\nIMPORTANT: Return ONLY the JSON object, no markdown, no extra text.\n\n---\nTARGET LANGUAGE: {TARGET_LANGUAGE}\nMESSAGE TO PROCESS:\n{MESSAGE}	mistralai/mistral-large	0.3	1000	8	null	2026-06-13 22:14:26.381	2026-06-13 22:14:26.381
288ebc0e-84ea-492e-b32d-76482cbedbc7	bellitalia-info-workspace	Conversation History Layer	CONVERSATION_HISTORY	Humanization layer: transforms technical responses into natural, contextual messages with greetings, offers suggestions, and personality	MessageCircle		mistralai/mistral-large	0.7	500	9	null	2026-06-13 22:14:26.383	2026-06-13 22:14:26.383
f325e04e-c6d7-4d29-8fc1-2931c3e664da	bellitalia-info-workspace	Security Agent	SECURITY	Security validation: detects dangerous content, SQL injection, XSS, offensive language. Blocks unsafe messages completely (no send, shows 🚫 icon)	Shield		mistralai/mistral-large	0	500	98	[]	2026-06-13 22:14:26.385	2026-06-13 22:14:26.385
c1cebb6e-7540-4929-9f16-0177ceff9da3	echatbot-hq-support	Router Agent	ROUTER	Pure orchestration: intent classification, context interpretation for short responses (with CONFERMA keyword), and FAQ handling	GitBranch		mistralai/mistral-large	0	500	0	["productSearchAgent", "cartManagementAgent", "orderTrackingAgent", "customerSupportAgent", "profileManagementAgent", "fetchWebsitePage"]	2026-06-13 22:14:26.502	2026-06-13 22:14:26.502
3156d9b0-bbb0-4866-8d8d-b58aaac223a5	echatbot-hq-support	Operator Message	OPERATOR	Human operator manual message bypass (no LLM processing, direct to customer)	User		mistralai/mistral-large	0	100	0	null	2026-06-13 22:14:26.503	2026-06-13 22:14:26.503
cf4f87da-08c6-44ee-8ca2-916cff0813fc	echatbot-hq-support	Customer Support Agent	CUSTOMER_SUPPORT	Specialist in customer support, human escalation, complaints, and urgent issues	Headset		mistralai/mistral-large	0.2	2048	4	["contactOperator"]	2026-06-13 22:14:26.505	2026-06-13 22:14:26.505
994d2784-9320-47b2-81cd-af0865d66a0a	echatbot-hq-support	Summary Agent	SUMMARY_AGENT	Specialist in creating concise conversation summaries for support team email notifications	FileText		mistralai/mistral-large	0.2	500	5	[]	2026-06-13 22:14:26.506	2026-06-13 22:14:26.506
d44a2504-2cbd-4be2-bd47-d1f28addb5c4	echatbot-hq-support	Profile Management Agent	PROFILE_MANAGEMENT	Specialist in managing customer profile information and notification preferences (enable/disable push notifications)	User		mistralai/mistral-large	0.2	500	6	["getProfileLink", "contactOperator"]	2026-06-13 22:14:26.507	2026-06-13 22:14:26.507
2b7b2048-145a-4be6-add3-54607a785dce	echatbot-hq-support	Notifications Agent	NOTIFICATIONS	Specialist in push notification campaigns, announcements, and broadcast messages	Bell		mistralai/mistral-large	0.3	1000	7	null	2026-06-13 22:14:26.509	2026-06-13 22:14:26.509
5fab135d-e940-4c9c-a212-c78337538bdd	echatbot-hq-support	Safety + Translation	TRANSLATION	Final layer: translates response to customer's language (IT/EN/ES/PT), blocks profanity and spam, validates external links	Globe	You are a SECURITY and TRANSLATION filter for WhatsApp e-commerce messages.\n\nYour job is CRITICAL:\n1. Translate the message to the target language\n2. Filter and block ANY inappropriate content\n\n## SECURITY FILTERING - Block ANY of these:\n\n**Profanity (Italian)**:\ncazzo, troia, puttana, stronzo, stronza, minchia, vaffanculo, coglione, fica, pene, pompino, scopare, fottere, frocio, zoccola\n\n**Profanity (Spanish)**:\nputa, cabrón, mierda, coño, polla, verga, pendejo, maricón, chupame, follar, joder, zorra, gilipollas\n\n**Profanity (Portuguese)**:\nputa, porra, caralho, foda, foder, buceta, piroca, merda, viado, vadia, arrombado\n\n**Profanity (English)**:\nfuck, pussy, bitch, dick, shit, cock, blowjob, anal, porn\n\n**Spam/Scam**:\nclick here, promo code, discount code, free gift, urgent, bitcoin, crypto, referral bonus, click now, claim now\n\n**Phishing**:\n.ru, .tk, .xyz, .onion, telegram link, t.me, password, otp, codice segreto, verify account\n\n**Adult Content**:\nnude, xxx, webcam, onlyfans, porn link, sexo gratis\n\n## LINK VALIDATION\nOnly allow links from these trusted domains:\n{ALLOWED_LINKS}\n\nAny other external links should be flagged as potentially dangerous.\n\n## TRANSLATION RULES\n- Keep formatting (emojis, line breaks)\n- Maintain professional, friendly tone\n- Use "{CUSTOMER_NAME}" as the customer name in greetings\n- Preserve prices and numbers exactly\n- Keep Italian product names in Italian (unless translateProductNames is enabled)\n- Keep brand names unchanged\n\n## NEVER TRANSLATE PLANS\nCRITICAL: The following subscription plan names MUST remain EXACTLY as written, in UPPERCASE:\n- FREE_TRIAL\n- BASIC\n- STARTER\n- PREMIUM\n- ENTERPRISE\n\nThese are technical identifiers used throughout the system. Never translate, modify, or lowercase them.\nExamples of CORRECT usage:\n- "Ofrecemos planes PREMIUM y ENTERPRISE" (Spanish) ✅\n- "We offer STARTER, PREMIUM and ENTERPRISE plans" (English) ✅  \n- "I nostri piani sono BASIC, PREMIUM e ENTERPRISE" (Italian) ✅\n\nExamples of WRONG usage:\n- "planes Premium y Empresarial" ❌ (translated)\n- "piani premium e enterprise" ❌ (lowercased)\n- "Starter, Premium, Enterprise" ❌ (not uppercase)\n\n## REPLACEMENT\nIf you detect inappropriate content, replace with:\n- IT: "Ciao {CUSTOMER_NAME}! Scopri le nostre ultime novità. Contattaci per maggiori informazioni!"\n- EN: "Hello {CUSTOMER_NAME}! Discover our latest products. Contact us for more information!"\n- ES: "¡Hola {CUSTOMER_NAME}! Descubre nuestras últimas novedades. ¡Contáctanos para más información!"\n- PT: "Olá {CUSTOMER_NAME}! Descubra nossas novidades. Entre em contato para mais informações!"\n\n## OUTPUT FORMAT - Return ONLY valid JSON:\n{\n  "translatedText": "The translated and filtered text",\n  "safe": true,\n  "blockedReason": null\n}\n\nIf blocked:\n{\n  "translatedText": "[replacement message in target language]",\n  "safe": false,\n  "blockedReason": "profanity|spam|phishing|adult|dangerous_link"\n}\n\nIMPORTANT: Return ONLY the JSON object, no markdown, no extra text.\n\n---\nTARGET LANGUAGE: {TARGET_LANGUAGE}\nMESSAGE TO PROCESS:\n{MESSAGE}	mistralai/mistral-large	0.3	1000	8	null	2026-06-13 22:14:26.511	2026-06-13 22:14:26.511
0c260548-7fd7-4b09-ad3a-73f9f9648981	echatbot-hq-support	Conversation History Layer	CONVERSATION_HISTORY	Humanization layer: transforms technical responses into natural, contextual messages with greetings, offers suggestions, and personality	MessageCircle		mistralai/mistral-large	0.7	500	9	null	2026-06-13 22:14:26.513	2026-06-13 22:14:26.513
9ed4d64c-1061-4b46-9459-063e3effc9b4	echatbot-hq-support	Security Agent	SECURITY	Security validation: detects dangerous content, SQL injection, XSS, offensive language. Blocks unsafe messages completely (no send, shows 🚫 icon)	Shield		mistralai/mistral-large	0	500	98	[]	2026-06-13 22:14:26.515	2026-06-13 22:14:26.515
\.


--
-- Data for Name: agent_conversation_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agent_conversation_logs (id, "workspaceId", "customerId", "conversationId", "messageId", step, "agentType", "agentAction", "inputMessage", "agentPrompt", "llmModel", "llmResponse", confidence, reasoning, "tokensUsed", "executionTimeMs", "functionsCalled", "hasError", "errorMessage", "createdAt") FROM stdin;
\.


--
-- Data for Name: appointments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.appointments (id, "workspaceId", "customerId", "serviceId", "startTime", "endTime", timezone, "googleEventId", "googleEventLink", "googleCalendarId", "zoomLink", "zoomMeetingId", status, "cancelledAt", "cancellationReason", "cancelledBy", "customerName", "customerPhone", "customerEmail", "customerNotes", "adminNotes", "bookedVia", "reminder24hSentAt", "reminder1hSentAt", "reminder30mSentAt", "reminderChannel", "reminderBilledAt", "reminderBillingTotal", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: authentication_attempts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.authentication_attempts (id, "userId", email, "attemptType", success, "failureReason", "ipAddress", "userAgent", metadata, "timestamp") FROM stdin;
cmqdtz4d90001dlng90844d6h	fd566368-a330-47b4-9b11-3e44622cba2e	gelsogrove@gmail.com	oauth	t	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	{"action": "login_skip_2fa", "provider": "google"}	2026-06-14 13:39:18.621
cmtad038x0001b1ngp3jazode	fd566368-a330-47b4-9b11-3e44622cba2e	gelsogrove@gmail.com	oauth	t	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	{"action": "login_skip_2fa", "provider": "google"}	2026-08-26 17:19:58.833
\.


--
-- Data for Name: billing_transactions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.billing_transactions (id, "userId", "workspaceId", type, amount, "balanceAfter", description, "referenceId", "referenceType", metadata, "createdAt") FROM stdin;
cmqcwxqy200k3ibng0upqrufg	fd566368-a330-47b4-9b11-3e44622cba2e	bellitalia-vip-ecommerce	RECHARGE	22.00	22.00	Initial credit - Free Trial	\N	\N	\N	2025-09-05 08:00:00
cmqcwxqy700k4ibngtds1oqyu	fd566368-a330-47b4-9b11-3e44622cba2e	bellitalia-vip-ecommerce	RECHARGE	30.00	52.00	Credit recharge +$30	\N	\N	\N	2025-09-15 12:30:00
cmqcwxqyc00k5ibngd31i9k8s	fd566368-a330-47b4-9b11-3e44622cba2e	bellitalia-vip-ecommerce	MESSAGE	-0.10	51.90	WhatsApp message	\N	\N	\N	2025-09-20 08:15:00
cmqcwxqyf00k6ibngbjxlzljm	fd566368-a330-47b4-9b11-3e44622cba2e	bellitalia-vip-ecommerce	MESSAGE	-0.10	51.80	WhatsApp message	\N	\N	\N	2025-09-20 09:15:00
cmqcwxqyi00k7ibng2q84xqis	fd566368-a330-47b4-9b11-3e44622cba2e	bellitalia-vip-ecommerce	MESSAGE	-0.10	51.70	WhatsApp message	\N	\N	\N	2025-09-20 10:15:00
cmqcwxqyl00k8ibng81zdc6ib	fd566368-a330-47b4-9b11-3e44622cba2e	bellitalia-vip-ecommerce	MESSAGE	-0.10	51.60	WhatsApp message	\N	\N	\N	2025-09-20 11:15:00
cmqcwxqyp00k9ibngh67a173n	fd566368-a330-47b4-9b11-3e44622cba2e	bellitalia-vip-ecommerce	MESSAGE	-0.10	51.50	WhatsApp message	\N	\N	\N	2025-09-20 12:15:00
cmqcwxqys00kaibng25s7u2qo	fd566368-a330-47b4-9b11-3e44622cba2e	bellitalia-vip-ecommerce	PUSH_NOTIFICATION	-1.00	50.50	Push notification	\N	\N	\N	2025-10-15 07:00:00
cmqcwxqyv00kbibngfr2pkzeo	fd566368-a330-47b4-9b11-3e44622cba2e	bellitalia-vip-ecommerce	PUSH_NOTIFICATION	-1.00	49.50	Push notification	\N	\N	\N	2025-10-15 08:00:00
cmqcwxqyy00kcibngu5gbptv5	fd566368-a330-47b4-9b11-3e44622cba2e	bellitalia-vip-ecommerce	PUSH_NOTIFICATION	-1.00	48.50	Push notification	\N	\N	\N	2025-10-15 09:00:00
cmqcwxqz100kdibng0ayeb9ry	fd566368-a330-47b4-9b11-3e44622cba2e	bellitalia-info-workspace	MESSAGE	-0.10	48.40	WhatsApp message	\N	\N	\N	2025-10-20 06:00:00
cmqcwxqz500keibngbzvuzof2	fd566368-a330-47b4-9b11-3e44622cba2e	bellitalia-info-workspace	MESSAGE	-0.10	48.30	WhatsApp message	\N	\N	\N	2025-10-20 06:05:00
cmqcwxqz800kfibngu3k6bvsu	fd566368-a330-47b4-9b11-3e44622cba2e	bellitalia-info-workspace	MESSAGE	-0.10	48.20	WhatsApp message	\N	\N	\N	2025-10-20 07:10:00
cmqcwxqzc00kgibngv39x53cp	fd566368-a330-47b4-9b11-3e44622cba2e	bellitalia-info-workspace	MESSAGE	-0.10	48.10	WhatsApp message	\N	\N	\N	2025-10-20 07:15:00
cmqcwxqzf00khibngpfjq6oc0	fd566368-a330-47b4-9b11-3e44622cba2e	bellitalia-info-workspace	MESSAGE	-0.10	48.00	WhatsApp message	\N	\N	\N	2025-10-20 08:20:00
cmqcwxqzi00kiibngjfqv29p6	fd566368-a330-47b4-9b11-3e44622cba2e	bellitalia-info-workspace	MESSAGE	-0.10	47.90	WhatsApp message	\N	\N	\N	2025-10-20 08:25:00
cmqcwxqzm00kjibngv2wi8l49	fd566368-a330-47b4-9b11-3e44622cba2e	bellitalia-info-workspace	MESSAGE	-0.10	47.80	WhatsApp message	\N	\N	\N	2025-10-20 09:30:00
cmqcwxqzp00kkibngnsc1zbvt	fd566368-a330-47b4-9b11-3e44622cba2e	bellitalia-info-workspace	MESSAGE	-0.10	47.70	WhatsApp message	\N	\N	\N	2025-10-20 09:35:00
cmqcwxqzs00klibngtapnuilu	fd566368-a330-47b4-9b11-3e44622cba2e	bellitalia-info-workspace	MESSAGE	-0.10	47.60	WhatsApp message	\N	\N	\N	2025-10-20 10:40:00
cmqcwxqzv00kmibngmlutauig	fd566368-a330-47b4-9b11-3e44622cba2e	bellitalia-info-workspace	MESSAGE	-0.10	47.50	WhatsApp message	\N	\N	\N	2025-10-20 10:45:00
cmqcwxqzy00knibngfwpwyqtr	fd566368-a330-47b4-9b11-3e44622cba2e	bellitalia-vip-ecommerce	RECHARGE	50.00	97.50	Credit recharge +$50	\N	\N	\N	2025-11-01 07:00:00
cmqcwxr0200koibng111yy36z	fd566368-a330-47b4-9b11-3e44622cba2e	bellitalia-vip-ecommerce	PUSH_NOTIFICATION	-1.00	96.50	Push notification	\N	\N	\N	2025-11-10 08:00:00
cmqcwxr0500kpibngxevr0hcw	fd566368-a330-47b4-9b11-3e44622cba2e	bellitalia-vip-ecommerce	PUSH_NOTIFICATION	-1.00	95.50	Push notification	\N	\N	\N	2025-11-10 08:10:00
cmqcwxr0800kqibng9p29l7jp	fd566368-a330-47b4-9b11-3e44622cba2e	bellitalia-vip-ecommerce	PUSH_NOTIFICATION	-1.00	94.50	Push notification	\N	\N	\N	2025-11-10 08:20:00
cmqcwxr0c00kribng5txjt5yi	fd566368-a330-47b4-9b11-3e44622cba2e	bellitalia-vip-ecommerce	PUSH_NOTIFICATION	-1.00	93.50	Push notification	\N	\N	\N	2025-11-10 08:30:00
cmqcwxr0f00ksibngkwosr33m	fd566368-a330-47b4-9b11-3e44622cba2e	bellitalia-vip-ecommerce	PUSH_NOTIFICATION	-1.00	92.50	Push notification	\N	\N	\N	2025-11-10 08:40:00
cmqcwxr0i00ktibngnviz52gq	fd566368-a330-47b4-9b11-3e44622cba2e	bellitalia-info-workspace	PUSH_NOTIFICATION	-1.00	91.50	Push notification	\N	\N	\N	2025-11-10 13:00:00
cmqcwxr0l00kuibngst0xxw4e	fd566368-a330-47b4-9b11-3e44622cba2e	bellitalia-info-workspace	PUSH_NOTIFICATION	-1.00	90.50	Push notification	\N	\N	\N	2025-11-10 13:10:00
cmqcwxr0o00kvibng3x5651ts	fd566368-a330-47b4-9b11-3e44622cba2e	bellitalia-info-workspace	PUSH_NOTIFICATION	-1.00	89.50	Push notification	\N	\N	\N	2025-11-10 13:20:00
cmqcwxr0r00kwibngztrdkc95	fd566368-a330-47b4-9b11-3e44622cba2e	bellitalia-info-workspace	PUSH_NOTIFICATION	-1.00	88.50	Push notification	\N	\N	\N	2025-11-10 13:30:00
cmqcwxr0u00kxibngwl63xjro	fd566368-a330-47b4-9b11-3e44622cba2e	bellitalia-info-workspace	PUSH_NOTIFICATION	-1.00	87.50	Push notification	\N	\N	\N	2025-11-10 13:40:00
cmqcwxr0w00kyibnglxvj5e8m	fd566368-a330-47b4-9b11-3e44622cba2e	bellitalia-vip-ecommerce	MESSAGE	-0.10	87.40	WhatsApp message	\N	\N	\N	2025-11-20 09:00:00
cmqcwxr0z00kzibngtq5tzno5	fd566368-a330-47b4-9b11-3e44622cba2e	bellitalia-vip-ecommerce	MESSAGE	-0.10	87.30	WhatsApp message	\N	\N	\N	2025-11-20 09:05:00
cmqcwxr1200l0ibngjf4tamzh	fd566368-a330-47b4-9b11-3e44622cba2e	bellitalia-vip-ecommerce	MESSAGE	-0.10	87.20	WhatsApp message	\N	\N	\N	2025-11-20 09:10:00
cmqcwxr1500l1ibng01w6fqmb	fd566368-a330-47b4-9b11-3e44622cba2e	bellitalia-vip-ecommerce	MESSAGE	-0.10	87.10	WhatsApp message	\N	\N	\N	2025-11-20 09:15:00
cmqcwxr1700l2ibng0wmw17mm	fd566368-a330-47b4-9b11-3e44622cba2e	bellitalia-vip-ecommerce	MESSAGE	-0.10	87.00	WhatsApp message	\N	\N	\N	2025-11-20 09:20:00
cmqcwxr1a00l3ibng9n0ixv6l	fd566368-a330-47b4-9b11-3e44622cba2e	bellitalia-vip-ecommerce	MESSAGE	-0.10	86.90	WhatsApp message	\N	\N	\N	2025-11-20 09:25:00
cmqcwxr1d00l4ibngbbrl3q3o	fd566368-a330-47b4-9b11-3e44622cba2e	bellitalia-vip-ecommerce	MESSAGE	-0.10	86.80	WhatsApp message	\N	\N	\N	2025-11-20 09:30:00
cmqcwxr1g00l5ibngvdizpczq	fd566368-a330-47b4-9b11-3e44622cba2e	bellitalia-vip-ecommerce	MESSAGE	-0.10	86.70	WhatsApp message	\N	\N	\N	2025-11-20 09:35:00
cmqcwxr1j00l6ibng12djewl8	fd566368-a330-47b4-9b11-3e44622cba2e	bellitalia-vip-ecommerce	RECHARGE	100.00	186.70	Credit recharge +$100	\N	\N	\N	2025-12-01 07:00:00
cmqcwxr1m00l7ibngp0ns70ir	fd566368-a330-47b4-9b11-3e44622cba2e	bellitalia-vip-ecommerce	MESSAGE	-0.10	186.60	WhatsApp message	\N	\N	\N	2025-12-05 08:00:00
cmqcwxr1p00l8ibngj0umcrip	fd566368-a330-47b4-9b11-3e44622cba2e	bellitalia-vip-ecommerce	MESSAGE	-0.10	186.50	WhatsApp message	\N	\N	\N	2025-12-05 08:03:00
cmqcwxr1r00l9ibngod50dpgt	fd566368-a330-47b4-9b11-3e44622cba2e	bellitalia-vip-ecommerce	MESSAGE	-0.10	186.40	WhatsApp message	\N	\N	\N	2025-12-05 08:06:00
cmqcwxr1u00laibnghuvuzrb4	fd566368-a330-47b4-9b11-3e44622cba2e	bellitalia-vip-ecommerce	MESSAGE	-0.10	186.30	WhatsApp message	\N	\N	\N	2025-12-05 08:09:00
cmqcwxr1x00lbibng0va55163	fd566368-a330-47b4-9b11-3e44622cba2e	bellitalia-vip-ecommerce	MESSAGE	-0.10	186.20	WhatsApp message	\N	\N	\N	2025-12-05 08:12:00
cmqcwxr1z00lcibngnh5on5jv	fd566368-a330-47b4-9b11-3e44622cba2e	bellitalia-vip-ecommerce	MESSAGE	-0.10	186.10	WhatsApp message	\N	\N	\N	2025-12-05 08:15:00
cmqcwxr2200ldibng6rtf20hm	fd566368-a330-47b4-9b11-3e44622cba2e	bellitalia-vip-ecommerce	MESSAGE	-0.10	186.00	WhatsApp message	\N	\N	\N	2025-12-05 08:18:00
cmqcwxr2400leibngcbhdk2v2	fd566368-a330-47b4-9b11-3e44622cba2e	bellitalia-vip-ecommerce	MESSAGE	-0.10	185.90	WhatsApp message	\N	\N	\N	2025-12-05 08:21:00
cmqcwxr2800lfibngjbdiyayb	fd566368-a330-47b4-9b11-3e44622cba2e	bellitalia-vip-ecommerce	MESSAGE	-0.10	185.80	WhatsApp message	\N	\N	\N	2025-12-05 08:24:00
cmqcwxr2a00lgibng272vuqlz	fd566368-a330-47b4-9b11-3e44622cba2e	bellitalia-vip-ecommerce	MESSAGE	-0.10	185.70	WhatsApp message	\N	\N	\N	2025-12-05 08:27:00
cmqcwxr2d00lhibng0fqgr8at	fd566368-a330-47b4-9b11-3e44622cba2e	bellitalia-vip-ecommerce	MESSAGE	-0.10	185.60	WhatsApp message	\N	\N	\N	2025-12-05 08:30:00
cmqcwxr2g00liibng5ybco8gm	fd566368-a330-47b4-9b11-3e44622cba2e	bellitalia-vip-ecommerce	MESSAGE	-0.10	185.50	WhatsApp message	\N	\N	\N	2025-12-05 08:33:00
cmqcwxr2j00ljibngmkhy41g2	fd566368-a330-47b4-9b11-3e44622cba2e	bellitalia-vip-ecommerce	MESSAGE	-0.10	185.40	WhatsApp message	\N	\N	\N	2025-12-05 08:36:00
cmqcwxr2n00lkibng3kv4oy45	fd566368-a330-47b4-9b11-3e44622cba2e	bellitalia-vip-ecommerce	MESSAGE	-0.10	185.30	WhatsApp message	\N	\N	\N	2025-12-05 08:39:00
cmqcwxr2q00llibngdgiykxth	fd566368-a330-47b4-9b11-3e44622cba2e	bellitalia-vip-ecommerce	MESSAGE	-0.10	185.20	WhatsApp message	\N	\N	\N	2025-12-05 08:42:00
cmqcwxr2s00lmibngxv1jh5cq	fd566368-a330-47b4-9b11-3e44622cba2e	bellitalia-info-workspace	PUSH_NOTIFICATION	-1.00	184.20	Push notification	\N	\N	\N	2025-12-05 13:00:00
cmqcwxr2v00lnibng68tyiils	fd566368-a330-47b4-9b11-3e44622cba2e	bellitalia-info-workspace	PUSH_NOTIFICATION	-1.00	183.20	Push notification	\N	\N	\N	2025-12-05 13:05:00
cmqcwxr2x00loibngbaj0nbtl	fd566368-a330-47b4-9b11-3e44622cba2e	bellitalia-info-workspace	PUSH_NOTIFICATION	-1.00	182.20	Push notification	\N	\N	\N	2025-12-05 13:10:00
cmqcwxr3000lpibngg9t0dvay	fd566368-a330-47b4-9b11-3e44622cba2e	bellitalia-info-workspace	PUSH_NOTIFICATION	-1.00	181.20	Push notification	\N	\N	\N	2025-12-05 13:15:00
cmqcwxr3300lqibnghtvbrkpe	fd566368-a330-47b4-9b11-3e44622cba2e	bellitalia-info-workspace	PUSH_NOTIFICATION	-1.00	180.20	Push notification	\N	\N	\N	2025-12-05 13:20:00
cmqcwxr3600lribng0x9t9o0u	fd566368-a330-47b4-9b11-3e44622cba2e	bellitalia-info-workspace	PUSH_NOTIFICATION	-1.00	179.20	Push notification	\N	\N	\N	2025-12-05 13:25:00
cmqcwxr3800lsibngp1kkz841	fd566368-a330-47b4-9b11-3e44622cba2e	bellitalia-info-workspace	PUSH_NOTIFICATION	-1.00	178.20	Push notification	\N	\N	\N	2025-12-05 13:30:00
cmqcwxr3b00ltibngr1dxfg9g	fd566368-a330-47b4-9b11-3e44622cba2e	bellitalia-info-workspace	PUSH_NOTIFICATION	-1.00	177.20	Push notification	\N	\N	\N	2025-12-05 13:35:00
cmqcwxr3e00luibngauytna7e	fd566368-a330-47b4-9b11-3e44622cba2e	bellitalia-info-workspace	PUSH_NOTIFICATION	-1.00	176.20	Push notification	\N	\N	\N	2025-12-05 13:40:00
cmqcwxr3g00lvibng5qv7u0dk	fd566368-a330-47b4-9b11-3e44622cba2e	bellitalia-info-workspace	PUSH_NOTIFICATION	-1.00	175.20	Push notification	\N	\N	\N	2025-12-05 13:45:00
cmqcwxr3k00lwibngq7g6dnbe	fd566368-a330-47b4-9b11-3e44622cba2e	bellitalia-vip-ecommerce	MESSAGE	-0.10	175.10	WhatsApp message	\N	\N	\N	2026-06-14 07:00:00
cmqcwxr3m00lxibnglx6mk8jn	fd566368-a330-47b4-9b11-3e44622cba2e	bellitalia-vip-ecommerce	MESSAGE	-0.10	175.00	WhatsApp message	\N	\N	\N	2026-06-14 07:15:00
cmqcwxr3p00lyibng1h541vrr	fd566368-a330-47b4-9b11-3e44622cba2e	bellitalia-vip-ecommerce	MESSAGE	-0.10	174.90	WhatsApp message	\N	\N	\N	2026-06-14 07:30:00
cmqcwxr3s00lzibngc62m9ylm	fd566368-a330-47b4-9b11-3e44622cba2e	bellitalia-vip-ecommerce	PUSH_NOTIFICATION	-1.00	173.90	Push notification	\N	\N	\N	2026-06-14 09:00:00
cmqcwxr3v00m0ibngkv0fjcf4	fd566368-a330-47b4-9b11-3e44622cba2e	bellitalia-vip-ecommerce	PUSH_NOTIFICATION	-1.00	172.90	Push notification	\N	\N	\N	2026-06-14 09:30:00
cmqcwxr3x00m1ibng8o5ss25j	fd566368-a330-47b4-9b11-3e44622cba2e	bellitalia-info-workspace	PUSH_NOTIFICATION	-1.00	171.90	Push notification	\N	\N	\N	2026-06-14 12:00:00
cmqcwxr4000m2ibngirehjpz4	fd566368-a330-47b4-9b11-3e44622cba2e	bellitalia-info-workspace	PUSH_NOTIFICATION	-1.00	170.90	Push notification	\N	\N	\N	2026-06-14 12:20:00
cmqcwxr4300m3ibngp56jcl94	fd566368-a330-47b4-9b11-3e44622cba2e	bellitalia-info-workspace	PUSH_NOTIFICATION	-1.00	169.90	Push notification	\N	\N	\N	2026-06-14 12:40:00
cmqcwxr4700m4ibngld1kozf2	fd566368-a330-47b4-9b11-3e44622cba2e	\N	INVOICE_PAID	0.00	52.00	Monthly plan PREMIUM - September 2025	\N	\N	\N	2025-10-01 07:00:00
cmqcwxr4900m5ibng3dqva5a7	fd566368-a330-47b4-9b11-3e44622cba2e	\N	INVOICE_PAID	0.00	43.50	Monthly plan PREMIUM - October 2025	\N	\N	\N	2025-11-01 08:00:00
cmqcwxr4c00m6ibng28hlmeq8	fd566368-a330-47b4-9b11-3e44622cba2e	\N	INVOICE_PAID	0.00	88.50	Monthly plan PREMIUM - November 2025	\N	\N	\N	2025-12-01 08:00:00
cmqcwxr4e00m7ibngikiuym2a	fd566368-a330-47b4-9b11-3e44622cba2e	\N	INVOICE_PAID	0.00	175.20	Monthly plan PREMIUM - December 2025	\N	\N	\N	2026-01-01 08:00:00
\.


--
-- Data for Name: blackout_periods; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.blackout_periods (id, "workspaceId", "startDate", "endDate", reason, "createdAt") FROM stdin;
873b29a5-9b6c-4a95-b8c8-3096078817c2	bellitalia-vip-ecommerce	2026-08-15 00:00:00	2026-08-31 23:59:59	Vacanze estive 2026	2026-06-13 22:14:26.869
\.


--
-- Data for Name: cart_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cart_items (id, "itemType", quantity, notes, "createdAt", "updatedAt", "cartId", "productId", "serviceId") FROM stdin;
\.


--
-- Data for Name: carts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.carts (id, "createdAt", "updatedAt", "customerId", "workspaceId") FROM stdin;
\.


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.categories (id, name, description, "createdAt", "updatedAt", "isActive", "workspaceId", slug) FROM stdin;
64c27872-f13e-4f7d-93e1-36554da37e06	Pasta	Pasta tradizionale italiana di semola di grano duro, perfetta per autentici primi piatti.	2026-06-13 22:14:26.652	2026-06-13 22:14:26.652	t	bellitalia-vip-ecommerce	pasta
6293be2f-81c7-467d-9fc0-f67c329d1378	Salumi	Salumi artigianali affettati al momento, ideali per taglieri e panini gourmet.	2026-06-13 22:14:26.656	2026-06-13 22:14:26.656	t	bellitalia-vip-ecommerce	salumi
b118202c-9754-48f6-9931-4bdef444b306	Formaggi	Formaggi italiani DOP, un mix equilibrato di specialità fresche e stagionate.	2026-06-13 22:14:26.66	2026-06-13 22:14:26.66	t	bellitalia-vip-ecommerce	formaggi
967ce878-5db6-4bc6-83e0-3b0371e883e3	Condimenti	Salse, oli e condimenti da dispensa che esaltano le ricette italiane.	2026-06-13 22:14:26.663	2026-06-13 22:14:26.663	t	bellitalia-vip-ecommerce	condimenti
1730d192-60ff-4170-89e6-f2b7a9752042	Dolci	Dolci e biscotti italiani classici per concludere ogni pasto con dolcezza.	2026-06-13 22:14:26.666	2026-06-13 22:14:26.666	t	bellitalia-vip-ecommerce	dolci
1170e844-f4f5-431a-9000-29ef671325c7	Bevande	Bevande italiane, vini e caffè selezionati per un servizio premium.	2026-06-13 22:14:26.669	2026-06-13 22:14:26.669	t	bellitalia-vip-ecommerce	bevande
3bc244a6-02da-4f78-901e-b8e885530f03	Specialità	Prelibatezze regionali in edizione limitata che celebrano la diversità culinaria italiana.	2026-06-13 22:14:26.672	2026-06-13 22:14:26.672	t	bellitalia-vip-ecommerce	specialità
71b0d204-c820-4603-b6ac-c007b16a41bf	Conserve	Verdure conservate sott'olio e in salamoia, pronte come antipasti o contorni.	2026-06-13 22:14:26.675	2026-06-13 22:14:26.675	t	bellitalia-vip-ecommerce	conserve
63377316-b0dd-478e-8b5a-60458c97f8f8	Surgelati	Prodotti surgelati italiani di alta qualità. Attualmente con sconto del 20%!	2026-06-13 22:14:26.679	2026-06-13 22:14:26.679	t	bellitalia-vip-ecommerce	surgelati
\.


--
-- Data for Name: chat_sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.chat_sessions (id, status, context, "startedAt", "endedAt", "escalatedAt", "createdAt", "updatedAt", "deletedAt", "workspaceId", "customerId", "isAnonymous", "visitorId", "expiresAt", channel, "isPlayground", title, feedback, "sortOrder") FROM stdin;
633b81a4-7149-431d-bf03-aec01abf3fd7	active	{"language": "it", "customerName": "Luca Informazioni"}	2026-06-13 22:14:26.305	\N	\N	2026-06-13 22:14:26.305	2026-06-13 22:14:26.305	\N	bellitalia-info-workspace	e703f9c3-ae4e-4c0d-afd2-48dda4b5ea8e	f	\N	\N	whatsapp	f	\N	\N	\N
165fc672-0cfa-4540-a904-fac39d4b8db5	active	{"language": "eng", "customerName": "Emily Johnson"}	2026-06-13 22:14:26.316	\N	\N	2026-06-13 22:14:26.316	2026-06-13 22:14:26.316	\N	bellitalia-info-workspace	753bf3a5-ff99-4830-8c0c-afa7be62d743	f	\N	\N	whatsapp	f	\N	\N	\N
f549b89c-1531-443c-8d98-d3acac7cf851	active	{"language": "esp", "customerName": "Carlos López"}	2026-06-13 22:14:26.325	\N	\N	2026-06-13 22:14:26.325	2026-06-13 22:14:26.325	\N	bellitalia-info-workspace	4a4695a1-b63c-47a0-9e84-323becdc8a7a	f	\N	\N	whatsapp	f	\N	\N	\N
1f3f92d5-3a83-439d-b2e5-bb8bcba8f277	active	{"language": "prt", "customerName": "Ana Silva"}	2026-06-13 22:14:26.333	\N	\N	2026-06-13 22:14:26.333	2026-06-13 22:14:26.333	\N	bellitalia-info-workspace	6bb71ec1-cd3c-47bc-9cb1-c285c641a119	f	\N	\N	whatsapp	f	\N	\N	\N
c03b705c-f8fe-4404-9041-84805eb72439	active	{"language": "eng", "customerName": "Sara Product Demo"}	2026-06-13 22:14:26.583	\N	\N	2026-06-13 22:14:26.583	2026-06-13 22:14:26.583	\N	echatbot-hq-support	fc24368e-377a-46ff-b6bc-aab2c9a3871a	f	\N	\N	whatsapp	f	\N	\N	\N
b2357c3e-040b-4f0b-9b8e-db0e19a675c4	active	{"language": "it", "customerName": "Mario Rossi"}	2026-06-13 22:14:26.944	\N	\N	2026-06-13 22:14:26.944	2026-06-13 22:14:26.944	\N	bellitalia-vip-ecommerce	768079dc-ade2-47c9-ae94-fa839d96b5dc	f	\N	\N	whatsapp	f	\N	\N	\N
1abdb4d6-d289-4a67-89cb-f9851df4a2ab	active	{"language": "es", "customerName": "Maria Garcia"}	2026-06-13 22:14:26.949	\N	\N	2026-06-13 22:14:26.949	2026-06-13 22:14:26.949	\N	bellitalia-vip-ecommerce	6fc43406-b2ef-48ba-a1dd-3171316d3cf3	f	\N	\N	whatsapp	f	\N	\N	\N
91288484-fcbc-4c8f-af59-95ff094d1d4c	active	{"language": "pt", "customerName": "João Silva"}	2026-06-13 22:14:26.953	\N	\N	2026-06-13 22:14:26.953	2026-06-13 22:14:26.953	\N	bellitalia-vip-ecommerce	e47d0970-59a7-4c6e-bf3d-abae59964db0	f	\N	\N	whatsapp	f	\N	\N	\N
feae6cdb-6015-4655-b8f0-296272e12b82	active	{"language": "en", "customerName": "John Smith"}	2026-06-13 22:14:26.96	\N	\N	2026-06-13 22:14:26.96	2026-06-13 22:14:26.96	\N	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	f	\N	\N	whatsapp	t	\N	\N	\N
12f7f507-c2c9-4781-9b12-5f969fd37125	active	{}	2026-06-15 17:15:37.681	\N	\N	2026-06-15 17:15:37.681	2026-06-15 17:15:37.681	\N	cmqcx3fcx0000cgng9dml0qbh	e95ce5db-dfa2-41c4-b6bb-7e344cb36825	t	visitor_1781543737551_138c222d	2026-06-16 17:15:37.551	widget	f	\N	\N	\N
\.


--
-- Data for Name: conversation_messages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.conversation_messages (id, "workspaceId", "customerId", "conversationId", role, content, "agentType", "functionName", "functionArguments", "tokensUsed", "debugInfo", "deliveredAt", "deliveryStatus", reaction, "whatsappMessageId", "createdAt") FROM stdin;
cmqcwxq890000ibngsg6uctvs	bellitalia-info-workspace	e703f9c3-ae4e-4c0d-afd2-48dda4b5ea8e	633b81a4-7149-431d-bf03-aec01abf3fd7	user	Effettuate consegne refrigerate anche il lunedì?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-06-13 19:14:26.312
cmqcwxq890001ibngltfp886s	bellitalia-info-workspace	e703f9c3-ae4e-4c0d-afd2-48dda4b5ea8e	633b81a4-7149-431d-bf03-aec01abf3fd7	assistant	Sì, i mezzi refrigerati partono ogni lunedì e giovedì da Barcellona verso il Nord Italia.	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-06-13 19:15:26.812
cmqcwxq8i0002ibngi12me03y	bellitalia-info-workspace	753bf3a5-ff99-4830-8c0c-afa7be62d743	165fc672-0cfa-4540-a904-fac39d4b8db5	user	Can you send brochures directly to my clients in London?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-06-13 18:54:26.322
cmqcwxq8i0003ibng1rasq5jc	bellitalia-info-workspace	753bf3a5-ff99-4830-8c0c-afa7be62d743	165fc672-0cfa-4540-a904-fac39d4b8db5	assistant	Of course, we can drop-ship samples or brochures directly to your customer with neutral packaging.	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-06-13 18:55:26.822
cmqcwxq8q0004ibng9vsyuh72	bellitalia-info-workspace	4a4695a1-b63c-47a0-9e84-323becdc8a7a	f549b89c-1531-443c-8d98-d3acac7cf851	user	¿Trabajan con entregas en Sevilla dentro de franjas horarias?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-06-13 19:29:26.329
cmqcwxq8q0005ibng1cdm9atu	bellitalia-info-workspace	4a4695a1-b63c-47a0-9e84-323becdc8a7a	f549b89c-1531-443c-8d98-d3acac7cf851	assistant	Sí, podemos coordinar franjas de mañana o tarde con nuestros transportistas locales.	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-06-13 19:30:26.829
cmqcwxq8z0006ibngdyofdr9i	bellitalia-info-workspace	6bb71ec1-cd3c-47bc-9cb1-c285c641a119	1f3f92d5-3a83-439d-b2e5-bb8bcba8f277	user	Conseguem entregar diretamente aos meus restaurantes com prova de entrega?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-06-13 19:54:26.338
cmqcwxq8z0007ibngrc01fght	bellitalia-info-workspace	6bb71ec1-cd3c-47bc-9cb1-c285c641a119	1f3f92d5-3a83-439d-b2e5-bb8bcba8f277	assistant	Sim, fornecemos POD digital assinada e podemos enviar a cópia por e-mail assim que o motorista conclui a entrega.	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-06-13 19:55:26.838
cmqcwxqfy0034ibng8hjv35f9	echatbot-hq-support	fc24368e-377a-46ff-b6bc-aab2c9a3871a	c03b705c-f8fe-4404-9041-84805eb72439	user	Great! I'd like a live walkthrough and to involve my operations team.	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-06-13 22:12:26.589
cmqcwxqfy0035ibngiqbm6gdx	echatbot-hq-support	fc24368e-377a-46ff-b6bc-aab2c9a3871a	c03b705c-f8fe-4404-9041-84805eb72439	assistant	Perfect, I'm escalating this to our human operator. You'll receive a calendar invitation and WhatsApp follow-up within 15 minutes.	\N	\N	\N	\N	{"action":"HANDOFF","operatorNotified":true}	\N	not_queued	\N	\N	2026-06-13 22:12:27.089
cmqcwxqpv005uibngxad5jhyc	bellitalia-vip-ecommerce	768079dc-ade2-47c9-ae94-fa839d96b5dc	b2357c3e-040b-4f0b-9b8e-db0e19a675c4	user	Ciao! Vorrei sapere quali formaggi avete disponibili	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-06-12 22:14:26.946
cmqcwxqpv005vibng418m1e6v	bellitalia-vip-ecommerce	768079dc-ade2-47c9-ae94-fa839d96b5dc	b2357c3e-040b-4f0b-9b8e-db0e19a675c4	assistant	Ciao! Abbiamo una vasta selezione di formaggi italiani:\n\n🧀 **Parmigiano Reggiano DOP** - €18.50/kg\n🧀 **Pecorino Romano DOP** - €16.90/kg\n🧀 **Gorgonzola Dolce** - €14.50/kg\n\nVuoi aggiungere qualcosa al carrello?	\N	\N	\N	\N	{"agentSelected":"PRODUCT_SEARCH","steps":[{"agentType":"Router","decision":"PRODUCT_SEARCH"},{"agentType":"PRODUCT_SEARCH","response":"..."}]}	\N	not_queued	\N	\N	2026-06-12 22:14:27.946
cmqcwxqpv005wibngtlbjsq6s	bellitalia-vip-ecommerce	768079dc-ade2-47c9-ae94-fa839d96b5dc	b2357c3e-040b-4f0b-9b8e-db0e19a675c4	user	Sì, vorrei 1kg di Parmigiano Reggiano	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-06-12 22:14:28.946
cmqcwxqpv005xibngm35t0uak	bellitalia-vip-ecommerce	768079dc-ade2-47c9-ae94-fa839d96b5dc	b2357c3e-040b-4f0b-9b8e-db0e19a675c4	assistant	✅ Perfetto! Ho aggiunto al carrello:\n\n**Parmigiano Reggiano DOP**\nQuantità: 1 kg\nPrezzo: €18.50\n\nVuoi procedere con l'ordine?	\N	\N	\N	\N	{"agentSelected":"CART","functionCalled":"AddToCart"}	\N	not_queued	\N	\N	2026-06-12 22:14:29.946
cmqcwxqpz005yibngounxqwn7	bellitalia-vip-ecommerce	6fc43406-b2ef-48ba-a1dd-3171316d3cf3	1abdb4d6-d289-4a67-89cb-f9851df4a2ab	user	Hola, ¿dónde está mi pedido?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-06-13 21:59:26.951
cmqcwxqpz005zibngt7qvqwm3	bellitalia-vip-ecommerce	6fc43406-b2ef-48ba-a1dd-3171316d3cf3	1abdb4d6-d289-4a67-89cb-f9851df4a2ab	assistant	¡Hola! Tu pedido está en tránsito 🚚\n\n📦 **Pedido #ORD-001**\nEstado: En camino\nEntrega estimada: Mañana\n\n¿Necesitas algo más?	\N	\N	\N	\N	{"agentSelected":"ORDER_TRACKING"}	\N	not_queued	\N	\N	2026-06-13 22:00:26.951
cmqcwxqq60060ibnge2e1e8pi	bellitalia-vip-ecommerce	e47d0970-59a7-4c6e-bf3d-abae59964db0	91288484-fcbc-4c8f-af59-95ff094d1d4c	user	Olá! Tem alguma promoção hoje?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-06-13 21:54:26.957
cmqcwxqq60061ibng5jss7evf	bellitalia-vip-ecommerce	e47d0970-59a7-4c6e-bf3d-abae59964db0	91288484-fcbc-4c8f-af59-95ff094d1d4c	assistant	Olá! Sim, temos ofertas especiais:\n\n🎉 **Oferta da Semana**:\n- Azeite Toscano: -20%\n- Prosciutto di Parma: -15%\n\nQuer aproveitar?	\N	\N	\N	\N	{"agentSelected":"PRODUCT_SEARCH"}	\N	not_queued	\N	\N	2026-06-13 21:55:26.957
cmqcwxqr10062ibngd0jtr0np	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #1: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-14 22:14:26.962
cmqcwxqr10063ibngk3tixjna	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #2: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":82}	\N	not_queued	\N	\N	2026-05-14 22:19:26.962
cmqcwxqr10064ibngrxl4qnpt	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #3: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-14 22:24:26.962
cmqcwxqr10065ibngeouslom5	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #4: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":22}	\N	not_queued	\N	\N	2026-05-14 22:29:26.962
cmqcwxqr10066ibngr8as2wz0	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #5: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-14 22:34:26.962
cmqcwxqr10067ibngfk3e9gt9	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #6: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":72}	\N	not_queued	\N	\N	2026-05-14 22:39:26.962
cmqcwxqr10068ibngp0j0trdh	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #7: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-14 22:44:26.962
cmqcwxqr10069ibngc155l80y	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #8: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":118}	\N	not_queued	\N	\N	2026-05-14 22:49:26.962
cmqcwxqr1006aibngcfj3dytp	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #9: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-14 22:54:26.962
cmqcwxqr1006bibngjm1351y3	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #10: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":29}	\N	not_queued	\N	\N	2026-05-14 22:59:26.962
cmqcwxqr1006cibngbxmxvyy1	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #11: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-14 23:04:26.962
cmqcwxqr1006dibngyrota4lh	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #12: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":107}	\N	not_queued	\N	\N	2026-05-14 23:09:26.962
cmqcwxqr1006eibngqimc4yya	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #13: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-14 23:14:26.962
cmqcwxqr1006fibngihuufhsb	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #14: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":109}	\N	not_queued	\N	\N	2026-05-14 23:19:26.962
cmqcwxqr1006gibngai91zs5f	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #15: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-14 23:24:26.962
cmqcwxqr1006hibngmaqu93bk	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #16: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":69}	\N	not_queued	\N	\N	2026-05-14 23:29:26.962
cmqcwxqr1006iibngd3n4t333	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #17: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-14 23:34:26.962
cmqcwxqr1006jibngh28qnyay	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #18: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":74}	\N	not_queued	\N	\N	2026-05-14 23:39:26.962
cmqcwxqr1006kibngxkc80723	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #19: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-14 23:44:26.962
cmqcwxqr1006libng1ayj4b7h	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #20: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":49}	\N	not_queued	\N	\N	2026-05-14 23:49:26.962
cmqcwxqr2006mibngcvgedew8	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #21: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-14 23:54:26.962
cmqcwxqr2006nibng59qd7fjt	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #22: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":97}	\N	not_queued	\N	\N	2026-05-14 23:59:26.962
cmqcwxqr2006oibng5np2lkpd	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #23: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 00:04:26.962
cmqcwxqr2006pibng9r1ks4x0	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #24: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":91}	\N	not_queued	\N	\N	2026-05-15 00:09:26.962
cmqcwxqr2006qibng07pyhzri	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #25: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 00:14:26.962
cmqcwxqr2006ribng2rd4v47h	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #26: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":46}	\N	not_queued	\N	\N	2026-05-15 00:19:26.962
cmqcwxqr2006sibng57n2fuim	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #27: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 00:24:26.962
cmqcwxqr2006tibngmkkd1vou	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #28: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":98}	\N	not_queued	\N	\N	2026-05-15 00:29:26.962
cmqcwxqr2006uibngen5cy0wd	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #29: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 00:34:26.962
cmqcwxqr2006vibngs35bbr7x	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #30: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":24}	\N	not_queued	\N	\N	2026-05-15 00:39:26.962
cmqcwxqr2006wibng8e4e5wbl	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #31: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 00:44:26.962
cmqcwxqr2006xibnghiprvz1b	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #32: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":27}	\N	not_queued	\N	\N	2026-05-15 00:49:26.962
cmqcwxqr2006yibng16r12kzn	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #33: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 00:54:26.962
cmqcwxqr2006zibngnvqq6bqk	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #34: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":45}	\N	not_queued	\N	\N	2026-05-15 00:59:26.962
cmqcwxqr20070ibngpssd55jq	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #35: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 01:04:26.962
cmqcwxqr20071ibngkmwd24km	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #36: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":44}	\N	not_queued	\N	\N	2026-05-15 01:09:26.962
cmqcwxqr20072ibng426yuu5g	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #37: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 01:14:26.962
cmqcwxqr20073ibngbbn3myuo	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #38: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":71}	\N	not_queued	\N	\N	2026-05-15 01:19:26.962
cmqcwxqr20074ibng9g80cjt1	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #39: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 01:24:26.962
cmqcwxqr20075ibngqwafr8lw	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #40: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":73}	\N	not_queued	\N	\N	2026-05-15 01:29:26.962
cmqcwxqr20076ibngpdeqo80c	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #41: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 01:34:26.962
cmqcwxqr20077ibng4axkfnuz	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #42: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":62}	\N	not_queued	\N	\N	2026-05-15 01:39:26.962
cmqcwxqr20078ibngmeqvsy8n	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #43: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 01:44:26.962
cmqcwxqr20079ibngddytti0n	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #44: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":109}	\N	not_queued	\N	\N	2026-05-15 01:49:26.962
cmqcwxqr2007aibngj1zi7wng	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #45: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 01:54:26.962
cmqcwxqr2007bibngg2f04qj8	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #46: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":112}	\N	not_queued	\N	\N	2026-05-15 01:59:26.962
cmqcwxqr2007cibngbxg8f6l5	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #47: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 02:04:26.962
cmqcwxqr2007dibngbax1hvi6	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #48: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":53}	\N	not_queued	\N	\N	2026-05-15 02:09:26.962
cmqcwxqr2007eibng3osaoez0	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #49: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 02:14:26.962
cmqcwxqr2007fibngbpm12pm3	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #50: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":109}	\N	not_queued	\N	\N	2026-05-15 02:19:26.962
cmqcwxqr2007gibng1lnr8vp8	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #51: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 02:24:26.962
cmqcwxqr2007hibngkeie1fam	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #52: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":113}	\N	not_queued	\N	\N	2026-05-15 02:29:26.962
cmqcwxqr2007iibngbtxrx8m1	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #53: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 02:34:26.962
cmqcwxqr2007jibng3wv2wpi9	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #54: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":77}	\N	not_queued	\N	\N	2026-05-15 02:39:26.962
cmqcwxqr2007kibngb6hz1hvp	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #55: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 02:44:26.962
cmqcwxqr2007libnghxlr4xph	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #56: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":20}	\N	not_queued	\N	\N	2026-05-15 02:49:26.962
cmqcwxqr2007mibngf9phwk2u	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #57: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 02:54:26.962
cmqcwxqr2007nibngd21ydkd9	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #58: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":102}	\N	not_queued	\N	\N	2026-05-15 02:59:26.962
cmqcwxqr2007oibngwer48935	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #59: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 03:04:26.962
cmqcwxqr2007pibngcad2pq15	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #60: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":105}	\N	not_queued	\N	\N	2026-05-15 03:09:26.962
cmqcwxqr2007qibngjvzs662p	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #61: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 03:14:26.962
cmqcwxqr2007ribng06bw36o0	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #62: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":118}	\N	not_queued	\N	\N	2026-05-15 03:19:26.962
cmqcwxqr2007sibngf7mctqmo	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #63: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 03:24:26.962
cmqcwxqr2007tibngn82f2k1q	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #64: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":74}	\N	not_queued	\N	\N	2026-05-15 03:29:26.962
cmqcwxqr2007uibngwy1lu8p1	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #65: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 03:34:26.962
cmqcwxqr2007vibngt6ejbr97	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #66: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":115}	\N	not_queued	\N	\N	2026-05-15 03:39:26.962
cmqcwxqr2007wibng2j83u0b4	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #67: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 03:44:26.962
cmqcwxqr2007xibngabsvc9ok	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #68: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":60}	\N	not_queued	\N	\N	2026-05-15 03:49:26.962
cmqcwxqr2007yibng8jwrqbbv	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #69: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 03:54:26.962
cmqcwxqr2007zibngpe2w9qbz	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #70: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":71}	\N	not_queued	\N	\N	2026-05-15 03:59:26.962
cmqcwxqr20080ibngncbp3zxj	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #71: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 04:04:26.962
cmqcwxqr20081ibng1i6k23de	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #72: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":104}	\N	not_queued	\N	\N	2026-05-15 04:09:26.962
cmqcwxqr20082ibngd2rndca4	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #73: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 04:14:26.962
cmqcwxqr20083ibngwofseoog	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #74: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":96}	\N	not_queued	\N	\N	2026-05-15 04:19:26.962
cmqcwxqr20084ibng7mru2xj8	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #75: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 04:24:26.962
cmqcwxqr20085ibnggzaosk5f	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #76: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":68}	\N	not_queued	\N	\N	2026-05-15 04:29:26.962
cmqcwxqr20086ibng1oeykt6n	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #77: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 04:34:26.962
cmqcwxqr20087ibngutw59ge8	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #78: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":111}	\N	not_queued	\N	\N	2026-05-15 04:39:26.962
cmqcwxqr20088ibng91sm0lob	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #79: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 04:44:26.962
cmqcwxqr20089ibngy1k4p9us	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #80: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":28}	\N	not_queued	\N	\N	2026-05-15 04:49:26.962
cmqcwxqr2008aibngug36graz	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #81: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 04:54:26.962
cmqcwxqr2008bibngb5z5gqz6	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #82: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":25}	\N	not_queued	\N	\N	2026-05-15 04:59:26.962
cmqcwxqr2008cibngm5sn1jwg	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #83: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 05:04:26.962
cmqcwxqr2008dibng6p41y94q	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #84: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":114}	\N	not_queued	\N	\N	2026-05-15 05:09:26.962
cmqcwxqr2008eibngqyfer3wa	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #85: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 05:14:26.962
cmqcwxqr2008fibnguji9iue7	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #86: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":92}	\N	not_queued	\N	\N	2026-05-15 05:19:26.962
cmqcwxqr2008gibng9npyh8vx	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #87: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 05:24:26.962
cmqcwxqr2008hibngr1p36nbd	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #88: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":86}	\N	not_queued	\N	\N	2026-05-15 05:29:26.962
cmqcwxqr2008iibng2tvq6jny	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #89: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 05:34:26.962
cmqcwxqr2008jibng9o0laaor	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #90: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":96}	\N	not_queued	\N	\N	2026-05-15 05:39:26.962
cmqcwxqr2008kibngd5zh5cny	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #91: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 05:44:26.962
cmqcwxqr2008libngan5f8a5e	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #92: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":96}	\N	not_queued	\N	\N	2026-05-15 05:49:26.962
cmqcwxqr2008mibngh9gpzskb	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #93: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 05:54:26.962
cmqcwxqr2008nibngp1jzyaps	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #94: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":49}	\N	not_queued	\N	\N	2026-05-15 05:59:26.962
cmqcwxqr2008oibngo06omdux	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #95: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 06:04:26.962
cmqcwxqr2008pibngcjno1rr0	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #96: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":90}	\N	not_queued	\N	\N	2026-05-15 06:09:26.962
cmqcwxqr2008qibngurke9kq3	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #97: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 06:14:26.962
cmqcwxqr2008ribngx7r6h1je	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #98: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":67}	\N	not_queued	\N	\N	2026-05-15 06:19:26.962
cmqcwxqr2008sibngqtxt3q0q	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #99: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 06:24:26.962
cmqcwxqr2008tibng99uh36pn	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #100: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":74}	\N	not_queued	\N	\N	2026-05-15 06:29:26.962
cmqcwxqr2008uibng8hzoi6zd	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #101: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 06:34:26.962
cmqcwxqr2008vibngq25o26er	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #102: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":62}	\N	not_queued	\N	\N	2026-05-15 06:39:26.962
cmqcwxqr2008wibngv15tpdfa	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #103: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 06:44:26.962
cmqcwxqr2008xibngxy3uyntx	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #104: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":66}	\N	not_queued	\N	\N	2026-05-15 06:49:26.962
cmqcwxqr2008yibngbgnufl5v	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #105: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 06:54:26.962
cmqcwxqr2008zibngm5kzxjp4	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #106: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":44}	\N	not_queued	\N	\N	2026-05-15 06:59:26.962
cmqcwxqr20090ibngv57npe0o	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #107: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 07:04:26.962
cmqcwxqr20091ibngptiyed1a	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #108: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":87}	\N	not_queued	\N	\N	2026-05-15 07:09:26.962
cmqcwxqr20092ibngiigp2aqd	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #109: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 07:14:26.962
cmqcwxqr20093ibngq030d0e5	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #110: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":52}	\N	not_queued	\N	\N	2026-05-15 07:19:26.962
cmqcwxqr20094ibnguewqawpv	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #111: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 07:24:26.962
cmqcwxqr20095ibngxzkdpfzt	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #112: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":59}	\N	not_queued	\N	\N	2026-05-15 07:29:26.962
cmqcwxqr20096ibnggl0nsc8f	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #113: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 07:34:26.962
cmqcwxqr20097ibngxq5qmfqv	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #114: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":93}	\N	not_queued	\N	\N	2026-05-15 07:39:26.962
cmqcwxqr20098ibng8bpyxemp	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #115: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 07:44:26.962
cmqcwxqr20099ibnga6ro6r1d	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #116: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":60}	\N	not_queued	\N	\N	2026-05-15 07:49:26.962
cmqcwxqr2009aibngzb4fubvt	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #117: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 07:54:26.962
cmqcwxqr2009bibnges19923n	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #118: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":94}	\N	not_queued	\N	\N	2026-05-15 07:59:26.962
cmqcwxqr2009cibnggsajyp1a	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #119: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 08:04:26.962
cmqcwxqr2009dibngrz202kr2	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #120: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":77}	\N	not_queued	\N	\N	2026-05-15 08:09:26.962
cmqcwxqr2009eibngq8w5y3fh	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #121: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 08:14:26.962
cmqcwxqr2009fibngskeuxtmy	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #122: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":101}	\N	not_queued	\N	\N	2026-05-15 08:19:26.962
cmqcwxqr2009gibng0l4aj6gd	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #123: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 08:24:26.962
cmqcwxqr2009hibng5az6abnh	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #124: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":99}	\N	not_queued	\N	\N	2026-05-15 08:29:26.962
cmqcwxqr2009iibng8jmlkquo	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #125: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 08:34:26.962
cmqcwxqr2009jibngvvibqd5b	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #126: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":52}	\N	not_queued	\N	\N	2026-05-15 08:39:26.962
cmqcwxqr2009kibngjc2czalj	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #127: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 08:44:26.962
cmqcwxqr2009libngitzynt1l	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #128: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":97}	\N	not_queued	\N	\N	2026-05-15 08:49:26.962
cmqcwxqr2009mibngvigvmmkg	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #129: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 08:54:26.962
cmqcwxqr2009nibnggce3a2yh	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #130: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":76}	\N	not_queued	\N	\N	2026-05-15 08:59:26.962
cmqcwxqr2009oibng68wk4bxj	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #131: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 09:04:26.962
cmqcwxqr2009pibngyb3zojne	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #132: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":27}	\N	not_queued	\N	\N	2026-05-15 09:09:26.962
cmqcwxqr2009qibngqw3hoxnm	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #133: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 09:14:26.962
cmqcwxqr2009ribngika9racq	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #134: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":80}	\N	not_queued	\N	\N	2026-05-15 09:19:26.962
cmqcwxqr2009sibngq1yvxgu3	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #135: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 09:24:26.962
cmqcwxqr2009tibngho95gybi	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #136: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":40}	\N	not_queued	\N	\N	2026-05-15 09:29:26.962
cmqcwxqr2009uibngd8gz0e4v	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #137: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 09:34:26.962
cmqcwxqr2009vibngpc2u1s9v	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #138: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":32}	\N	not_queued	\N	\N	2026-05-15 09:39:26.962
cmqcwxqr2009wibngyphmyqxj	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #139: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 09:44:26.962
cmqcwxqr2009xibngfxvzkyyr	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #140: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":118}	\N	not_queued	\N	\N	2026-05-15 09:49:26.962
cmqcwxqr2009yibng4phw0xwa	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #141: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 09:54:26.962
cmqcwxqr2009zibngl06xjw6i	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #142: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":99}	\N	not_queued	\N	\N	2026-05-15 09:59:26.962
cmqcwxqr200a0ibngworx9la2	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #143: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 10:04:26.962
cmqcwxqr200a1ibngq9jvle4t	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #144: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":115}	\N	not_queued	\N	\N	2026-05-15 10:09:26.962
cmqcwxqr200a2ibngf9cbmlau	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #145: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 10:14:26.962
cmqcwxqr200a3ibngsdnpeoku	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #146: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":36}	\N	not_queued	\N	\N	2026-05-15 10:19:26.962
cmqcwxqr200a4ibngxpkzhjwz	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #147: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 10:24:26.962
cmqcwxqr200a5ibngc19hs2p1	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #148: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":75}	\N	not_queued	\N	\N	2026-05-15 10:29:26.962
cmqcwxqr200a6ibnghkko4fjv	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #149: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 10:34:26.962
cmqcwxqr200a7ibngerci177o	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #150: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":46}	\N	not_queued	\N	\N	2026-05-15 10:39:26.962
cmqcwxqr200a8ibng4y84zihk	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #151: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 10:44:26.962
cmqcwxqr200a9ibngph9jkoj3	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #152: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":98}	\N	not_queued	\N	\N	2026-05-15 10:49:26.962
cmqcwxqr200aaibnggfh6mutq	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #153: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 10:54:26.962
cmqcwxqr200abibngud9ravql	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #154: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":83}	\N	not_queued	\N	\N	2026-05-15 10:59:26.962
cmqcwxqr200acibngbtea9p80	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #155: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 11:04:26.962
cmqcwxqr200adibngq57593cm	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #156: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":46}	\N	not_queued	\N	\N	2026-05-15 11:09:26.962
cmqcwxqr200aeibngjr5xqy5i	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #157: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 11:14:26.962
cmqcwxqr200afibng8b74rj3p	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #158: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":45}	\N	not_queued	\N	\N	2026-05-15 11:19:26.962
cmqcwxqr200agibng4jzkqdpa	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #159: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 11:24:26.962
cmqcwxqr200ahibnguzk3nw99	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #160: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":115}	\N	not_queued	\N	\N	2026-05-15 11:29:26.962
cmqcwxqr200aiibngnhs44j1n	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #161: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 11:34:26.962
cmqcwxqr200ajibng6ovlgqqi	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #162: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":117}	\N	not_queued	\N	\N	2026-05-15 11:39:26.962
cmqcwxqr200akibng04fzhjea	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #163: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 11:44:26.962
cmqcwxqr200alibng14bnihhj	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #164: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":22}	\N	not_queued	\N	\N	2026-05-15 11:49:26.962
cmqcwxqr200amibngxgmfeff6	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #165: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 11:54:26.962
cmqcwxqr200anibng8eiiwpt3	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #166: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":41}	\N	not_queued	\N	\N	2026-05-15 11:59:26.962
cmqcwxqr200aoibngrt8jsq8c	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #167: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 12:04:26.962
cmqcwxqr200apibng0tt99bm8	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #168: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":108}	\N	not_queued	\N	\N	2026-05-15 12:09:26.962
cmqcwxqr200aqibng9k3tnqcr	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #169: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 12:14:26.962
cmqcwxqr200aribngs1d8rar0	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #170: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":23}	\N	not_queued	\N	\N	2026-05-15 12:19:26.962
cmqcwxqr200asibng8oydm2ps	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #171: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 12:24:26.962
cmqcwxqr200atibngkjihpy2m	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #172: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":52}	\N	not_queued	\N	\N	2026-05-15 12:29:26.962
cmqcwxqr200auibnghyhx5qq9	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #173: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 12:34:26.962
cmqcwxqr200avibngj5jw79tc	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #174: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":117}	\N	not_queued	\N	\N	2026-05-15 12:39:26.962
cmqcwxqr200awibngsvalu4tq	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #175: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 12:44:26.962
cmqcwxqr200axibnggyt4c5ux	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #176: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":40}	\N	not_queued	\N	\N	2026-05-15 12:49:26.962
cmqcwxqr200ayibng5e65rwew	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #177: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 12:54:26.962
cmqcwxqr200azibngvzw1atyo	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #178: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":92}	\N	not_queued	\N	\N	2026-05-15 12:59:26.962
cmqcwxqr200b0ibnguwpivctt	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #179: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 13:04:26.962
cmqcwxqr200b1ibng34lo3jsq	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #180: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":24}	\N	not_queued	\N	\N	2026-05-15 13:09:26.962
cmqcwxqr200b2ibngecvlrm5w	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #181: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 13:14:26.962
cmqcwxqr200b3ibngrnvkyjs1	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #182: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":69}	\N	not_queued	\N	\N	2026-05-15 13:19:26.962
cmqcwxqr200b4ibngt9uacd0u	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #183: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 13:24:26.962
cmqcwxqr200b5ibngsw3rgobm	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #184: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":63}	\N	not_queued	\N	\N	2026-05-15 13:29:26.962
cmqcwxqr200b6ibngs246fzje	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #185: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 13:34:26.962
cmqcwxqr200b7ibngf6y3si6u	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #186: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":113}	\N	not_queued	\N	\N	2026-05-15 13:39:26.962
cmqcwxqr200b8ibng8ufa7pna	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #187: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 13:44:26.962
cmqcwxqr200b9ibngqn0xxniv	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #188: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":83}	\N	not_queued	\N	\N	2026-05-15 13:49:26.962
cmqcwxqr200baibngzp1fw84j	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #189: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 13:54:26.962
cmqcwxqr200bbibngra61bz56	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #190: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":68}	\N	not_queued	\N	\N	2026-05-15 13:59:26.962
cmqcwxqr200bcibng6e3gmx38	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #191: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 14:04:26.962
cmqcwxqr200bdibnguvo3kkod	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #192: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":26}	\N	not_queued	\N	\N	2026-05-15 14:09:26.962
cmqcwxqr200beibnghgy973om	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #193: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 14:14:26.962
cmqcwxqr200bfibng0hd27hqk	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #194: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":27}	\N	not_queued	\N	\N	2026-05-15 14:19:26.962
cmqcwxqr200bgibng8dipyynq	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #195: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 14:24:26.962
cmqcwxqr200bhibngfho7a7r4	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #196: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":54}	\N	not_queued	\N	\N	2026-05-15 14:29:26.962
cmqcwxqr200biibng24o7xhox	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #197: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 14:34:26.962
cmqcwxqr200bjibngpcuamexd	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #198: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":50}	\N	not_queued	\N	\N	2026-05-15 14:39:26.962
cmqcwxqr200bkibng51sqp113	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #199: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 14:44:26.962
cmqcwxqr200blibngnaos5vkq	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #200: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":74}	\N	not_queued	\N	\N	2026-05-15 14:49:26.962
cmqcwxqr200bmibngm5dmqqfe	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #201: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 14:54:26.962
cmqcwxqr200bnibnggrteecet	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #202: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":87}	\N	not_queued	\N	\N	2026-05-15 14:59:26.962
cmqcwxqr200boibngrdyqsybd	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #203: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 15:04:26.962
cmqcwxqr200bpibng8qoqnoui	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #204: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":110}	\N	not_queued	\N	\N	2026-05-15 15:09:26.962
cmqcwxqr200bqibnga7931ecv	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #205: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 15:14:26.962
cmqcwxqr200bribngyv9cfkw5	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #206: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":114}	\N	not_queued	\N	\N	2026-05-15 15:19:26.962
cmqcwxqr200bsibngaugo6q9y	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #207: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 15:24:26.962
cmqcwxqr200btibng9s77fq7q	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #208: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":22}	\N	not_queued	\N	\N	2026-05-15 15:29:26.962
cmqcwxqr200buibng0hydi57t	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #209: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 15:34:26.962
cmqcwxqr200bvibngmsui27td	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #210: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":91}	\N	not_queued	\N	\N	2026-05-15 15:39:26.962
cmqcwxqr200bwibngtzbzfpoc	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #211: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 15:44:26.962
cmqcwxqr200bxibngkqu8f9g3	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #212: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":109}	\N	not_queued	\N	\N	2026-05-15 15:49:26.962
cmqcwxqr200byibngerpnpqkv	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #213: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 15:54:26.962
cmqcwxqr200bzibng7bo7rcnm	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #214: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":102}	\N	not_queued	\N	\N	2026-05-15 15:59:26.962
cmqcwxqr200c0ibngssyox09p	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #215: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 16:04:26.962
cmqcwxqr200c1ibngua4gqrm9	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #216: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":75}	\N	not_queued	\N	\N	2026-05-15 16:09:26.962
cmqcwxqr200c2ibng9x85b0h2	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #217: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 16:14:26.962
cmqcwxqr200c3ibngyiufomdy	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #218: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":25}	\N	not_queued	\N	\N	2026-05-15 16:19:26.962
cmqcwxqr200c4ibngcvcrk3xz	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #219: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 16:24:26.962
cmqcwxqr200c5ibngd2yi951v	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #220: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":81}	\N	not_queued	\N	\N	2026-05-15 16:29:26.962
cmqcwxqr200c6ibngp9wtkn3f	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #221: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 16:34:26.962
cmqcwxqr200c7ibnglg3g5a04	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #222: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":83}	\N	not_queued	\N	\N	2026-05-15 16:39:26.962
cmqcwxqr200c8ibngc7lntnc6	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #223: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 16:44:26.962
cmqcwxqr200c9ibngxp0cslr7	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #224: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":42}	\N	not_queued	\N	\N	2026-05-15 16:49:26.962
cmqcwxqr200caibngrasmpzca	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #225: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 16:54:26.962
cmqcwxqr200cbibng5narbd1y	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #226: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":23}	\N	not_queued	\N	\N	2026-05-15 16:59:26.962
cmqcwxqr200ccibng4dvqfl0h	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #227: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 17:04:26.962
cmqcwxqr200cdibngdcvn0ga7	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #228: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":55}	\N	not_queued	\N	\N	2026-05-15 17:09:26.962
cmqcwxqr200ceibng5nqesace	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #229: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 17:14:26.962
cmqcwxqr200cfibngjk59vugq	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #230: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":86}	\N	not_queued	\N	\N	2026-05-15 17:19:26.962
cmqcwxqr200cgibngkhng6b1x	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #231: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 17:24:26.962
cmqcwxqr200chibngdwa8citk	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #232: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":116}	\N	not_queued	\N	\N	2026-05-15 17:29:26.962
cmqcwxqr200ciibngvq5trghe	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #233: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 17:34:26.962
cmqcwxqr200cjibngfont8o25	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #234: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":111}	\N	not_queued	\N	\N	2026-05-15 17:39:26.962
cmqcwxqr200ckibngu20igw9n	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #235: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 17:44:26.962
cmqcwxqr200clibngd371bzh0	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #236: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":107}	\N	not_queued	\N	\N	2026-05-15 17:49:26.962
cmqcwxqr200cmibngsef6efbg	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #237: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 17:54:26.962
cmqcwxqr200cnibng84xtvrpv	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #238: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":108}	\N	not_queued	\N	\N	2026-05-15 17:59:26.962
cmqcwxqr200coibngw5rkfpi1	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #239: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 18:04:26.962
cmqcwxqr200cpibnga0nvlijh	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #240: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":59}	\N	not_queued	\N	\N	2026-05-15 18:09:26.962
cmqcwxqr200cqibng8wa2xxu7	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #241: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 18:14:26.962
cmqcwxqr200cribngk3mefw8b	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #242: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":51}	\N	not_queued	\N	\N	2026-05-15 18:19:26.962
cmqcwxqr200csibng3l21p5wi	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #243: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 18:24:26.962
cmqcwxqr200ctibngrnhq0dyp	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #244: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":85}	\N	not_queued	\N	\N	2026-05-15 18:29:26.962
cmqcwxqr200cuibng4t4oke2e	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #245: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 18:34:26.962
cmqcwxqr200cvibng8csx4v0k	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #246: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":40}	\N	not_queued	\N	\N	2026-05-15 18:39:26.962
cmqcwxqr200cwibngtmkh3puf	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #247: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 18:44:26.962
cmqcwxqr200cxibngui411pjw	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #248: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":97}	\N	not_queued	\N	\N	2026-05-15 18:49:26.962
cmqcwxqr200cyibngvtxc6v6u	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #249: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 18:54:26.962
cmqcwxqr200czibngxkny1g1w	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #250: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":42}	\N	not_queued	\N	\N	2026-05-15 18:59:26.962
cmqcwxqr200d0ibngz62t4i8c	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #251: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 19:04:26.962
cmqcwxqr200d1ibngankmokth	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #252: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":64}	\N	not_queued	\N	\N	2026-05-15 19:09:26.962
cmqcwxqr200d2ibngf28ryzsh	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #253: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 19:14:26.962
cmqcwxqr200d3ibngr1tun3nd	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #254: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":49}	\N	not_queued	\N	\N	2026-05-15 19:19:26.962
cmqcwxqr200d4ibnghkqfty2t	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #255: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 19:24:26.962
cmqcwxqr200d5ibng9jow4wwx	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #256: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":66}	\N	not_queued	\N	\N	2026-05-15 19:29:26.962
cmqcwxqr200d6ibngq51g69jd	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #257: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 19:34:26.962
cmqcwxqr200d7ibngt6kujpi3	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #258: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":54}	\N	not_queued	\N	\N	2026-05-15 19:39:26.962
cmqcwxqr200d8ibngq6rtdepk	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #259: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 19:44:26.962
cmqcwxqr200d9ibngr5jwdvf5	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #260: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":88}	\N	not_queued	\N	\N	2026-05-15 19:49:26.962
cmqcwxqr200daibng5nnxce0v	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #261: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 19:54:26.962
cmqcwxqr200dbibng898rho4x	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #262: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":79}	\N	not_queued	\N	\N	2026-05-15 19:59:26.962
cmqcwxqr200dcibngin8huocj	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #263: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 20:04:26.962
cmqcwxqr200ddibng0dh0nzyu	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #264: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":72}	\N	not_queued	\N	\N	2026-05-15 20:09:26.962
cmqcwxqr200deibngrij5wj32	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #265: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 20:14:26.962
cmqcwxqr200dfibngx8b0o0ow	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #266: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":61}	\N	not_queued	\N	\N	2026-05-15 20:19:26.962
cmqcwxqr200dgibngr6z1dhxx	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #267: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 20:24:26.962
cmqcwxqr200dhibngg40nq03y	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #268: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":91}	\N	not_queued	\N	\N	2026-05-15 20:29:26.962
cmqcwxqr200diibng7gsvcr56	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #269: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 20:34:26.962
cmqcwxqr200djibngzw6kjfir	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #270: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":60}	\N	not_queued	\N	\N	2026-05-15 20:39:26.962
cmqcwxqr200dkibngblmr67cn	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #271: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 20:44:26.962
cmqcwxqr200dlibng4lgr5iir	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #272: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":101}	\N	not_queued	\N	\N	2026-05-15 20:49:26.962
cmqcwxqr200dmibngchx08hrr	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #273: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 20:54:26.962
cmqcwxqr200dnibng7a7x5akh	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #274: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":119}	\N	not_queued	\N	\N	2026-05-15 20:59:26.962
cmqcwxqr200doibngwlvjmbf4	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #275: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 21:04:26.962
cmqcwxqr200dpibnglody4d87	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #276: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":114}	\N	not_queued	\N	\N	2026-05-15 21:09:26.962
cmqcwxqr200dqibngwofmifx6	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #277: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 21:14:26.962
cmqcwxqr200dribngkhdiza99	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #278: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":26}	\N	not_queued	\N	\N	2026-05-15 21:19:26.962
cmqcwxqr200dsibngbq37o1a9	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #279: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 21:24:26.962
cmqcwxqr200dtibngbswt7up9	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #280: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":87}	\N	not_queued	\N	\N	2026-05-15 21:29:26.962
cmqcwxqr200duibng9x5zvrth	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #281: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 21:34:26.962
cmqcwxqr200dvibngy9pkck9e	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #282: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":43}	\N	not_queued	\N	\N	2026-05-15 21:39:26.962
cmqcwxqr200dwibngdwsrocpj	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #283: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 21:44:26.962
cmqcwxqr200dxibngjqo4z9rz	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #284: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":29}	\N	not_queued	\N	\N	2026-05-15 21:49:26.962
cmqcwxqr200dyibngwe98k0j0	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #285: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 21:54:26.962
cmqcwxqr200dzibngr6nq8cwj	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #286: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":117}	\N	not_queued	\N	\N	2026-05-15 21:59:26.962
cmqcwxqr200e0ibngblsc7794	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #287: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 22:04:26.962
cmqcwxqr200e1ibngol64sy3t	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #288: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":107}	\N	not_queued	\N	\N	2026-05-15 22:09:26.962
cmqcwxqr200e2ibngeve6f63h	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #289: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 22:14:26.962
cmqcwxqr200e3ibngsj9raqau	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #290: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":115}	\N	not_queued	\N	\N	2026-05-15 22:19:26.962
cmqcwxqr200e4ibngjl13r96i	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #291: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 22:24:26.962
cmqcwxqr200e5ibngq5k77r25	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #292: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":24}	\N	not_queued	\N	\N	2026-05-15 22:29:26.962
cmqcwxqr200e6ibnggu9qdg92	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #293: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 22:34:26.962
cmqcwxqr200e7ibngcr178zhj	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #294: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":64}	\N	not_queued	\N	\N	2026-05-15 22:39:26.962
cmqcwxqr200e8ibngbv3azu4x	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #295: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 22:44:26.962
cmqcwxqr200e9ibngp6rzm5oh	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #296: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":99}	\N	not_queued	\N	\N	2026-05-15 22:49:26.962
cmqcwxqr200eaibng9ygh84m4	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #297: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 22:54:26.962
cmqcwxqr200ebibngjgbzqotm	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #298: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":66}	\N	not_queued	\N	\N	2026-05-15 22:59:26.962
cmqcwxqr200ecibngjxix4pjm	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #299: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 23:04:26.962
cmqcwxqr200edibng1atmqjx5	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #300: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":54}	\N	not_queued	\N	\N	2026-05-15 23:09:26.962
cmqcwxqr200eeibngzisjbce5	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #301: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 23:14:26.962
cmqcwxqr200efibngrmqegv8f	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #302: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":23}	\N	not_queued	\N	\N	2026-05-15 23:19:26.962
cmqcwxqr200egibngugjrpok8	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #303: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 23:24:26.962
cmqcwxqr200ehibng1nyqjnl8	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #304: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":33}	\N	not_queued	\N	\N	2026-05-15 23:29:26.962
cmqcwxqr200eiibng576ircm6	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #305: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 23:34:26.962
cmqcwxqr200ejibngukfm8z7x	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #306: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":113}	\N	not_queued	\N	\N	2026-05-15 23:39:26.962
cmqcwxqr200ekibngnkfx8zsk	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #307: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 23:44:26.962
cmqcwxqr200elibng3wo4ua5t	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #308: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":49}	\N	not_queued	\N	\N	2026-05-15 23:49:26.962
cmqcwxqr200emibngl4wsxeok	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #309: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-15 23:54:26.962
cmqcwxqr200enibng0pcd2rz7	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #310: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":22}	\N	not_queued	\N	\N	2026-05-15 23:59:26.962
cmqcwxqr200eoibngjs43p3r3	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #311: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-16 00:04:26.962
cmqcwxqr200epibngviogkcj1	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #312: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":91}	\N	not_queued	\N	\N	2026-05-16 00:09:26.962
cmqcwxqr200eqibngoy5k7n39	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #313: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-16 00:14:26.962
cmqcwxqr200eribnggex6xjbh	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #314: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":41}	\N	not_queued	\N	\N	2026-05-16 00:19:26.962
cmqcwxqr200esibngzga1d10h	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #315: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-16 00:24:26.962
cmqcwxqr200etibngeunkk8sb	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #316: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":75}	\N	not_queued	\N	\N	2026-05-16 00:29:26.962
cmqcwxqr200euibngs4cgxxx5	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #317: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-16 00:34:26.962
cmqcwxqr200evibngjc0d6sfl	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #318: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":94}	\N	not_queued	\N	\N	2026-05-16 00:39:26.962
cmqcwxqr200ewibng8by08lw4	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #319: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-16 00:44:26.962
cmqcwxqr200exibngieqk6jkb	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #320: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":85}	\N	not_queued	\N	\N	2026-05-16 00:49:26.962
cmqcwxqr200eyibngxr71hso8	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #321: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-16 00:54:26.962
cmqcwxqr200ezibngr1oc42q0	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #322: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":74}	\N	not_queued	\N	\N	2026-05-16 00:59:26.962
cmqcwxqr200f0ibngttw72qjm	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #323: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-16 01:04:26.962
cmqcwxqr200f1ibng0v73ps6b	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #324: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":58}	\N	not_queued	\N	\N	2026-05-16 01:09:26.962
cmqcwxqr200f2ibngrgi5dm6c	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #325: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-16 01:14:26.962
cmqcwxqr200f3ibngaahr307d	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #326: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":29}	\N	not_queued	\N	\N	2026-05-16 01:19:26.962
cmqcwxqr200f4ibng9yrjsk8j	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #327: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-16 01:24:26.962
cmqcwxqr200f5ibngia9rc2zr	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #328: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":48}	\N	not_queued	\N	\N	2026-05-16 01:29:26.962
cmqcwxqr200f6ibngc6mrkmji	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #329: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-16 01:34:26.962
cmqcwxqr200f7ibngqqd4bco0	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #330: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":91}	\N	not_queued	\N	\N	2026-05-16 01:39:26.962
cmqcwxqr200f8ibngo7y9oaym	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #331: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-16 01:44:26.962
cmqcwxqr200f9ibng8o330g8v	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #332: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":29}	\N	not_queued	\N	\N	2026-05-16 01:49:26.962
cmqcwxqr200faibngcez5exl2	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #333: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-16 01:54:26.962
cmqcwxqr200fbibnglopzut64	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #334: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":51}	\N	not_queued	\N	\N	2026-05-16 01:59:26.962
cmqcwxqr200fcibngrl2plikw	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #335: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-16 02:04:26.962
cmqcwxqr200fdibngk6kl3o6x	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #336: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":43}	\N	not_queued	\N	\N	2026-05-16 02:09:26.962
cmqcwxqr200feibngol1zt95z	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #337: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-16 02:14:26.962
cmqcwxqr200ffibngrn2zexuj	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #338: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":62}	\N	not_queued	\N	\N	2026-05-16 02:19:26.962
cmqcwxqr200fgibngbghb6zye	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #339: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-16 02:24:26.962
cmqcwxqr200fhibngdwajfwxk	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #340: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":35}	\N	not_queued	\N	\N	2026-05-16 02:29:26.962
cmqcwxqr200fiibng2v1acaxy	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #341: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-16 02:34:26.962
cmqcwxqr200fjibng2968c0t4	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #342: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":70}	\N	not_queued	\N	\N	2026-05-16 02:39:26.962
cmqcwxqr200fkibng291hn7bd	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #343: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-16 02:44:26.962
cmqcwxqr200flibng46y8we09	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #344: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":86}	\N	not_queued	\N	\N	2026-05-16 02:49:26.962
cmqcwxqr200fmibnguzlrud24	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #345: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-16 02:54:26.962
cmqcwxqr200fnibngqk45hatf	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #346: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":100}	\N	not_queued	\N	\N	2026-05-16 02:59:26.962
cmqcwxqr200foibng1udht4rm	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #347: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-16 03:04:26.962
cmqcwxqr200fpibngq2s2acpp	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #348: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":41}	\N	not_queued	\N	\N	2026-05-16 03:09:26.962
cmqcwxqr200fqibngv7dvhbh1	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #349: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-16 03:14:26.962
cmqcwxqr200fribngig1vpq1z	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #350: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":87}	\N	not_queued	\N	\N	2026-05-16 03:19:26.962
cmqcwxqr200fsibnglrjou1fm	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #351: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-16 03:24:26.962
cmqcwxqr200ftibngg9gqoofn	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #352: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":52}	\N	not_queued	\N	\N	2026-05-16 03:29:26.962
cmqcwxqr200fuibng6crd0m71	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #353: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-16 03:34:26.962
cmqcwxqr200fvibnghx9cm0e5	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #354: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":98}	\N	not_queued	\N	\N	2026-05-16 03:39:26.962
cmqcwxqr200fwibngx4zdqdua	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #355: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-16 03:44:26.962
cmqcwxqr200fxibngxipx671o	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #356: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":55}	\N	not_queued	\N	\N	2026-05-16 03:49:26.962
cmqcwxqr200fyibng399r55ph	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #357: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-16 03:54:26.962
cmqcwxqr200fzibngp9lzkxhk	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #358: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":23}	\N	not_queued	\N	\N	2026-05-16 03:59:26.962
cmqcwxqr200g0ibng96qtozik	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #359: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-16 04:04:26.962
cmqcwxqr200g1ibngw5684rab	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #360: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":60}	\N	not_queued	\N	\N	2026-05-16 04:09:26.962
cmqcwxqr200g2ibng88itjzhd	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #361: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-16 04:14:26.962
cmqcwxqr200g3ibngevue1pvs	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #362: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":112}	\N	not_queued	\N	\N	2026-05-16 04:19:26.962
cmqcwxqr200g4ibngq1he89ev	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #363: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-16 04:24:26.962
cmqcwxqr200g5ibngvsgh8xft	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #364: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":82}	\N	not_queued	\N	\N	2026-05-16 04:29:26.962
cmqcwxqr200g6ibngcfsrn2h4	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #365: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-16 04:34:26.962
cmqcwxqr200g7ibngexg8psbm	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #366: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":73}	\N	not_queued	\N	\N	2026-05-16 04:39:26.962
cmqcwxqr200g8ibng8bmpw89l	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #367: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-16 04:44:26.962
cmqcwxqr200g9ibngd9d8k6qd	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #368: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":43}	\N	not_queued	\N	\N	2026-05-16 04:49:26.962
cmqcwxqr200gaibngxlz2b2mw	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #369: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-16 04:54:26.962
cmqcwxqr200gbibngowug2fha	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #370: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":100}	\N	not_queued	\N	\N	2026-05-16 04:59:26.962
cmqcwxqr200gcibngraykhlii	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #371: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-16 05:04:26.962
cmqcwxqr200gdibng7grx4xkm	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #372: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":90}	\N	not_queued	\N	\N	2026-05-16 05:09:26.962
cmqcwxqr200geibngejg6gdoq	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #373: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-16 05:14:26.962
cmqcwxqr200gfibng0g1ygxsz	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #374: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":27}	\N	not_queued	\N	\N	2026-05-16 05:19:26.962
cmqcwxqr200ggibngb0mjq5yl	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #375: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-16 05:24:26.962
cmqcwxqr200ghibngdlke0rda	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #376: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":86}	\N	not_queued	\N	\N	2026-05-16 05:29:26.962
cmqcwxqr200giibngw9h0amec	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #377: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-16 05:34:26.962
cmqcwxqr200gjibngg850geic	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #378: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":110}	\N	not_queued	\N	\N	2026-05-16 05:39:26.962
cmqcwxqr200gkibngqq1ixw00	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #379: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-16 05:44:26.962
cmqcwxqr200glibng0lcehhic	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #380: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":84}	\N	not_queued	\N	\N	2026-05-16 05:49:26.962
cmqcwxqr200gmibng6uhl6ury	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #381: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-16 05:54:26.962
cmqcwxqr200gnibng207a0oof	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #382: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":38}	\N	not_queued	\N	\N	2026-05-16 05:59:26.962
cmqcwxqr200goibngs2n60fbh	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #383: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-16 06:04:26.962
cmqcwxqr200gpibng70gnrrx4	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #384: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":73}	\N	not_queued	\N	\N	2026-05-16 06:09:26.962
cmqcwxqr200gqibngp28msj0q	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #385: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-16 06:14:26.962
cmqcwxqr200gribnghzza70rq	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #386: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":31}	\N	not_queued	\N	\N	2026-05-16 06:19:26.962
cmqcwxqr200gsibngp8he52qs	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #387: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-16 06:24:26.962
cmqcwxqr200gtibnglhty41vc	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #388: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":111}	\N	not_queued	\N	\N	2026-05-16 06:29:26.962
cmqcwxqr200guibng4xs3rw3c	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #389: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-16 06:34:26.962
cmqcwxqr200gvibngc266qy4a	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #390: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":88}	\N	not_queued	\N	\N	2026-05-16 06:39:26.962
cmqcwxqr200gwibngqdyjggla	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #391: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-16 06:44:26.962
cmqcwxqr200gxibngcc84h9e7	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #392: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":105}	\N	not_queued	\N	\N	2026-05-16 06:49:26.962
cmqcwxqr200gyibngvj0vn10t	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #393: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-16 06:54:26.962
cmqcwxqr200gzibngwvowl21j	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #394: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":58}	\N	not_queued	\N	\N	2026-05-16 06:59:26.962
cmqcwxqr200h0ibng7ahgn2si	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #395: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-16 07:04:26.962
cmqcwxqr200h1ibngpkace2y5	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #396: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":118}	\N	not_queued	\N	\N	2026-05-16 07:09:26.962
cmqcwxqr200h2ibngqs3le7mq	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #397: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-16 07:14:26.962
cmqcwxqr200h3ibngy5sgp1yp	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #398: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":103}	\N	not_queued	\N	\N	2026-05-16 07:19:26.962
cmqcwxqr200h4ibngjqb7k61m	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #399: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-16 07:24:26.962
cmqcwxqr200h5ibng8862blic	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #400: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":115}	\N	not_queued	\N	\N	2026-05-16 07:29:26.962
cmqcwxqr200h6ibngsz0qrem2	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #401: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-16 07:34:26.962
cmqcwxqr200h7ibngzs5i1n7w	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #402: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":85}	\N	not_queued	\N	\N	2026-05-16 07:39:26.962
cmqcwxqr200h8ibng4o3tfij8	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #403: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-16 07:44:26.962
cmqcwxqr200h9ibng66ndqe1h	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #404: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":70}	\N	not_queued	\N	\N	2026-05-16 07:49:26.962
cmqcwxqr200haibngxjui9twt	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #405: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-16 07:54:26.962
cmqcwxqr200hbibng7rpv91ng	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #406: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":90}	\N	not_queued	\N	\N	2026-05-16 07:59:26.962
cmqcwxqr200hcibng4llypd1n	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #407: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-16 08:04:26.962
cmqcwxqr200hdibng40elj84f	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #408: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":35}	\N	not_queued	\N	\N	2026-05-16 08:09:26.962
cmqcwxqr200heibngf8hlyqiy	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #409: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-16 08:14:26.962
cmqcwxqr200hfibngl4js9vtv	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #410: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":53}	\N	not_queued	\N	\N	2026-05-16 08:19:26.962
cmqcwxqr200hgibng5pkntt5z	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #411: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-16 08:24:26.962
cmqcwxqr200hhibnguzbzsgdg	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #412: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":94}	\N	not_queued	\N	\N	2026-05-16 08:29:26.962
cmqcwxqr200hiibng46lexun4	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #413: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-16 08:34:26.962
cmqcwxqr200hjibngtjhil8jp	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #414: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":112}	\N	not_queued	\N	\N	2026-05-16 08:39:26.962
cmqcwxqr200hkibngc9a93uo4	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #415: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-16 08:44:26.962
cmqcwxqr200hlibngl365to64	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #416: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":64}	\N	not_queued	\N	\N	2026-05-16 08:49:26.962
cmqcwxqr200hmibngg1l2cced	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #417: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-16 08:54:26.962
cmqcwxqr200hnibngniv9rxf7	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #418: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":59}	\N	not_queued	\N	\N	2026-05-16 08:59:26.962
cmqcwxqr200hoibng5bq4ui7s	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #419: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-16 09:04:26.962
cmqcwxqr200hpibngr7p455br	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #420: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":63}	\N	not_queued	\N	\N	2026-05-16 09:09:26.962
cmqcwxqr200hqibng2r0prz5n	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #421: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-16 09:14:26.962
cmqcwxqr200hribngvk1soovy	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #422: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":113}	\N	not_queued	\N	\N	2026-05-16 09:19:26.962
cmqcwxqr200hsibng87u8eqbr	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #423: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-16 09:24:26.962
cmqcwxqr200htibngfjl7nwwo	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #424: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":44}	\N	not_queued	\N	\N	2026-05-16 09:29:26.962
cmqcwxqr200huibng1o6khbde	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #425: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-16 09:34:26.962
cmqcwxqr200hvibngnbsldqlx	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #426: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":61}	\N	not_queued	\N	\N	2026-05-16 09:39:26.962
cmqcwxqr200hwibngja38v45o	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #427: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-16 09:44:26.962
cmqcwxqr200hxibngxh8znm7m	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #428: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":40}	\N	not_queued	\N	\N	2026-05-16 09:49:26.962
cmqcwxqr200hyibnghachgr6i	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #429: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-16 09:54:26.962
cmqcwxqr200hzibngnqumnkif	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #430: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":38}	\N	not_queued	\N	\N	2026-05-16 09:59:26.962
cmqcwxqr200i0ibngxd5s0npd	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #431: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-16 10:04:26.962
cmqcwxqr200i1ibnge5142aes	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #432: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":48}	\N	not_queued	\N	\N	2026-05-16 10:09:26.962
cmqcwxqr200i2ibng9pek4c80	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #433: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-16 10:14:26.962
cmqcwxqr200i3ibng9nrqzcep	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #434: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":85}	\N	not_queued	\N	\N	2026-05-16 10:19:26.962
cmqcwxqr200i4ibngd9uhkm7e	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #435: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-16 10:24:26.962
cmqcwxqr200i5ibngj1jz31cf	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #436: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":103}	\N	not_queued	\N	\N	2026-05-16 10:29:26.962
cmqcwxqr200i6ibng2wg7lwo8	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #437: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-16 10:34:26.962
cmqcwxqr200i7ibngv6x77i9n	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #438: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":62}	\N	not_queued	\N	\N	2026-05-16 10:39:26.962
cmqcwxqr200i8ibng9hggru7r	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #439: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-16 10:44:26.962
cmqcwxqr200i9ibng5hkcf3nh	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #440: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":73}	\N	not_queued	\N	\N	2026-05-16 10:49:26.962
cmqcwxqr200iaibngc0yz4i4d	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #441: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-16 10:54:26.962
cmqcwxqr200ibibngt96bfqhs	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #442: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":77}	\N	not_queued	\N	\N	2026-05-16 10:59:26.962
cmqcwxqr200icibnglule1bhk	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #443: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-16 11:04:26.962
cmqcwxqr200idibngt85bwldq	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #444: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":101}	\N	not_queued	\N	\N	2026-05-16 11:09:26.962
cmqcwxqr200ieibng7rlixktm	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #445: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-16 11:14:26.962
cmqcwxqr200ifibngcsztc17m	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #446: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":49}	\N	not_queued	\N	\N	2026-05-16 11:19:26.962
cmqcwxqr200igibng6kve8aru	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #447: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-16 11:24:26.962
cmqcwxqr200ihibngwr3y5fa1	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #448: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":75}	\N	not_queued	\N	\N	2026-05-16 11:29:26.962
cmqcwxqr200iiibng8nsirq4s	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #449: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-16 11:34:26.962
cmqcwxqr200ijibngirvzplpk	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #450: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":87}	\N	not_queued	\N	\N	2026-05-16 11:39:26.962
cmqcwxqr200ikibngeiy9vuvy	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #451: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-16 11:44:26.962
cmqcwxqr200ilibngxon4515g	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #452: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":107}	\N	not_queued	\N	\N	2026-05-16 11:49:26.962
cmqcwxqr200imibngvocp92un	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #453: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-16 11:54:26.962
cmqcwxqr200inibngoslmyiss	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #454: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":85}	\N	not_queued	\N	\N	2026-05-16 11:59:26.962
cmqcwxqr200ioibngij201fdm	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #455: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-16 12:04:26.962
cmqcwxqr200ipibng6twybfzr	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #456: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":87}	\N	not_queued	\N	\N	2026-05-16 12:09:26.962
cmqcwxqr200iqibngus1fi0l9	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #457: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-16 12:14:26.962
cmqcwxqr200iribngbcsi6znl	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #458: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":112}	\N	not_queued	\N	\N	2026-05-16 12:19:26.962
cmqcwxqr200isibng7vs1yy4h	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #459: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-16 12:24:26.962
cmqcwxqr200itibnghbvw1pq7	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #460: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":24}	\N	not_queued	\N	\N	2026-05-16 12:29:26.962
cmqcwxqr200iuibngaaa2e05m	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #461: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-16 12:34:26.962
cmqcwxqr200ivibngkw2np6kq	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #462: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":84}	\N	not_queued	\N	\N	2026-05-16 12:39:26.962
cmqcwxqr200iwibngnpzuagp6	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #463: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-16 12:44:26.962
cmqcwxqr200ixibng5cc3lev9	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #464: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":46}	\N	not_queued	\N	\N	2026-05-16 12:49:26.962
cmqcwxqr200iyibngvqd7kol0	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #465: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-16 12:54:26.962
cmqcwxqr200izibng0hubkfyp	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #466: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":50}	\N	not_queued	\N	\N	2026-05-16 12:59:26.962
cmqcwxqr200j0ibngu7y56nbx	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #467: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-16 13:04:26.962
cmqcwxqr200j1ibng4vn1xdfi	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #468: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":119}	\N	not_queued	\N	\N	2026-05-16 13:09:26.962
cmqcwxqr200j2ibnglph0rngm	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #469: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-16 13:14:26.962
cmqcwxqr200j3ibng9y7ur09f	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #470: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":76}	\N	not_queued	\N	\N	2026-05-16 13:19:26.962
cmqcwxqr200j4ibngz55ggcpz	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #471: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-16 13:24:26.962
cmqcwxqr200j5ibngx2n32gqf	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #472: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":35}	\N	not_queued	\N	\N	2026-05-16 13:29:26.962
cmqcwxqr200j6ibnge562hiyq	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #473: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-16 13:34:26.962
cmqcwxqr200j7ibngly3eirfl	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #474: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":102}	\N	not_queued	\N	\N	2026-05-16 13:39:26.962
cmqcwxqr200j8ibng8y1vo5dy	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #475: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-16 13:44:26.962
cmqcwxqr200j9ibngsd0gojig	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #476: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":63}	\N	not_queued	\N	\N	2026-05-16 13:49:26.962
cmqcwxqr200jaibngz9mit4ld	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #477: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-16 13:54:26.962
cmqcwxqr200jbibng86xfuqla	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #478: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":24}	\N	not_queued	\N	\N	2026-05-16 13:59:26.962
cmqcwxqr200jcibngvfthl6fy	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #479: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-16 14:04:26.962
cmqcwxqr200jdibngrwgv72ai	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #480: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":92}	\N	not_queued	\N	\N	2026-05-16 14:09:26.962
cmqcwxqr200jeibngvhnkcza7	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #481: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-16 14:14:26.962
cmqcwxqr200jfibng2ecz46uh	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #482: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":27}	\N	not_queued	\N	\N	2026-05-16 14:19:26.962
cmqcwxqr200jgibng1hepxk2z	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #483: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-16 14:24:26.962
cmqcwxqr200jhibngfd0x2f7z	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #484: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":107}	\N	not_queued	\N	\N	2026-05-16 14:29:26.962
cmqcwxqr200jiibng0y7te5ot	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #485: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-16 14:34:26.962
cmqcwxqr200jjibngoeiwfim5	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #486: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":70}	\N	not_queued	\N	\N	2026-05-16 14:39:26.962
cmqcwxqr200jkibngb9h4ex5t	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #487: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-16 14:44:26.962
cmqcwxqr200jlibng9mp5ovnj	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #488: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":38}	\N	not_queued	\N	\N	2026-05-16 14:49:26.962
cmqcwxqr200jmibngozuddix2	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #489: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-16 14:54:26.962
cmqcwxqr200jnibngz1y5oluq	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #490: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":74}	\N	not_queued	\N	\N	2026-05-16 14:59:26.962
cmqcwxqr200joibngp3x62w13	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #491: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-16 15:04:26.962
cmqcwxqr200jpibnggk10j0o9	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #492: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":32}	\N	not_queued	\N	\N	2026-05-16 15:09:26.962
cmqcwxqr200jqibngx7sqhxcg	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #493: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-16 15:14:26.962
cmqcwxqr200jribngf7egg4y6	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #494: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":34}	\N	not_queued	\N	\N	2026-05-16 15:19:26.962
cmqcwxqr200jsibng2d43n331	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #495: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-16 15:24:26.962
cmqcwxqr200jtibngibbulzjf	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #496: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":104}	\N	not_queued	\N	\N	2026-05-16 15:29:26.962
cmqcwxqr200juibngvus7uogi	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #497: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-16 15:34:26.962
cmqcwxqr200jvibnga2y5mjfd	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #498: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":71}	\N	not_queued	\N	\N	2026-05-16 15:39:26.962
cmqcwxqr200jwibnghc78gesk	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	user	Customer message #499: Can I ask a question about your products?	\N	\N	\N	\N	\N	\N	not_queued	\N	\N	2026-05-16 15:44:26.962
cmqcwxqr200jxibngy2ui4lm8	bellitalia-vip-ecommerce	2766c7a0-c110-4405-a1bb-3904e3b822bb	feae6cdb-6015-4655-b8f0-296272e12b82	assistant	Assistant response #500: Of course! Feel free to ask me anything. I'm here to help you with product information, shipping details, and more.	\N	\N	\N	\N	{"agentSelected":"GENERAL_INQUIRY","tokensUsed":92}	\N	not_queued	\N	\N	2026-05-16 15:49:26.962
cmqfh568x000021ng0bhn9jiy	cmqcx3fcx0000cgng9dml0qbh	e95ce5db-dfa2-41c4-b6bb-7e344cb36825	12f7f507-c2c9-4781-9b12-5f969fd37125	user	Ciao chi sei?	ROUTER	\N	\N	0	\N	\N	not_queued	\N	\N	2026-06-15 17:15:38.337
cmqfh5gf4000121ngr94yzgim	cmqcx3fcx0000cgng9dml0qbh	e95ce5db-dfa2-41c4-b6bb-7e344cb36825	12f7f507-c2c9-4781-9b12-5f969fd37125	user	Chi sei?	ROUTER	\N	\N	0	\N	\N	not_queued	\N	\N	2026-06-15 17:15:51.52
\.


--
-- Data for Name: credit_notes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.credit_notes (id, "creditNoteCode", "orderId", amount, reason, "createdAt", "createdById") FROM stdin;
\.


--
-- Data for Name: customer_feedback; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.customer_feedback (id, "workspaceId", "customerId", rating, comment, "stayKey", "arrivalDate", "departureDate", "createdAt") FROM stdin;
\.


--
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.customers (id, name, email, phone, "customId", address, company, discount, language, currency, notes, tags, "serviceIds", "isBlacklisted", "createdAt", "updatedAt", "deletedAt", "isActive", "registrationStatus", "workspaceId", last_privacy_version_accepted, privacy_accepted_at, push_notifications_consent, push_notifications_consent_at, "activeChatbot", "operatorRequestedAt", "originChannel", "operatorQueuePosition", "operatorQueueEnteredAt", "invoiceAddress", "salesId", "maxActiveAppointments", "lastAppointmentDate", "stayProfile", "feedbackRating", "feedbackComment", "feedbackAt") FROM stdin;
e703f9c3-ae4e-4c0d-afd2-48dda4b5ea8e	Luca Informazioni	luca.info@bellitalia.com	+39 06 1234 5671	\N	Via Torino 18, Milano	Trattoria Milano	0	IT	EUR	\N	{}	{}	f	2026-05-29 22:14:26.293	2026-05-29 22:14:26.293	\N	t	NEW	bellitalia-info-workspace	\N	\N	t	2026-06-13 22:14:26.293	t	\N	\N	\N	\N	\N	\N	5	\N	\N	\N	\N	\N
753bf3a5-ff99-4830-8c0c-afa7be62d743	Emily Johnson	emily.johnson@foodbuyers.uk	+44 20 1234 8899	\N	221B Baker Street, London	London Catering Co.	0	ENG	EUR	\N	{}	{}	f	2026-06-01 22:14:26.293	2026-06-01 22:14:26.293	\N	t	NEW	bellitalia-info-workspace	\N	\N	t	2026-06-13 22:14:26.296	t	\N	\N	\N	\N	\N	\N	5	\N	\N	\N	\N	\N
4a4695a1-b63c-47a0-9e84-323becdc8a7a	Carlos López	carlos.logistica@sevilla.es	+34 622 89 45 11	\N	Calle Feria 45, Sevilla	Tapas Sur	0	ESP	EUR	\N	{}	{}	f	2026-06-04 22:14:26.293	2026-06-04 22:14:26.293	\N	t	NEW	bellitalia-info-workspace	\N	\N	t	2026-06-13 22:14:26.299	t	\N	\N	\N	\N	\N	\N	5	\N	\N	\N	\N	\N
6bb71ec1-cd3c-47bc-9cb1-c285c641a119	Ana Silva	ana.silva@porto-rest.pt	+351 965 778 201	\N	Rua das Flores 12, Porto	Porto Delights	0	PRT	EUR	\N	{}	{}	f	2026-06-06 22:14:26.293	2026-06-06 22:14:26.293	\N	t	NEW	bellitalia-info-workspace	\N	\N	t	2026-06-13 22:14:26.301	t	\N	\N	\N	\N	\N	\N	5	\N	\N	\N	\N	\N
fc24368e-377a-46ff-b6bc-aab2c9a3871a	Sara Product Demo	sara.demo@echatbot.ai	+39 380 1112223	\N	\N	Innovative Retail Group	0	ENG	EUR	\N	{}	{}	f	2026-06-13 16:14:26.58	2026-06-13 16:14:26.58	\N	t	NEW	echatbot-hq-support	\N	\N	t	2026-06-13 22:14:26.58	t	\N	\N	\N	\N	\N	\N	5	\N	\N	\N	\N	\N
768079dc-ade2-47c9-ae94-fa839d96b5dc	Mario Rossi	mario.rossi@test.com	+390212345678	\N	{"name":"Mario Rossi","street":"Via Roma 123","city":"Milano","postalCode":"20100","country":"Italia"}	Rossi Limited S.r.l.	10	IT	EUR	\N	{}	{}	f	2025-04-04 22:00:00	2025-04-04 22:00:00	\N	t	NEW	bellitalia-vip-ecommerce	v1.0	\N	t	2026-06-13 22:14:26.935	t	\N	\N	\N	\N	\N	be9f5a8f-8469-46b0-863c-76c5bd6a3036	5	\N	\N	\N	\N	\N
e47d0970-59a7-4c6e-bf3d-abae59964db0	João Silva	joao.silva@test.com	+351123456789	\N	{"name":"João Silva","street":"Rua Augusta 456","city":"Lisboa","postalCode":"1100-053","country":"Portugal"}	Silva & Filhos Lda	10	PRT	EUR	\N	{}	{}	f	2025-05-11 22:00:00	2025-05-11 22:00:00	\N	t	NEW	bellitalia-vip-ecommerce	v1.0	\N	t	2026-06-13 22:14:26.937	t	\N	\N	\N	\N	\N	54426f86-3e59-42d3-908f-5d0d2dc8d42c	5	\N	\N	\N	\N	\N
6fc43406-b2ef-48ba-a1dd-3171316d3cf3	Maria Garcia	maria.garcia@test.com	+34666777888	\N	{"name":"Maria Garcia","street":"Calle Mayor 789","city":"Madrid","postalCode":"28013","country":"España"}	Garcia Imports S.L.	10	ESP	EUR	\N	{}	{}	t	2025-06-07 22:00:00	2025-06-07 22:00:00	\N	t	NEW	bellitalia-vip-ecommerce	\N	\N	f	\N	t	\N	\N	\N	\N	\N	27c2a0d8-563a-4878-9657-eeb7f50a9b85	5	\N	\N	\N	\N	\N
2766c7a0-c110-4405-a1bb-3904e3b822bb	John Smith	john.smith@test.com	+44123456789	\N	{"name":"John Smith","street":"Baker Street 221B","city":"London","postalCode":"NW1 6XE","country":"United Kingdom"}	Smith & Co Ltd	10	ENG	EUR	\N	{}	{}	t	2025-07-14 22:00:00	2025-07-14 22:00:00	\N	t	NEW	bellitalia-vip-ecommerce	\N	\N	f	\N	t	\N	\N	\N	\N	\N	a749bee2-de90-415c-aa14-51c7138db11c	5	\N	\N	\N	\N	\N
1b70a5b5-7d8f-4b7f-a25f-13406c6d2b4c	Test Customer (Playground)	playground@test.echatbot.local	+39 999 1234567	\N	{"name":"Test Customer","street":"Via Test 999","city":"Test City","postalCode":"99999","country":"Italia"}	Playground Test Company	0	IT	EUR	\N	{}	{}	f	2026-06-13 22:14:26.941	2026-06-13 22:14:26.941	\N	t	NEW	bellitalia-vip-ecommerce	\N	\N	f	\N	t	\N	\N	\N	\N	\N	be9f5a8f-8469-46b0-863c-76c5bd6a3036	5	\N	\N	\N	\N	\N
e95ce5db-dfa2-41c4-b6bb-7e344cb36825	Visitor 138c222d	visitor_1781543737551_138c222d@visitor.local	\N	visitor_1781543737551_138c222d	\N	\N	0	it	EUR	\N	{}	{}	f	2026-06-15 17:15:37.666	2026-06-15 17:15:37.666	\N	f	NEW	cmqcx3fcx0000cgng9dml0qbh	\N	\N	f	\N	t	\N	\N	\N	\N	\N	\N	5	\N	\N	\N	\N	\N
\.


--
-- Data for Name: demorobot_assets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.demorobot_assets (id, "flowCategoryId", type, url, title, summary, language, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: demorobot_flow_edges; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.demorobot_flow_edges (id, "sourceNodeId", "targetNodeId", label, "triggersEscalation", "createdAt", "targetFlowId") FROM stdin;
\.


--
-- Data for Name: demorobot_flow_node_attachments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.demorobot_flow_node_attachments ("nodeId", "assetId", "createdAt") FROM stdin;
\.


--
-- Data for Name: demorobot_flow_nodes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.demorobot_flow_nodes (id, "flowId", question, "positionX", "positionY", "fieldKey", "fieldType", "terminalType", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: demorobot_flows; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.demorobot_flows (id, "workspaceId", "flowCategoryId", title, description, keywords, "retrievalDocument", embedding, "compiledPrompt", hash, "createdAt", "updatedAt", "isProtected", "isActive") FROM stdin;
\.


--
-- Data for Name: faqs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.faqs (id, "workspaceId", question, answer, keywords, category, "order", "isActive", "createdAt", "updatedAt") FROM stdin;
cmqcwxqaa0008ibngf8jutc0i	bellitalia-info-workspace	Quali tipologie di prodotti offre BellItalia?	Abbiamo a disposizione una vasta gamma di prodotti alimentari italiani e mediterranei — da articoli artigianali realizzati da produttori esclusivi fino a marchi ben noti — ideali per ristoranti, pizzerie, distributori e grande distribuzione.	\N	Products	0	t	2026-06-13 22:14:26.386	2026-06-13 22:14:26.386
cmqcwxqac0009ibngsbb56mx1	bellitalia-info-workspace	Chi può acquistare da BellItalia (ristoranti / negozi / privati)?	Il nostro catalogo è progettato principalmente per clienti professionali — pizzerie, ristoranti, distributori e GDO (grande distribuzione).	\N	Customers	0	t	2026-06-13 22:14:26.388	2026-06-13 22:14:26.388
cmqcwxqae000aibngy3zdc6sv	bellitalia-info-workspace	Quanti prodotti avete nel vostro catalogo?	Offriamo più di 600 riferimenti nel nostro catalogo di prodotti autentici italiani.	\N	Products	0	t	2026-06-13 22:14:26.39	2026-06-13 22:14:26.39
cmqcwxqaf000bibngeddafeuw	bellitalia-info-workspace	What kinds of products does BellItalia offer?	We provide a wide variety of Italian and Mediterranean food products — from artisanal items made by exclusive producers to well-known brand names — ideal for restaurants, pizzerias, distributors and large distribution.	\N	Products	0	t	2026-06-13 22:14:26.391	2026-06-13 22:14:26.391
cmqcwxqah000cibnggjhq6nk6	bellitalia-info-workspace	Who can buy from BellItalia (restaurants / shops / individuals)?	Our catalogue is designed mainly for professional clients — pizzerias, restaurants, distributors and GDO (large retailers).	\N	Customers	0	t	2026-06-13 22:14:26.393	2026-06-13 22:14:26.393
cmqcwxqai000dibngp7s4dinj	bellitalia-info-workspace	How many products do you have in your catalogue?	We offer more than 600 references in our catalogue of authentic Italian products.	\N	Products	0	t	2026-06-13 22:14:26.394	2026-06-13 22:14:26.394
cmqcwxqak000eibnglr4x8dsc	bellitalia-info-workspace	Do you supply fresh products (like fresh cheese or tomatoes)?	Yes — among our offerings there are fresh Italian cheeses and tomatoes, as part of our authentic Italian ingredients.	\N	Products	0	t	2026-06-13 22:14:26.396	2026-06-13 22:14:26.396
cmqcwxqal000fibng4d34t9zl	bellitalia-info-workspace	Do you offer pasta products?	Yes — for example, we distribute traditional Italian pasta such as tagliatelle.	\N	Products	0	t	2026-06-13 22:14:26.397	2026-06-13 22:14:26.397
cmqcwxqam000gibngok1flh89	bellitalia-info-workspace	Do you supply to pizzerias and help them with Italian pizza ingredients?	Absolutely — we offer specialized selections for pizzerias, helping them with high-quality Italian ingredients to craft their pizzas.	\N	Customers	0	t	2026-06-13 22:14:26.398	2026-06-13 22:14:26.398
cmqcwxqao000hibngtag5s311	bellitalia-info-workspace	Do you deliver all over Spain or only locally?	We provide logistic solutions across the Iberian Peninsula, serving both local businesses and large distribution clients.	\N	Delivery	0	t	2026-06-13 22:14:26.4	2026-06-13 22:14:26.4
cmqcwxqaq000iibngml6gv34m	bellitalia-info-workspace	How can I contact you to place an order or ask for information?	You can contact us via phone at +34 93 15 91 221, via WhatsApp at +34 602 25 17 06, or by email at info@bellitalia.com.	\N	Contact	0	t	2026-06-13 22:14:26.402	2026-06-13 22:14:26.402
cmqcwxqar000jibnggg6hykc3	bellitalia-info-workspace	Can I request your catalog in PDF?	Yes — our catalogue is downloadable as a PDF with all our product references.	\N	Products	0	t	2026-06-13 22:14:26.403	2026-06-13 22:14:26.403
cmqcwxqat000kibng7n0lc8ee	bellitalia-info-workspace	Is your service suitable for big distribution companies / retailers?	Yes — we have a business area dedicated to 'GDO' (large distribution), offering tailored logistic and supply solutions for large retailers.	\N	Customers	0	t	2026-06-13 22:14:26.405	2026-06-13 22:14:26.405
cmqcwxqav000libnghf8xg1c0	bellitalia-info-workspace	If I own a restaurant, can you support my supply needs?	Definitely — we work with restaurants to supply high-quality Italian products, with a reliable and professional service.	\N	Customers	0	t	2026-06-13 22:14:26.407	2026-06-13 22:14:26.407
cmqcwxqax000mibngtzda8zyl	bellitalia-info-workspace	Are your products only Italian or also Mediterranean more broadly?	We offer primarily Italian products but also Mediterranean-style foods and beverages, aimed at clients who value quality and tradition.	\N	Products	0	t	2026-06-13 22:14:26.409	2026-06-13 22:14:26.409
cmqcwxqay000nibngrblv00gw	bellitalia-info-workspace	What makes BellItalia unique compared to other distributors?	Our strengths are the variety of unique products (from artisanal to branded), fast and reliable delivery, and specialized professional service.	\N	Company	0	t	2026-06-13 22:14:26.41	2026-06-13 22:14:26.41
cmqcwxqb0000oibng52f18i5a	bellitalia-info-workspace	Can I become a distributor with BellItalia if I have a wholesale business?	Yes — there is a section for distributors: we offer a reliable product range, logistic support and collaboration adapted to distributors' needs.	\N	Customers	0	t	2026-06-13 22:14:26.412	2026-06-13 22:14:26.412
cmqcwxqb2000pibngmpzdq47f	bellitalia-info-workspace	Do you ship to grocery stores or supermarkets?	Yes — through our 'GDO' line, we supply to large distribution channels, ensuring products suitable for retail shelves.	\N	Customers	0	t	2026-06-13 22:14:26.414	2026-06-13 22:14:26.414
cmqcwxqb3000qibngbw1mijdh	bellitalia-info-workspace	How quickly can you deliver orders?	We emphasize fast and reliable shipping as one of our main qualities.	\N	Delivery	0	t	2026-06-13 22:14:26.415	2026-06-13 22:14:26.415
cmqcwxqb5000ribngpfpag5b8	bellitalia-info-workspace	Are there any minimum order quantities / requirements?	For details like minimum orders or logistic conditions, we recommend contacting us directly — you can reach us by phone, WhatsApp or email.	\N	Orders	0	t	2026-06-13 22:14:26.417	2026-06-13 22:14:26.417
cmqcwxqb7000sibngtc1tua30	bellitalia-info-workspace	Do you only supply food, or also beverages and wines?	We supply food products, beverages, and Mediterranean/Italian wines.	\N	Products	0	t	2026-06-13 22:14:26.419	2026-06-13 22:14:26.419
cmqcwxqb8000tibnggvxf7i7c	bellitalia-info-workspace	I'm a small restaurant — can I still place an order?	Yes — BellItalia works with restaurants of different sizes and tailors service to their specific needs.	\N	Customers	0	t	2026-06-13 22:14:26.42	2026-06-13 22:14:26.42
cmqcwxqba000uibng1wws5z5k	bellitalia-info-workspace	How long does it take to get a response when I contact you?	Once you send a message via our contact form, we commit to responding within 24 hours.	\N	Contact	0	t	2026-06-13 22:14:26.422	2026-06-13 22:14:26.422
cmqcwxqbb000vibngqra4w8on	bellitalia-info-workspace	Do you offer refrigerated transport for dairy products?	Yes, we maintain the cold chain between 2–4 °C using certified refrigerated carriers so cheeses and fresh products arrive safely.	\N	Transport	0	t	2026-06-13 22:14:26.423	2026-06-13 22:14:26.423
cmqcwxqbd000wibngju98bgg7	bellitalia-info-workspace	How do you ship frozen goods to ensure -18 °C stability?	Frozen SKUs travel in -18 °C trucks with temperature probes and seals; if the seal is broken the shipment is replaced.	\N	Transport	0	t	2026-06-13 22:14:26.425	2026-06-13 22:14:26.425
cmqcwxqbe000xibngylbcirxu	bellitalia-info-workspace	Can ambient and refrigerated goods travel in the same delivery?	We consolidate ambient items on one pallet and refrigerate the rest, dispatching both pallets on the same route so you receive everything together.	\N	Transport	0	t	2026-06-13 22:14:26.426	2026-06-13 22:14:26.426
cmqcwxqbg000yibng4rbwn6n3	bellitalia-info-workspace	What is the average transit time from Barcelona to Northern Italy?	Transit to Milan/Turin averages 48–72 hours with two departures per week; Central Spain deliveries remain within 24–48 hours.	\N	Transport	0	t	2026-06-13 22:14:26.428	2026-06-13 22:14:26.428
cmqcwxqbi000zibnge20tgmmv	bellitalia-info-workspace	Do you provide ADR-certified carriers for wine or spirits pallets?	Yes, for alcohol shipments we work with ADR partners able to move wine or spirits under the correct documentation.	\N	Transport	0	t	2026-06-13 22:14:26.43	2026-06-13 22:14:26.43
cmqcwxqbj0010ibngnlvgr3jj	bellitalia-info-workspace	Can you arrange tail-lift trucks for pallet deliveries?	When clients lack a dock we can send trucks equipped with tail-lift to unload pallets safely at street level.	\N	Transport	0	t	2026-06-13 22:14:26.431	2026-06-13 22:14:26.431
cmqcwxqbl0011ibngiehwggsw	bellitalia-info-workspace	Is it possible to request temperature data loggers with each shipment?	We can include a data logger and share the temperature report along with the POD for full traceability.	\N	Transport	0	t	2026-06-13 22:14:26.433	2026-06-13 22:14:26.433
cmqcwxqbn0012ibngp48w99c4	bellitalia-info-workspace	Do you deliver on Saturdays for urgent restocks?	Saturday morning deliveries are available in the main metropolitan areas with a small surcharge to cover weekend shifts.	\N	Transport	0	t	2026-06-13 22:14:26.435	2026-06-13 22:14:26.435
cmqcwxqbo0013ibng0xui88qy	bellitalia-info-workspace	How do you handle customs paperwork for Canary Islands or non-EU destinations?	Our logistics team prepares phytosanitary certificates and customs declarations for Canary Islands, Andorra or extra-EU routes.	\N	Transport	0	t	2026-06-13 22:14:26.436	2026-06-13 22:14:26.436
cmqcwxqbq0014ibngde1thxuv	bellitalia-info-workspace	Can you drop-ship directly to my restaurant customers?	Yes, we can ship directly to your final customer with neutral packing slips while you receive the invoice and tracking.	\N	Transport	0	t	2026-06-13 22:14:26.438	2026-06-13 22:14:26.438
cmqcwxqbs0015ibngbzfzxb93	bellitalia-info-workspace	Do you consolidate multiple orders to reduce transport cost?	Whenever purchase orders share the same route we consolidate them onto the same pallet to optimize freight cost per unit.	\N	Transport	0	t	2026-06-13 22:14:26.44	2026-06-13 22:14:26.44
cmqcwxqbt0016ibngiofkhieb	bellitalia-info-workspace	Is tracking available for the transport service?	Every shipment includes real-time tracking — parcel links for small boxes and GPS checkpoints for palletized loads.	\N	Transport	0	t	2026-06-13 22:14:26.441	2026-06-13 22:14:26.441
cmqcwxqbv0017ibngh8pjmno3	bellitalia-info-workspace	How far in advance should refrigerated transport be booked during holidays?	During peak weeks (Christmas/Easter) we recommend booking cold-chain space 4–5 days ahead to guarantee capacity.	\N	Transport	0	t	2026-06-13 22:14:26.443	2026-06-13 22:14:26.443
cmqcwxqbw0018ibng8qxi0nvd	bellitalia-info-workspace	Can you handle deliveries with restricted time windows?	We frequently deliver to malls, airports and cruise terminals with strict slots — just share the window when placing the order.	\N	Transport	0	t	2026-06-13 22:14:26.444	2026-06-13 22:14:26.444
cmqcwxqbz0019ibngqqezpf7g	bellitalia-info-workspace	Do you provide digital proof of delivery or signed CMR?	Yes, the driver uploads the signed POD/CMR immediately and we forward the PDF to your logistics contact.	\N	Transport	0	t	2026-06-13 22:14:26.447	2026-06-13 22:14:26.447
cmqcwxqc0001aibng86v1ny7z	bellitalia-info-workspace	Are there surcharges for Balearic Islands or remote areas?	Balearic Islands and remote mountain towns have a transparent surcharge which we quote before confirming the shipment.	\N	Transport	0	t	2026-06-13 22:14:26.448	2026-06-13 22:14:26.448
cmqcwxqc3001bibngx4fkz2nf	bellitalia-info-workspace	Can I use my own carrier while you prepare the pallets?	Of course — we can palletize, label and load your appointed carrier once a pickup slot is agreed.	\N	Transport	0	t	2026-06-13 22:14:26.451	2026-06-13 22:14:26.451
cmqcwxqc4001cibngvwxwo3xo	bellitalia-info-workspace	Do you insure shipments against temperature excursions?	All refrigerated and frozen shipments are insured; if a temperature excursion occurs we trigger a replacement immediately.	\N	Transport	0	t	2026-06-13 22:14:26.452	2026-06-13 22:14:26.452
cmqcwxqc7001dibngfo5qszu7	bellitalia-info-workspace	What is the maximum weight per pallet you can ship?	Standard pallets can reach roughly 900 kg; above that threshold we split the goods into multiple pallets for safety.	\N	Transport	0	t	2026-06-13 22:14:26.455	2026-06-13 22:14:26.455
cmqcwxqc8001eibngxflj1bet	bellitalia-info-workspace	Do you offer dual-compartment trucks for mixed frozen and ambient goods?	Yes, we collaborate with carriers operating dual-compartment vehicles so frozen and ambient products travel together without risk.	\N	Transport	0	t	2026-06-13 22:14:26.456	2026-06-13 22:14:26.456
cmqcwxqca001fibngo91svgnb	bellitalia-info-workspace	Posso integrare il vostro servizio con il mio CRM?	Sì, certo! È una customizzazione disponibile con la versione Enterprise. Mandaci una email con tutte le specifiche del vostro CRM (API disponibili, formati dati, autenticazione, etc.) a support@echatbot.ai e provvediamo a farti un preventivo dettagliato.	\N	Integrazioni	0	t	2026-06-13 22:14:26.458	2026-06-13 22:14:26.458
cmqcwxqcb001gibngpe2z34w0	bellitalia-info-workspace	Posso lanciare un webhook quando viene effettuato un ordine?	Sì, certo! È una customizzazione disponibile con la versione Enterprise. Mandaci una email con l'URL webhook di destinazione, il formato/struttura dati attesi, timing (immediate o batch?), e autenticazione required (API key, OAuth, etc.). Implementiamo un flusso: Ordine completato → Scheduler → Security Check → POST webhook al tuo servizio → Log e retry su failure.	\N	Integrazioni	0	t	2026-06-13 22:14:26.459	2026-06-13 22:14:26.459
cmqcwxqcd001hibngi2m5uu8i	bellitalia-info-workspace	Posso leggere la disponibilità dinamicamente dai miei server facendo una chiamata esterna?	Sì, certo! È una customizzazione disponibile con la versione Enterprise. Mandaci una email con l'URL API del vostro servizio di disponibilità, parametri da inviare (SKU, quantità, warehouse, etc.), formato risposta atteso, e timeout/retry policy. Implementiamo: Cliente chiede → ChatBot chiama API esterna → Risposta dinamica integrata nel flusso.	\N	Integrazioni	0	t	2026-06-13 22:14:26.461	2026-06-13 22:14:26.461
cmqcwxqce001iibng90pswmy4	bellitalia-info-workspace	Ho una squadra di agenti. Posso inoltrare la richiesta all'agente associato?	Sì, certo! Ecco come funziona: 1) Vai in Backoffice → Settings → Team Members, 2) Aggiungi agenti con nome, email, skills (Sales, Support, Technical), 3) Configura routing nel Agent Config con regole di assegnazione (round-robin, skill-based, etc.), 4) Quando il cliente scrive, il ChatBot analizza la richiesta, assegna l'agente disponibile, e notifica l'agente per la risposta. Se l'agente è offline, il sistema passa al prossimo in lista.	\N	Team	0	t	2026-06-13 22:14:26.462	2026-06-13 22:14:26.462
cmqcwxqcg001jibngqp0fa7cv	bellitalia-info-workspace	Come ricevono le notifiche gli agenti quando viene assegnata una richiesta?	Gli agenti ricevono notifiche email con il nome del cliente e il contesto della conversazione. Possono rispondere direttamente dalla dashboard. Se attivi la versione Enterprise, le notifiche possono arrivare anche via WhatsApp. Il sistema traccia tutti gli handover per analytics e feedback di soddisfazione cliente.	\N	Team	0	t	2026-06-13 22:14:26.464	2026-06-13 22:14:26.464
cmqcwxqch001kibngpkoh8zuq	bellitalia-info-workspace	Ho aggiunto delle FAQs. Puoi metterle nel flusso del chatbot?	Le FAQs sono già integrate nel flusso! Ecco come funzionano: 1) Aggiungi FAQ in Backoffice → Content → FAQs (Titolo, Risposta, Categorie, Keywords), 2) Quando il cliente chiede qualcosa, il sistema calcola un similarity score (0-100%), 3) Se score > 70% → usa la risposta FAQ istantaneamente (senza LLM latency), 4) Se score < 70% → usa risposta LLM standard. Tutto viene tracciato in analytics.	\N	FAQ	0	t	2026-06-13 22:14:26.465	2026-06-13 22:14:26.465
cmqcwxqcj001libngvkto0z4t	bellitalia-info-workspace	Quali sono i vantaggi di usare le FAQs nel chatbot?	I vantaggi delle FAQs sono: ✅ Risposte instant (no LLM latency), ✅ Consistenza (stesse risposte sempre), ✅ Risparmio token (meno costo LLM), ✅ Analytics complete (quante volte usata, click rate, fallback rate). Puoi vedere nel dashboard quali FAQ sono più usate e quali hanno il highest satisfaction rate.	\N	FAQ	0	t	2026-06-13 22:14:26.467	2026-06-13 22:14:26.467
cmqcwxqck001mibnghfg6qlyj	bellitalia-info-workspace	Can I integrate your service with my CRM?	Yes, of course! It's a customization available with the Enterprise version. Send us an email with all your CRM specifications (available APIs, data formats, authentication, etc.) to support@echatbot.ai and we'll provide you with a detailed quote.	\N	Integrations	0	t	2026-06-13 22:14:26.468	2026-06-13 22:14:26.468
cmqcwxqcl001nibngbpbk4012	bellitalia-info-workspace	Can I launch a webhook when an order is placed?	Yes, of course! It's a customization available with the Enterprise version. Send us an email with: webhook destination URL, expected data format/structure, timing (immediate or batch?), and required authentication (API key, OAuth, etc.). We implement: Order completed → Scheduler → Security Check → POST webhook to your service → Log and retry on failure.	\N	Integrations	0	t	2026-06-13 22:14:26.469	2026-06-13 22:14:26.469
cmqcwxqcn001oibngnifjwawq	bellitalia-info-workspace	Can I read availability dynamically from my servers by making an external API call?	Yes, of course! It's a customization available with the Enterprise version. Send us an email with: your availability service API URL, parameters to send (SKU, quantity, warehouse, etc.), expected response format, and timeout/retry policy. We implement: Customer asks → ChatBot calls external API → Dynamic response integrated in the flow.	\N	Integrations	0	t	2026-06-13 22:14:26.471	2026-06-13 22:14:26.471
cmqcwxqco001pibngaimgjxwm	bellitalia-info-workspace	I have a team of agents. Can I forward requests to the associated agent?	Yes, of course! Here's how it works: 1) Go to Backoffice → Settings → Team Members, 2) Add agents with name, email, skills (Sales, Support, Technical), 3) Configure routing in Agent Config with assignment rules (round-robin, skill-based, etc.), 4) When the customer writes, the ChatBot analyzes the request, assigns the available agent, and notifies the agent for response. If the agent is offline, the system moves to the next in the list.	\N	Team	0	t	2026-06-13 22:14:26.472	2026-06-13 22:14:26.472
cmqcwxqcp001qibngcy1unqxg	bellitalia-info-workspace	How do agents receive notifications when a request is assigned to them?	Agents receive email notifications with the customer name and conversation context. They can reply directly from the dashboard. If you activate the Enterprise version, notifications can also arrive via WhatsApp. The system tracks all handovers for analytics and customer satisfaction feedback.	\N	Team	0	t	2026-06-13 22:14:26.473	2026-06-13 22:14:26.473
cmqcwxqcr001ribngx1c7ggun	bellitalia-info-workspace	I've added some FAQs. Can you put them in the chatbot flow?	FAQs are already integrated into the flow! Here's how it works: 1) Add FAQ in Backoffice → Content → FAQs (Title, Answer, Categories, Keywords), 2) When a customer asks something, the system calculates a similarity score (0-100%), 3) If score > 70% → use the FAQ answer instantly (without LLM latency), 4) If score < 70% → use standard LLM response. Everything is tracked in analytics.	\N	FAQ	0	t	2026-06-13 22:14:26.475	2026-06-13 22:14:26.475
cmqcwxqcs001sibng4xiom7mo	bellitalia-info-workspace	What are the benefits of using FAQs in the chatbot?	The benefits of FAQs are: ✅ Instant answers (no LLM latency), ✅ Consistency (same answers always), ✅ Token savings (lower LLM cost), ✅ Complete analytics (times used, click rate, fallback rate). You can see in the dashboard which FAQs are most used and which have the highest satisfaction rate.	\N	FAQ	0	t	2026-06-13 22:14:26.476	2026-06-13 22:14:26.476
cmqcwxqdw001tibnge15ish6b	echatbot-hq-support	What plans does eChatbot offer and how is pricing calculated?	We offer Starter, Premium and Enterprise plans. Pricing is usage-based: a monthly platform fee plus credits for WhatsApp conversations, automations and AI tasks. Enterprise includes custom SLAs and concierge onboarding.	\N	Pricing	0	t	2026-06-13 22:14:26.516	2026-06-13 22:14:26.516
cmqcwxqdx001uibnghtopcyol	echatbot-hq-support	Can I test eChatbot before committing to a paid plan?	Yes, every workspace starts with a fully-featured trial environment so you can validate flows, integrations and analytics. No card is required during the trial.	\N	Pricing	0	t	2026-06-13 22:14:26.517	2026-06-13 22:14:26.517
cmqcwxqdz001vibngftjhxhov	echatbot-hq-support	Which channels are supported besides WhatsApp?	WhatsApp is the primary channel, but eChatbot also integrates email, Instagram DM, web chat widgets and backoffice messaging via the same unified automation stack.	\N	Platform	0	t	2026-06-13 22:14:26.519	2026-06-13 22:14:26.519
cmqcwxqe0001wibngy416nfg8	echatbot-hq-support	Does eChatbot support multilingual conversations?	Absolutely. Each workspace can configure Italian, English, Spanish, Portuguese and more. The AI router translates messages while keeping tone, brand voice and compliance consistent.	\N	Platform	0	t	2026-06-13 22:14:26.52	2026-06-13 22:14:26.52
cmqcwxqe2001xibng2uwrjiqc	echatbot-hq-support	How do I connect eChatbot with my ERP or CRM?	We provide REST APIs, webhooks, native connectors for HubSpot/Shopify, and middleware guides for custom ERPs. Enterprise clients receive solution architect support during integration.	\N	Integrations	0	t	2026-06-13 22:14:26.522	2026-06-13 22:14:26.522
cmqcwxqe3001yibngisootsu9	echatbot-hq-support	Can I talk with a human consultant if the bot can’t solve my issue?	Yes. Every plan includes human hand-off. Just request an agent and our team opens an email/WhatsApp thread with a named consultant who replies within SLA.	\N	Support	0	t	2026-06-13 22:14:26.523	2026-06-13 22:14:26.523
cmqcwxqe4001zibngjtlzlaif	echatbot-hq-support	Where is customer data hosted and how is it protected?	Data is hosted in the EU on Heroku infrastructure, encrypted at rest and in transit. We implement multi-tenant isolation, role-based access control and audit logging fully aligned with GDPR requirements. For more details, see our <a href='https://echatbot.ai/privacy' target='_blank'>Privacy Policy</a>.	\N	Security	0	t	2026-06-13 22:14:26.524	2026-06-13 22:14:26.524
cmqcwxqe60020ibng79hz6xd9	echatbot-hq-support	What happens to my customer data when they chat with the AI?	Customer messages are processed through OpenRouter's secure API with enterprise-grade encryption. Data is NOT used to train AI models and is processed only to generate responses. All conversations are stored encrypted in our EU servers and comply with GDPR data minimization principles. Full details in our <a href='https://echatbot.ai/privacy' target='_blank'>Privacy Policy</a>.	\N	Security	0	t	2026-06-13 22:14:26.526	2026-06-13 22:14:26.526
cmqcwxqe80021ibngxdmcuw4t	echatbot-hq-support	Which payment methods do you accept for subscriptions?	We accept SEPA transfer, credit cards (Visa/Mastercard) and invoicing with 30-day terms for Enterprise customers.	\N	Billing	0	t	2026-06-13 22:14:26.528	2026-06-13 22:14:26.528
cmqcwxqe90022ibng8wg2akbm	echatbot-hq-support	Can eChatbot escalate complex workflows to my internal team?	Yes. The workflow engine can trigger Zendesk/Asana tasks, send Slack alerts or forward transcripts via email so your team continues the conversation seamlessly.	\N	Automation	0	t	2026-06-13 22:14:26.529	2026-06-13 22:14:26.529
cmqcwxqeb0023ibngxg04q6w1	echatbot-hq-support	What type of analytics can I expect in the dashboard?	You can monitor conversation volume, conversion funnels, agent performance, translation usage, CSAT trends and export raw data for BI tools.	\N	Analytics	0	t	2026-06-13 22:14:26.531	2026-06-13 22:14:26.531
cmqcwxqec0024ibngphbb90d8	echatbot-hq-support	Is eChatbot Meta BSP compliant and do you manage WhatsApp templates?	Yes, we are aligned with Meta BSP guidelines. We help you register templates, manage quality scores and automate template fallback logic.	\N	Compliance	0	t	2026-06-13 22:14:26.532	2026-06-13 22:14:26.532
cmqcwxqee0025ibngwzlyojkx	echatbot-hq-support	How long does onboarding typically take?	Starter workspaces launch in a few hours. Enterprise rollouts include a 2-week implementation sprint covering training, automations, testing and go-live checklist.	\N	Deployment	0	t	2026-06-13 22:14:26.534	2026-06-13 22:14:26.534
cmqcwxqef0026ibng6imjpufy	echatbot-hq-support	Can I use my own AI models or bring OpenAI keys?	Certainly. You can plug in your own OpenAI/Anthropic keys, set model policies per agent and even mix internal deterministic flows with LLMs.	\N	Features	0	t	2026-06-13 22:14:26.535	2026-06-13 22:14:26.535
cmqcwxqeg0027ibngsivncp3h	echatbot-hq-support	How many operators can collaborate in the console?	There’s no hard cap. Role-based permissions let you add unlimited operators, admins and analysts while tracking their actions in the audit log.	\N	Team	0	t	2026-06-13 22:14:26.536	2026-06-13 22:14:26.536
cmqcwxqeh0028ibng075720xo	echatbot-hq-support	Do you support custom roadmaps or feature requests?	Enterprise contracts include roadmap alignment sessions and private betas. We prioritize features that align with your automation KPIs.	\N	Roadmap	0	t	2026-06-13 22:14:26.537	2026-06-13 22:14:26.537
cmqcwxqei0029ibng5lsdq0e2	echatbot-hq-support	Do I need WhatsApp Business API or can I use regular WhatsApp?	eChatbot requires the official WhatsApp Business API (not the free WhatsApp Business app). We guide you through Meta verification and handle the technical setup. Most businesses get approved within 24-48 hours.	\N	Setup	0	t	2026-06-13 22:14:26.538	2026-06-13 22:14:26.538
cmqcwxqek002aibng26mkr09x	echatbot-hq-support	Can I use my existing phone number or do I need a new one?	You can migrate your existing business number to WhatsApp Business API. However, we recommend a dedicated number for your chatbot to keep personal and business messages separate.	\N	Setup	0	t	2026-06-13 22:14:26.54	2026-06-13 22:14:26.54
cmqcwxqel002bibngteyz99sf	echatbot-hq-support	How long does it take to set up eChatbot?	Basic setup takes about 30 minutes: connect WhatsApp, upload your catalog, configure the AI personality. Full customization with integrations typically takes 1-2 days for Starter, 1-2 weeks for Enterprise.	\N	Setup	0	t	2026-06-13 22:14:26.541	2026-06-13 22:14:26.541
cmqcwxqem002cibngna1uorck	echatbot-hq-support	Can the AI actually sell my products?	Yes! The AI guides customers through product discovery, answers questions, handles objections, and facilitates checkout. It can send product images, create carts, and integrate with your payment system.	\N	AI Capabilities	0	t	2026-06-13 22:14:26.542	2026-06-13 22:14:26.542
cmqcwxqen002dibngsrs5be4m	echatbot-hq-support	How do I upload my product catalog?	You can upload products via CSV import, connect to Shopify/WooCommerce, or use our API. The dashboard lets you add products manually with images, variants, and pricing.	\N	AI Capabilities	0	t	2026-06-13 22:14:26.543	2026-06-13 22:14:26.543
cmqcwxqep002eibnghjqo3thk	echatbot-hq-support	Does the AI support multiple languages?	Yes! The AI auto-detects customer language and responds accordingly. We support Italian, English, Spanish, Portuguese and more. Your catalog stays in one language - the AI translates dynamically.	\N	AI Capabilities	0	t	2026-06-13 22:14:26.545	2026-06-13 22:14:26.545
cmqcwxqeq002fibng8xd91rfm	echatbot-hq-support	Can I customize the chatbot's personality and responses?	Absolutely. You control tone of voice (formal/friendly), bot name, identity response, and custom rules. You can also add FAQ entries that the AI prioritizes over generated responses.	\N	AI Capabilities	0	t	2026-06-13 22:14:26.546	2026-06-13 22:14:26.546
cmqcwxqer002gibngz9f5vcbg	echatbot-hq-support	Can the AI handle payments directly in WhatsApp?	The AI creates carts and sends secure payment links. We integrate with Stripe, PayPal, and custom payment gateways. WhatsApp Pay is not yet available in all regions.	\N	Payments	0	t	2026-06-13 22:14:26.547	2026-06-13 22:14:26.547
cmqcwxqes002hibngpuqzzw0a	echatbot-hq-support	How many messages can I send per month?	There's no hard message limit. You pay per conversation (24h window) according to WhatsApp's official rates. Our dashboard shows real-time usage and costs.	\N	Limits	0	t	2026-06-13 22:14:26.548	2026-06-13 22:14:26.548
cmqcwxqet002iibng63fcnxit	echatbot-hq-support	How many customers can the chatbot handle simultaneously?	Unlimited. The AI responds instantly to any number of concurrent conversations. During peak times (Black Friday, promotions), you won't experience slowdowns.	\N	Limits	0	t	2026-06-13 22:14:26.549	2026-06-13 22:14:26.549
cmqcwxqev002jibngo9pjiyc0	echatbot-hq-support	Is there a limit on products in my catalog?	Starter plans support up to 500 products. Premium handles 5,000+ products. Enterprise has no limits and includes vector search for large catalogs.	\N	Limits	0	t	2026-06-13 22:14:26.551	2026-06-13 22:14:26.551
cmqcwxqex002kibng62hfeslg	echatbot-hq-support	Is there a free trial period?	Yes! Every new workspace gets a 14-day free trial with full features. No credit card required to start. You can test all automations, integrations, and AI capabilities.	\N	Trial	0	t	2026-06-13 22:14:26.553	2026-06-13 22:14:26.553
cmqcwxqey002libng0df5tay3	echatbot-hq-support	Can I cancel my subscription anytime?	Yes, you can cancel anytime from your dashboard. Monthly plans end at the billing cycle. No cancellation fees. Your data is retained for 30 days after cancellation.	\N	Billing	0	t	2026-06-13 22:14:26.554	2026-06-13 22:14:26.554
cmqcwxqez002mibnghcr3nwp3	echatbot-hq-support	Do you offer support in Italian?	Sì! Our team is based in Italy and we offer full support in Italian, English, Spanish, and Portuguese. Enterprise clients get a dedicated Italian-speaking account manager.	\N	Support	0	t	2026-06-13 22:14:26.555	2026-06-13 22:14:26.555
cmqcwxqf1002nibngkrh5mnco	echatbot-hq-support	What are your support response times?	Starter: 24h email support. Premium: 4h response, live chat. Enterprise: 1h response, dedicated Slack channel, phone support during business hours.	\N	Support	0	t	2026-06-13 22:14:26.557	2026-06-13 22:14:26.557
cmqcwxqf2002oibnghuqrhs6l	echatbot-hq-support	Can I add the chatbot to my website?	Yes! We provide an embeddable widget for your website. Just copy-paste a code snippet. The widget syncs with your WhatsApp channel - customers can switch seamlessly.	\N	Widget	0	t	2026-06-13 22:14:26.558	2026-06-13 22:14:26.558
cmqcwxqf4002pibngc0gaka6v	echatbot-hq-support	How do I connect my WhatsApp number?	Go to **Menu > Settings > WhatsApp Channel**.\n\nHere you can:\n- Choose your WhatsApp provider (**Meta** official API or **UltraMsg**)\n- Enter your **phone number**, instance ID, and API token\n- Set the **webhook URL** and verify token\n- Enable or disable the channel with the toggle switch\n\nTip: The Meta official API requires approval from Meta Business. UltraMsg works immediately but has lower throughput.	\N	Platform Guide	10	t	2026-06-13 22:14:26.56	2026-06-13 22:14:26.56
cmqcwxqf5002qibngzbkd21zj	echatbot-hq-support	How do I enable or disable the WhatsApp channel?	Go to **Menu > Settings > WhatsApp Channel**.\n\nToggle the **Channel Active** switch at the top of the page.\n- Active: chatbot responds to incoming messages\n- Disabled: messages are received but NOT answered (the queue still logs them)\n\nUseful when you want to pause the bot temporarily without losing messages.	\N	Platform Guide	11	t	2026-06-13 22:14:26.561	2026-06-13 22:14:26.561
cmqcwxqf7002ribngv7khlp4d	echatbot-hq-support	How do I change the chatbot name and tone of voice?	Go to **Menu > Settings > AI Personality**.\n\nHere you can configure:\n- **Chatbot Name** — the name shown to customers (e.g. Sofia, Alex)\n- **Identity Response** — what the bot says when asked 'Who are you?'\n- **Tone of Voice** — choose FORMAL, FRIENDLY, or PROFESSIONAL\n- **Welcome Message** — the first message sent to new customers\n- **Custom AI Rules** — free-text instructions (e.g. 'Always greet by name', 'Use bullet points')\n\nChanges take effect on the next incoming message — no restart needed.	\N	Platform Guide	20	t	2026-06-13 22:14:26.563	2026-06-13 22:14:26.563
cmqcwxqf8002sibngpa03k0oe	echatbot-hq-support	How do I create a push campaign?	Go to **Menu > Campaigns** (icon near your user avatar in the top bar).\n\nSteps:\n1. Click **New Campaign**\n2. Write the message you want to send\n3. Choose your **target audience** (all customers, by tag, by language, etc.)\n4. Set the **scheduled date and time** or send immediately\n5. Click **Send** or **Schedule**\n\nAfter sending you can monitor delivery rate, open rate, and responses directly in the campaign detail page.	\N	Platform Guide	30	t	2026-06-13 22:14:26.564	2026-06-13 22:14:26.564
cmqcwxqf9002tibngxluq2rng	echatbot-hq-support	How do I add tags to a customer?	Go to **Menu > Customers**, find the customer and click on their name to open the profile.\n\nIn the customer detail panel:\n- Click **Add Tag**\n- Type the tag name (e.g. VIP, trial, italian) and confirm\n- Tags are used to **filter campaigns** and **segment your audience**\n\nYou can also add tags during a live chat from the Chat panel by clicking the customer name at the top.	\N	Platform Guide	40	t	2026-06-13 22:14:26.565	2026-06-13 22:14:26.565
cmqcwxqfb002uibngjd6s4l3c	echatbot-hq-support	How do I see conversations waiting for human support?	Go to **Menu > Queue**.\n\nThe Queue shows all conversations where a customer has requested human assistance (or where the chatbot has escalated to an operator).\n\nFrom here you can:\n- See the **waiting time** for each conversation\n- Click a chat to **open it and reply**\n- **Reassign** chats to a team member\n- Mark conversations as **resolved**\n\nYou can configure email notifications when new escalations arrive: go to **Menu > Settings > Human Support**.	\N	Platform Guide	50	t	2026-06-13 22:14:26.567	2026-06-13 22:14:26.567
cmqcwxqfc002vibngzkgt89n3	echatbot-hq-support	How do I block a customer?	Go to **Menu > Customers**, find the customer and open their profile.\n\nClick the **Block** button (or the three-dot menu > Block).\n- A blocked customer can no longer send messages that the chatbot processes\n- Their existing conversations remain visible in Chat history\n- You can **unblock** them at any time from the same profile\n\nBlocking applies to that specific phone number / contact only.	\N	Platform Guide	60	t	2026-06-13 22:14:26.568	2026-06-13 22:14:26.568
cmqcwxqfe002wibngoi81atml	echatbot-hq-support	What are Custom Tools (Calling Functions) and how do I create one?	Go to **Menu > Settings > Custom Tools**.\n\nCustom Tools allow the chatbot to call your **external APIs** (webhooks) to fetch or send real-time data — for example: check stock, look up order status, or trigger an action in your CRM.\n\nTo create a new tool:\n1. Click **Add Tool**\n2. Enter the **name** the AI will use to identify it (e.g. check_stock)\n3. Enter the **webhook URL** of your API endpoint\n4. Define the **parameters** the AI will collect from the conversation and pass to the API\n5. Set the **HTTP method** (GET or POST)\n6. Save\n\nThe chatbot will automatically call this function when it needs that information.	\N	Platform Guide	70	t	2026-06-13 22:14:26.57	2026-06-13 22:14:26.57
cmqcwxqff002xibngu8dr6i4r	echatbot-hq-support	How do I configure human support and operator escalation?	Go to **Menu > Settings > Human Support**.\n\nHere you can:\n- **Enable/disable** human support for your workspace\n- Set the **escalation message** shown to customers when an operator is assigned (supports variables like {{nameUser}}, {{agentName}}, {{agentPhone}})\n- Choose **contact method**: EMAIL or WHATSAPP for operator notifications\n- Write custom **escalation rules** (what situations should trigger escalation)\n\nOperators receive a notification and can reply from **Menu > Queue** or via the Operator Dashboard link.	\N	Platform Guide	80	t	2026-06-13 22:14:26.571	2026-06-13 22:14:26.571
cmqcwxqfg002yibngufwr82c0	echatbot-hq-support	Where can I see stats and analytics for my chatbot?	Go to **Menu > Analytics**.\n\nThe Analytics dashboard shows:\n- Total conversations and daily trends\n- Messages sent/received\n- Chatbot vs human response breakdown\n- Top FAQ answers used\n- Language distribution of customers\n- Campaign performance (delivery, read rate)\n\nYou can filter by **date range** and export data for BI tools.	\N	Platform Guide	90	t	2026-06-13 22:14:26.572	2026-06-13 22:14:26.572
cmqcwxqfh002zibngvcmr3ywf	echatbot-hq-support	How do I invite a team member to my workspace?	Go to **Menu > Team Collaboration** (accessible from the top navigation bar).\n\nSteps:\n1. Click **Invite Member**\n2. Enter their **email address**\n3. Choose their **role**: SUPER_ADMIN, ADMIN, or MEMBER\n4. Click **Send Invitation**\n\nThey will receive an email with a registration link. Once they accept, they can access your workspace with the permissions you assigned.\n\nRoles:\n- **SUPER_ADMIN** — full access including billing\n- **ADMIN** — full access except billing\n- **MEMBER** — read/respond only	\N	Platform Guide	100	t	2026-06-13 22:14:26.573	2026-06-13 22:14:26.573
cmqcwxqfi0030ibngthzcoy51	echatbot-hq-support	How do I add the chat widget to my website?	Go to **Menu > Settings > Website Widget**.\n\nHere you can:\n- Set the **widget title**, subtitle, and colors to match your brand\n- Choose **position** (bottom-right or bottom-left)\n- Enable or disable the widget channel\n\nTo embed it on your website:\n1. Scroll down to **Widget Code**\n2. Copy the JavaScript snippet\n3. Paste it just before the closing </body> tag of your website\n\nThe widget connects directly to the same chatbot and customer database as WhatsApp.	\N	Platform Guide	110	t	2026-06-13 22:14:26.574	2026-06-13 22:14:26.574
cmqcwxqfk0031ibnguct93gkd	echatbot-hq-support	Where do I see my credit balance and how do I top up?	Go to **Menu > Billing**.\n\nHere you can:\n- See your **current credit balance** and consumption history\n- View the **current plan** (Starter, Premium, Enterprise)\n- **Add credits** via credit card or PayPal\n- Download **monthly invoices**\n\nCredits are consumed per message sent/received. You will receive an email alert when your balance is running low.	\N	Platform Guide	120	t	2026-06-13 22:14:26.576	2026-06-13 22:14:26.576
cmqcwxqfl0032ibngauc3wl3d	echatbot-hq-support	How do I update my business information?	Go to **Menu > Settings > Business Config**.\n\nHere you can update:\n- **Business name**, description, and website URL\n- **Notification email** for alerts\n- **Currency** and **default language**\n\nThese details are used by the chatbot when customers ask about your business.	\N	Platform Guide	130	t	2026-06-13 22:14:26.577	2026-06-13 22:14:26.577
cmqcwxqfn0033ibng7omzi4vi	echatbot-hq-support	How do I restrict which domains can use my widget?	Go to **Menu > Settings > Security**.\n\nIn the **Allowed Domains** field, enter your website domains (one per line, e.g. https://myshop.com).\n\n- Only those domains will be allowed to load your widget\n- Requests from unlisted domains will be blocked (prevents unauthorized embedding)\n- Leave empty to allow all domains (not recommended for production)\n\nAlso here you can manage **2FA enforcement** for your team members.	\N	Platform Guide	140	t	2026-06-13 22:14:26.579	2026-06-13 22:14:26.579
cmqcwxqme004bibng6tf8rfsi	bellitalia-vip-ecommerce	How can I place an order?	To place an order:\n1. Search for products with "search [product name]"\n2. Add to cart with "add [quantity] [product]"\n3. View cart with "show cart"\n4. Confirm order with "proceed to checkout"\n\nYou will receive immediate confirmation via WhatsApp!	\N	Orders	1	t	2026-06-13 22:14:26.822	2026-06-13 22:14:26.822
cmqcwxqmf004cibng9of30byb	bellitalia-vip-ecommerce	I want to place an order	Of course! To place an order, tell me which product or service you would like to purchase and I will add it directly to your cart. For example, you can say:\n- "I want cheese"\n- "Add wine to cart"\n- "I need gift wrapping service"\n\nWhat would you like to order?	\N	Orders	2	t	2026-06-13 22:14:26.823	2026-06-13 22:14:26.823
cmqcwxqmg004dibngxqae8b4o	bellitalia-vip-ecommerce	What is the minimum order amount?	The minimum order is €50.00 for standard shipping. For orders below this amount, a €5.00 handling fee applies.	\N	Orders	3	t	2026-06-13 22:14:26.824	2026-06-13 22:14:26.824
cmqcwxqmh004eibngfyw24tt9	bellitalia-vip-ecommerce	Can I modify an order after placing it?	You can modify an order within 30 minutes of placing it by contacting us immediately. After this time, the order enters processing and can no longer be modified.	\N	Orders	4	t	2026-06-13 22:14:26.825	2026-06-13 22:14:26.825
cmqcwxqmi004fibngagqd3r5t	bellitalia-vip-ecommerce	How can I repeat a previous order?	You can easily repeat a previous order! Write "repeat last order" or "repeat order #[code]". I will show you the details and you can confirm.	\N	Orders	5	t	2026-06-13 22:14:26.826	2026-06-13 22:14:26.826
cmqcwxqmj004gibngve3mvih0	bellitalia-vip-ecommerce	Can I cancel an order?	You can cancel an order within 1 hour of placing it if it is still in "Pending confirmation" status. Once confirmed and in processing, cancellation is no longer possible. Contact us for assistance.	\N	Orders	6	t	2026-06-13 22:14:26.827	2026-06-13 22:14:26.827
cmqcwxqmk004hibnguwnd17xc	bellitalia-vip-ecommerce	Will I receive an order confirmation?	Yes! You will receive immediate confirmation via WhatsApp with:\n- Order code\n- Product summary\n- Total and payment method\n- Estimated delivery times\n\nYou will also receive updates on preparation and shipping.	\N	Orders	7	t	2026-06-13 22:14:26.828	2026-06-13 22:14:26.828
cmqcwxqml004iibngo0sq9glc	bellitalia-vip-ecommerce	What are the delivery times?	Standard delivery times are:\n- Metropolitan area: 24-48 hours\n- Region: 2-3 business days\n- Rest of country: 3-5 business days\n\nOrders confirmed before 2:00 PM ship the same day!	\N	Shipping	8	t	2026-06-13 22:14:26.829	2026-06-13 22:14:26.829
cmqcwxqmm004jibngsa4kspmq	bellitalia-vip-ecommerce	How much does shipping cost?	Shipping costs:\n- FREE for orders over €80\n- €7.50 for orders €50-€80\n- €12.50 for orders under €50\n\nRefrigerated shipping included for fresh products!	\N	Shipping	9	t	2026-06-13 22:14:26.83	2026-06-13 22:14:26.83
cmqcwxqmn004kibngqj5ykor4	bellitalia-vip-ecommerce	How can I track my order?	You can track your order in real-time! Write "where is my order" or "track order #[code]" and I will provide:\n- Current status\n- Courier tracking number\n- Link to follow shipment\n- Delivery estimate	\N	Shipping	10	t	2026-06-13 22:14:26.831	2026-06-13 22:14:26.831
cmqcwxqmo004libngjusp0upe	bellitalia-vip-ecommerce	Do you deliver on Saturdays?	Yes! We deliver Monday to Saturday, 8:00 AM - 6:00 PM. We are closed on Sundays. You can request a preferred time slot in the order notes.	\N	Shipping	11	t	2026-06-13 22:14:26.832	2026-06-13 22:14:26.832
cmqcwxqmp004mibngy4fahcdk	bellitalia-vip-ecommerce	What payment methods do you accept?	We accept:\n✅ Credit cards (Visa, Mastercard, Amex)\n✅ Bank transfer (for business orders)\n✅ PayPal\n✅ Cash on delivery (+€3.00)\n\nPayment is secure and protected with SSL encryption.	\N	Payments	12	t	2026-06-13 22:14:26.833	2026-06-13 22:14:26.833
cmqcwxqmq004nibnggsbg9von	bellitalia-vip-ecommerce	Can I get an invoice?	Certainly! You can request an invoice:\n1. During checkout (provide VAT/Tax ID)\n2. After ordering by writing "invoice order #[code]"\n\nYou will receive the PDF via WhatsApp within 24 hours of the order.	\N	Payments	13	t	2026-06-13 22:14:26.834	2026-06-13 22:14:26.834
cmqcwxqmr004oibnglc7h5fps	bellitalia-vip-ecommerce	When is payment charged?	With card/PayPal: immediate charge upon order confirmation.\nWith bank transfer: order confirmed upon payment receipt (send receipt via WhatsApp).\nCash on delivery: payment upon delivery.	\N	Payments	14	t	2026-06-13 22:14:26.835	2026-06-13 22:14:26.835
cmqcwxqms004pibngm14kn6hm	bellitalia-vip-ecommerce	Is it safe to pay by card?	Absolutely yes! Payments are processed through PCI-DSS certified gateways with SSL/TLS encryption. We never store your card data. All payments are tracked and protected.	\N	Payments	15	t	2026-06-13 22:14:26.836	2026-06-13 22:14:26.836
cmqcwxqmt004qibngqnolo5as	bellitalia-vip-ecommerce	Are the products fresh?	All our products are very fresh! We work with local producers and goods are shipped within 24 hours of production. We use refrigerated packaging to maintain the cold chain.	\N	Products	16	t	2026-06-13 22:14:26.837	2026-06-13 22:14:26.837
cmqcwxqmu004ribng8b34s9m4	bellitalia-vip-ecommerce	Do you have products for food intolerances?	Yes! We have a wide selection of products:\n✅ Gluten-free\n✅ Lactose-free\n✅ Vegetarian\n✅ Vegan\n✅ Halal\n✅ Organic\n\nSearch with filters: "gluten-free products", "vegan", etc.	\N	Products	17	t	2026-06-13 22:14:26.838	2026-06-13 22:14:26.838
cmqcwxqmv004sibng8gcqctwp	bellitalia-vip-ecommerce	How are products packaged?	We use:\n- Food-grade packaging\n- Refrigerated containers for fresh products\n- Eco-friendly protective materials\n- Individual wrapping for delicate products\n\nEverything arrives intact and at the right temperature!	\N	Products	18	t	2026-06-13 22:14:26.839	2026-06-13 22:14:26.839
cmqcwxqmx004tibngjvciat5v	bellitalia-vip-ecommerce	Can I see product certifications?	Yes! Each product has detailed information on:\n- DOP/IGP/STG certifications\n- Organic/Bio certifications\n- Halal certifications\n- Allergen lists\n\nWrite "product details [name]" to see complete information.	\N	Products	19	t	2026-06-13 22:14:26.84	2026-06-13 22:14:26.84
cmqcwxqmy004uibng6espeveq	bellitalia-vip-ecommerce	How do I register?	Registration is automatic! Just start a conversation on WhatsApp and I will guide you. You will need:\n- Name and surname\n- Delivery address\n- Phone number (already have it!)\n\nThat's it, you're registered!	\N	Account	20	t	2026-06-13 22:14:26.842	2026-06-13 22:14:26.842
cmqcwxqmz004vibngzfd0pvgv	bellitalia-vip-ecommerce	How do I change my data?	You can update your information anytime by writing:\n- "change address"\n- "update phone number"\n- "modify delivery address"\n\nI will send you a secure link to update your details.	\N	Account	21	t	2026-06-13 22:14:26.843	2026-06-13 22:14:26.843
cmqcwxqn1004wibngd701b07s	bellitalia-vip-ecommerce	How is my privacy protected?	Your privacy is fundamental:\n✅ Data encrypted with SSL\n✅ GDPR compliant\n✅ No data sharing with third parties\n✅ Right to access, modify, delete data\n\nWrite "privacy policy" to read the complete document.	\N	Account	22	t	2026-06-13 22:14:26.845	2026-06-13 22:14:26.845
cmqcwxqn2004xibngxk9i85g4	bellitalia-vip-ecommerce	How do I invite team members to my workspace?	To invite team members:\n1. Go to Settings → Team section\n2. Click "Invite Member" button (green)\n3. Enter their email address\n4. They will receive an invitation email with a secure link\n\n⚠️ Available on Premium (max 3 members) and Enterprise (unlimited) plans only.	\N	Account	23	t	2026-06-13 22:14:26.846	2026-06-13 22:14:26.846
cmqcwxqn3004yibngc9fy2wbk	bellitalia-vip-ecommerce	What happens when I accept a team invitation?	When you receive a team invitation email:\n1. Click "Accept Invitation" in the email\n2. If you already have an account → automatic acceptance\n3. If you are new → register with the invited email\n4. You will be added to the workspace with ADMIN role\n\n✅ Invitations expire after 7 days for security.	\N	Account	24	t	2026-06-13 22:14:26.847	2026-06-13 22:14:26.847
cmqcwxqn4004zibng02s36n13	bellitalia-vip-ecommerce	How many team members can I add to my workspace?	Team member limits by plan:\n\n🆓 Free Trial: Team members not available\n📊 Basic: Team members not available\n💎 Premium: Up to 3 team members\n🏢 Enterprise: Unlimited team members\n\nUpgrade your plan to add more team members!	\N	Account	25	t	2026-06-13 22:14:26.848	2026-06-13 22:14:26.848
cmqcwxqn50050ibngaeks0yc1	bellitalia-vip-ecommerce	How much does it cost to send messages?	💰 **Message Pricing Structure:**\n\n📱 **WhatsApp Channel**: €0.10 per message\n- You pay only for messages you actually send\n- Each customer message counts as 1 message\n- Replies and notifications also count\n\n🌐 **Web Widget Channel**: €0.05 per message\n- Lower cost for web-based conversations\n- All widget messages count (customer + bot)\n\n📅 **Plus Subscription Fee**:\n- Plan-based subscription (Basic, Premium, Enterprise)\n- Includes team members, features, and dashboard access\n- Billing cycles: Monthly or Annual\n\n💡 **How It Works**:\n1. You choose a subscription plan\n2. Each message sent costs the per-message fee\n3. Total monthly bill = Subscription + (Number of messages × per-message cost)\n4. View real-time costs in your Dashboard → Billing\n\n✅ Free Trial includes 100 messages to test!	\N	Billing	26	t	2026-06-13 22:14:26.849	2026-06-13 22:14:26.849
cmqcwxqn60051ibngil18e7bv	bellitalia-vip-ecommerce	What is included in my subscription plan?	📊 **Subscription Plan Inclusions**:\n\n🆓 **Free Trial** (7 days):\n- 100 free messages to test\n- Full access to all features\n- No credit card required initially\n\n📊 **Basic** (€29/month):\n- Unlimited messages at €0.10 each (WhatsApp) / €0.05 (Widget)\n- Up to 1,000 products in catalog\n- 1 team member\n- Email support\n\n💎 **Premium** (€99/month):\n- Unlimited messages\n- Up to 10,000 products\n- Up to 3 team members\n- Priority support\n- Advanced analytics\n\n🏢 **Enterprise** (Custom pricing):\n- Everything in Premium\n- Unlimited team members\n- Custom integrations\n- Dedicated account manager\n- SLA guarantee\n\n💡 All plans include the per-message cost on top of subscription!	\N	Billing	27	t	2026-06-13 22:14:26.85	2026-06-13 22:14:26.85
cmqcwxqn70052ibngyfrotb5s	bellitalia-vip-ecommerce	How do I upgrade my plan?	📈 **To Upgrade Your Plan**:\n\n1. Go to **Dashboard** → **Billing** → **Plans**\n2. Click **Upgrade** on the desired plan\n3. Choose billing frequency: **Monthly** or **Annual** (save 20%)\n4. Complete payment with card or bank transfer\n5. ✅ Plan activated immediately!\n\n💡 **Prorated Billing**: If you upgrade mid-month, you only pay for the remaining days of the current period + full next period.\n\n🔄 **Downgrade**: You can downgrade anytime. Changes take effect on the next billing cycle.	\N	Billing	28	t	2026-06-13 22:14:26.851	2026-06-13 22:14:26.851
cmqcwxqn90053ibngn4oskq20	bellitalia-vip-ecommerce	Can I send promotional WhatsApp campaigns?	Yes. You can create a promotional campaign, select your audience (all customers, filtered by tags, or a CSV list), and send a templated WhatsApp message. Only contacts with marketing opt-in are allowed.	\N	Campaigns	401	t	2026-06-13 22:14:26.853	2026-06-13 22:14:26.853
cmqcwxqna0054ibngx5xl27hv	bellitalia-vip-ecommerce	How much do campaigns cost?	Each attempted send costs $1.00. The estimated total is shown before you confirm. Credit is deducted per message sent; skipped opt-out/blocked contacts are not charged.	\N	Campaigns	402	t	2026-06-13 22:14:26.854	2026-06-13 22:14:26.854
cmqcwxqnb0055ibngu68yxy0l	bellitalia-vip-ecommerce	Can I schedule a campaign?	Yes. You can send immediately or schedule a date and time. The system throttles sends to respect WhatsApp limits and avoid rate-limit errors.	\N	Campaigns	403	t	2026-06-13 22:14:26.855	2026-06-13 22:14:26.855
cmqcwxqnc0056ibnglo4vyue8	bellitalia-vip-ecommerce	Do recipients need to opt in?	Yes. Only customers with marketing consent are eligible. Blacklisted, blocked, fake, or opt-out contacts are automatically skipped and not charged.	\N	Campaigns	404	t	2026-06-13 22:14:26.856	2026-06-13 22:14:26.856
cmqcwxqnd0057ibng059hxc9l	bellitalia-vip-ecommerce	What happens if I don’t have enough credit?	If credit is insufficient at scheduling, the campaign is blocked. If credit runs out during sending, the campaign pauses and no further messages are sent. You can top up credit and resume.	\N	Campaigns	405	t	2026-06-13 22:14:26.857	2026-06-13 22:14:26.857
\.


--
-- Data for Name: flow_categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.flow_categories (id, "workspaceId", name, slug, description, "lookupRules", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: flow_node_configs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.flow_node_configs (id, "workspaceId", "flowKey", "flowLabel", "systemPrompt", model, temperature, "maxTokens", "availableFunctions", flows, "isActive", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: gdpr_content; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.gdpr_content (id, "workspaceId", gdpr_ita, gdpr_esp, gdpr_eng, gdpr_prt, "createdAt", "updatedAt") FROM stdin;
cmqcwxqxe00jyibng6ouvttp3	bellitalia-vip-ecommerce	# Informativa Privacy e GDPR - Italiano\n\n## 1. Titolare del Trattamento\n\nLa gestione dei tuoi dati personali è effettuata dal titolare del trattamento indicato nella registrazione al servizio eChatbot.\n\n## 2. Finalità del Trattamento\n\nI tuoi dati personali vengono trattati per le seguenti finalità:\n- Fornire i servizi di comunicazione via WhatsApp\n- Gestire gli ordini e le transazioni commerciali\n- Inviare notifiche e aggiornamenti di servizio\n- Conformarsi agli obblighi legali e fiscali\n- Migliorare l'esperienza utente\n\n## 3. Base Legale\n\nIl trattamento dei tuoi dati è basato su:\n- Esecuzione del contratto (art. 6, par. 1, lett. b GDPR)\n- Interesse legittimo (art. 6, par. 1, lett. f GDPR)\n- Conformità a obblighi legali (art. 6, par. 1, lett. c GDPR)\n\n## 4. Categorie di Dati Trattati\n\n- Dati identificativi (nome, cognome, numero di telefono, email)\n- Dati di comunicazione (messaggi WhatsApp, cronologia chat)\n- Dati commerciali (ordini, preferenze prodotti)\n- Dati di localizzazione (paese di provenienza dal numero telefonico)\n- Dati tecnici (IP, tipo di dispositivo, cookie)\n\n## 5. Destinatari dei Dati\n\nI tuoi dati possono essere condivisi con:\n- Provider di servizi WhatsApp (Meta Platforms)\n- Provider di hosting e infrastrutture cloud\n- Partner commerciali e fornitori di servizi\n- Autorità pubbliche quando richiesto per legge\n\n## 6. Periodo di Conservazione\n\nI dati vengono conservati per:\n- Tutta la durata della relazione commerciale\n- 10 anni per obblighi fiscali e contabili\n- Fino a 90 giorni dopo la cancellazione dell'account per esigenze di sicurezza\n\n## 7. Diritti dell'Interessato\n\nHai il diritto di:\n- **Accesso** - Accedere ai tuoi dati personali\n- **Rettifica** - Correggere dati inesatti\n- **Cancellazione** - Eliminare i tuoi dati (diritto all'oblio)\n- **Limitazione** - Limitare il trattamento\n- **Portabilità** - Ricevere i tuoi dati in formato strutturato\n- **Opposizione** - Opporsi al trattamento\n- **Reclamo** - Presentare reclamo all'autorità di controllo\n\n## 8. Come Esercitare i Tuoi Diritti\n\nPer esercitare i diritti sopra indicati, contatta il titolare del trattamento attraverso:\n- Email: privacy@azienda.com\n- Modulo di contatto nel servizio\n- Indirizzo postale fornito dal titolare\n\n## 9. Sicurezza dei Dati\n\nImplementiamo misure di sicurezza tecniche e organizzative per proteggere i tuoi dati da accessi non autorizzati, alterazioni, perdita o distruzione.\n\n## 10. Trasferimenti Internazionali\n\nAlcuni dati potrebbero essere trasferiti a paesi terzi con adeguate garanzie di protezione secondo la normativa GDPR.\n\n## 11. Modifiche alla Informativa\n\nCi riserviamo il diritto di aggiornare questa informativa. Ti notificheremo di modifiche significative.\n\n## 12. Contatti\n\nPer qualsiasi domanda riguardante il trattamento dei tuoi dati:\n- **Data Protection Officer**: dpo@azienda.com\n- **Autorità di Controllo**: Garante per la Protezione dei Dati Personali (Italia)\n	# Aviso de Privacidad y GDPR - Español\n\n## 1. Responsable del Tratamiento\n\nLa gestión de tus datos personales es realizada por el responsable del tratamiento indicado en el registro del servicio eChatbot.\n\n## 2. Finalidad del Tratamiento\n\nTus datos personales se tratan para los siguientes propósitos:\n- Proporcionar servicios de comunicación a través de WhatsApp\n- Gestionar pedidos y transacciones comerciales\n- Enviar notificaciones y actualizaciones del servicio\n- Cumplir con obligaciones legales y fiscales\n- Mejorar la experiencia del usuario\n\n## 3. Base Legal\n\nEl tratamiento de tus datos se basa en:\n- Ejecución del contrato (Art. 6, párr. 1, lit. b RGPD)\n- Interés legítimo (Art. 6, párr. 1, lit. f RGPD)\n- Cumplimiento de obligaciones legales (Art. 6, párr. 1, lit. c RGPD)\n\n## 4. Categorías de Datos Tratados\n\n- Datos de identificación (nombre, apellido, número de teléfono, correo electrónico)\n- Datos de comunicación (mensajes de WhatsApp, historial de chat)\n- Datos comerciales (pedidos, preferencias de productos)\n- Datos de localización (país de origen del número de teléfono)\n- Datos técnicos (IP, tipo de dispositivo, cookies)\n\n## 5. Destinatarios de los Datos\n\nTus datos pueden compartirse con:\n- Proveedores de servicios de WhatsApp (Meta Platforms)\n- Proveedores de alojamiento e infraestructura en la nube\n- Socios comerciales y proveedores de servicios\n- Autoridades públicas cuando sea requerido por ley\n\n## 6. Período de Conservación de Datos\n\nLos datos se conservan durante:\n- Toda la duración de la relación comercial\n- 10 años por obligaciones fiscales y contables\n- Hasta 90 días después de la eliminación de la cuenta por motivos de seguridad\n\n## 7. Tus Derechos\n\nTienes derecho a:\n- **Acceso** - Acceder a tus datos personales\n- **Rectificación** - Corregir datos inexactos\n- **Supresión** - Eliminar tus datos (derecho al olvido)\n- **Limitación** - Limitar el tratamiento\n- **Portabilidad** - Recibir tus datos en formato estructurado\n- **Oposición** - Oponerte al tratamiento\n- **Reclamación** - Presentar una reclamación ante la autoridad supervisora\n\n## 8. Cómo Ejercer Tus Derechos\n\nPara ejercer los derechos mencionados anteriormente, contacta al responsable del tratamiento a través de:\n- Correo electrónico: privacy@empresa.com\n- Formulario de contacto en el servicio\n- Dirección postal proporcionada por el responsable\n\n## 9. Seguridad de Datos\n\nImplementamos medidas de seguridad técnicas y organizativas para proteger tus datos de accesos no autorizados, alteraciones, pérdidas o destrucción.\n\n## 10. Transferencias Internacionales\n\nAlgunos datos pueden ser transferidos a países terceros con garantías adecuadas de protección según la regulación RGPD.\n\n## 11. Cambios en Este Aviso\n\nNos reservamos el derecho de actualizar este aviso. Te notificaremos sobre cambios materiales.\n\n## 12. Información de Contacto\n\nPara cualquier pregunta relacionada con el tratamiento de tus datos:\n- **Delegado de Protección de Datos**: dpo@empresa.com\n- **Autoridad Supervisora**: Autoridad de Protección de Datos de tu país\n	# Privacy Notice and GDPR - English\n\n## 1. Data Controller\n\nThe management of your personal data is carried out by the data controller indicated during registration to the eChatbot service.\n\n## 2. Purpose of Processing\n\nYour personal data is processed for the following purposes:\n- Provide communication services via WhatsApp\n- Manage orders and commercial transactions\n- Send notifications and service updates\n- Comply with legal and tax obligations\n- Improve user experience\n\n## 3. Legal Basis\n\nThe processing of your data is based on:\n- Contract performance (Art. 6, par. 1, lit. b GDPR)\n- Legitimate interest (Art. 6, par. 1, lit. f GDPR)\n- Legal compliance (Art. 6, par. 1, lit. c GDPR)\n\n## 4. Categories of Data Processed\n\n- Identification data (name, surname, phone number, email)\n- Communication data (WhatsApp messages, chat history)\n- Commercial data (orders, product preferences)\n- Location data (country of origin from phone number)\n- Technical data (IP, device type, cookies)\n\n## 5. Data Recipients\n\nYour data may be shared with:\n- WhatsApp service providers (Meta Platforms)\n- Hosting and cloud infrastructure providers\n- Commercial partners and service providers\n- Public authorities when required by law\n\n## 6. Data Retention Period\n\nData is retained for:\n- The entire duration of the commercial relationship\n- 10 years for tax and accounting obligations\n- Up to 90 days after account deletion for security purposes\n\n## 7. Your Rights\n\nYou have the right to:\n- **Access** - Access your personal data\n- **Rectification** - Correct inaccurate data\n- **Erasure** - Delete your data (right to be forgotten)\n- **Restriction** - Restrict processing\n- **Portability** - Receive your data in structured format\n- **Objection** - Object to processing\n- **Lodge a Complaint** - File a complaint with the supervisory authority\n\n## 8. How to Exercise Your Rights\n\nTo exercise the rights mentioned above, contact the data controller through:\n- Email: privacy@company.com\n- Contact form in the service\n- Postal address provided by the data controller\n\n## 9. Data Security\n\nWe implement technical and organizational security measures to protect your data from unauthorized access, alteration, loss, or destruction.\n\n## 10. International Transfers\n\nSome data may be transferred to third countries with appropriate safeguards according to GDPR regulations.\n\n## 11. Changes to This Notice\n\nWe reserve the right to update this notice. We will notify you of material changes.\n\n## 12. Contact Information\n\nFor any questions regarding your data processing:\n- **Data Protection Officer**: dpo@company.com\n- **Supervisory Authority**: Your country's data protection authority\n	# Aviso de Privacidade e GDPR - Português\n\n## 1. Controlador de Dados\n\nA gestão dos seus dados pessoais é realizada pelo controlador de dados indicado no registro do serviço eChatbot.\n\n## 2. Finalidade do Processamento\n\nOs seus dados pessoais são processados para os seguintes fins:\n- Fornecer serviços de comunicação via WhatsApp\n- Gerenciar pedidos e transações comerciais\n- Enviar notificações e atualizações de serviço\n- Cumprir com obrigações legais e fiscais\n- Melhorar a experiência do usuário\n\n## 3. Base Legal\n\nO processamento dos seus dados é baseado em:\n- Execução do contrato (Art. 6, par. 1, lit. b RGPD)\n- Interesse legítimo (Art. 6, par. 1, lit. f RGPD)\n- Cumprimento de obrigações legais (Art. 6, par. 1, lit. c RGPD)\n\n## 4. Categorias de Dados Processados\n\n- Dados de identificação (nome, sobrenome, número de telefone, email)\n- Dados de comunicação (mensagens do WhatsApp, histórico de chat)\n- Dados comerciais (pedidos, preferências de produtos)\n- Dados de localização (país de origem do número de telefone)\n- Dados técnicos (IP, tipo de dispositivo, cookies)\n\n## 5. Destinatários dos Dados\n\nOs seus dados podem ser compartilhados com:\n- Fornecedores de serviços do WhatsApp (Meta Platforms)\n- Provedores de hospedagem e infraestrutura em nuvem\n- Parceiros comerciais e prestadores de serviços\n- Autoridades públicas quando exigido por lei\n\n## 6. Período de Retenção de Dados\n\nOs dados são retidos por:\n- Toda a duração do relacionamento comercial\n- 10 anos por obrigações fiscais e contábeis\n- Até 90 dias após a exclusão da conta por motivos de segurança\n\n## 7. Seus Direitos\n\nVocê tem o direito de:\n- **Acesso** - Acessar seus dados pessoais\n- **Retificação** - Corrigir dados imprecisos\n- **Apagamento** - Deletar seus dados (direito ao esquecimento)\n- **Limitação** - Limitar o processamento\n- **Portabilidade** - Receber seus dados em formato estruturado\n- **Objeção** - Objeter ao processamento\n- **Reclamação** - Apresentar uma reclamação à autoridade supervisora\n\n## 8. Como Exercer Seus Direitos\n\nPara exercer os direitos mencionados acima, entre em contato com o controlador de dados através de:\n- Email: privacy@empresa.com\n- Formulário de contato no serviço\n- Endereço postal fornecido pelo controlador\n\n## 9. Segurança de Dados\n\nImplementamos medidas de segurança técnicas e organizacionais para proteger seus dados contra acesso não autorizado, alteração, perda ou destruição.\n\n## 10. Transferências Internacionais\n\nAlguns dados podem ser transferidos para países terceiros com garantias adequadas de proteção de acordo com a regulação do RGPD.\n\n## 11. Alterações a Este Aviso\n\nNos reservamos o direito de atualizar este aviso. Notificaremos você sobre alterações materiais.\n\n## 12. Informações de Contato\n\nPara qualquer dúvida sobre o processamento dos seus dados:\n- **Encarregado de Proteção de Dados**: dpo@empresa.com\n- **Autoridade Supervisora**: Autoridade de Proteção de Dados do seu país\n	2026-06-13 22:14:27.218	2026-06-13 22:14:27.218
\.


--
-- Data for Name: google_calendar_connections; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.google_calendar_connections (id, "workspaceId", "calendarId", "accessToken", "refreshToken", "tokenExpiry", scope, "connectedAt", "lastSyncAt", "isActive", "errorMessage") FROM stdin;
\.


--
-- Data for Name: invoice_adjustments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.invoice_adjustments (id, "invoiceId", "userId", amount, reason, "createdAt", "createdById", "createdByEmail") FROM stdin;
cmqcwxr5c00mgibngfmsbait5	cmqcwxr5a00mfibngcip2lw53	fd566368-a330-47b4-9b11-3e44622cba2e	-5.25	Manual discount	2026-06-02 07:30:00	fd566368-a330-47b4-9b11-3e44622cba2e	gelsogrove@gmail.com
\.


--
-- Data for Name: invoice_credit_notes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.invoice_credit_notes (id, "invoiceId", "userId", amount, reason, "createdAt", "createdById", "createdByEmail") FROM stdin;
cmqcwxr5d00mhibngrn3fu4ia	cmqcwxr5000mcibngyz5axpt8	fd566368-a330-47b4-9b11-3e44622cba2e	5.00	Goodwill adjustment	2025-12-10 08:30:00	fd566368-a330-47b4-9b11-3e44622cba2e	gelsogrove@gmail.com
\.


--
-- Data for Name: invoice_year_sequences; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.invoice_year_sequences (year, last_value) FROM stdin;
\.


--
-- Data for Name: languages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.languages (id, name, code, "isDefault", "createdAt", "updatedAt", "isActive", "workspaceId") FROM stdin;
1c7e2e57-9f8a-4346-98f1-84c0b2dca546	Italiano	IT	t	2026-06-13 22:14:26.365	2026-06-13 22:14:26.365	t	bellitalia-info-workspace
73ee24f8-a147-457a-acf4-8b45d321ef7e	English	ENG	f	2026-06-13 22:14:26.367	2026-06-13 22:14:26.367	t	bellitalia-info-workspace
b8287af0-7a24-428f-9502-c1a6a8462bcf	Español	ESP	f	2026-06-13 22:14:26.368	2026-06-13 22:14:26.368	t	bellitalia-info-workspace
2e15a0b9-942e-45e8-9f71-5671d4992d9e	Português	PRT	f	2026-06-13 22:14:26.369	2026-06-13 22:14:26.369	t	bellitalia-info-workspace
81a32e5c-e58e-4e92-b43f-45033eb90594	English	ENG	t	2026-06-13 22:14:26.496	2026-06-13 22:14:26.496	t	echatbot-hq-support
478c12dc-40df-47e7-ad24-c8c5a9bb3928	Italiano	IT	f	2026-06-13 22:14:26.498	2026-06-13 22:14:26.498	t	echatbot-hq-support
f74c9b07-1c0d-4d80-8e86-7f37a5b14410	Español	ESP	f	2026-06-13 22:14:26.5	2026-06-13 22:14:26.5	t	echatbot-hq-support
b000dbe3-36b5-444c-8182-d3de3d6d0bfe	Español	ESP	f	2026-06-13 22:14:26.592	2026-06-13 22:14:26.592	t	bellitalia-vip-ecommerce
ac5a30ea-0ac5-49ea-99de-ed63278f9857	Português	PRT	f	2026-06-13 22:14:26.593	2026-06-13 22:14:26.593	t	bellitalia-vip-ecommerce
\.


--
-- Data for Name: late_cancellation_attempts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.late_cancellation_attempts (id, "workspaceId", "customerId", "serviceId", "googleEventId", "scheduledStartTime", "attemptedAt", "tooLateThreshold") FROM stdin;
\.


--
-- Data for Name: merchant_pushes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.merchant_pushes (id, "workspaceId", "merchantId", title, text, "photoUrl", "videoUrl", location, description, "isActive", "createdAt", "updatedAt", "deletedAt", "photoBase64") FROM stdin;
\.


--
-- Data for Name: merchant_quota_topups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.merchant_quota_topups (id, "workspaceId", "merchantId", amount, note, "createdByUserId", "createdAt") FROM stdin;
\.


--
-- Data for Name: merchants; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.merchants (id, "workspaceId", name, description, location, "billingName", "vatNumber", "taxCode", "sdiCode", pec, "billingAddress", "billingCity", "billingZip", "billingProvince", "billingCountry", "isActive", "quotaRemaining", "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.


--
-- Data for Name: message_attachments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.message_attachments (id, "conversationMessageId", "workspaceId", kind, url, "storageKey", "mimeType", filename, "sizeBytes", width, height, "waMediaId", "createdAt") FROM stdin;
\.


--
-- Data for Name: messages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.messages (id, direction, content, type, status, "aiGenerated", metadata, read, "createdAt", "updatedAt", "deletedAt", "chatSessionId", "functionCallsDebug", "processingSource", "translatedQuery", "processedPrompt", "debugInfo", "whatsappStatus", "whatsappError", "whatsappMessageId", "sentBy") FROM stdin;
64106872-48f7-4dcb-bd97-f8b2a81e1bb4	INBOUND	Ciao, vorrei sapere come spedite i prodotti freschi.	TEXT	sent	f	{}	f	2026-06-13 22:11:26.307	2026-06-13 22:14:26.308	\N	633b81a4-7149-431d-bf03-aec01abf3fd7	\N	\N	\N	\N	\N	\N	\N	\N	\N
f69fbd50-6774-4dac-a11e-db9e3fb7680c	OUTBOUND	Ciao! Per i prodotti freschi usiamo trasporto refrigerato dedicato con consegne 48h in tutta Italia.	TEXT	sent	t	{"workspace": "BellItalia Info", "agentSelected": "INFO_AGENT"}	f	2026-06-13 22:12:26.31	2026-06-13 22:14:26.31	\N	633b81a4-7149-431d-bf03-aec01abf3fd7	\N	\N	\N	\N	\N	\N	\N	\N	\N
c0d611ed-0da7-4fb7-b746-4acc36c22baf	INBOUND	Hello, do you have tracking for informational shipments?	TEXT	sent	f	{}	f	2026-06-13 22:11:26.318	2026-06-13 22:14:26.318	\N	165fc672-0cfa-4540-a904-fac39d4b8db5	\N	\N	\N	\N	\N	\N	\N	\N	\N
49343681-3206-4f7b-8cda-f696c6f9fc50	OUTBOUND	Yes, every parcel includes a tracking link so you can follow the delivery in real time.	TEXT	sent	t	{"workspace": "BellItalia Info", "agentSelected": "INFO_AGENT"}	f	2026-06-13 22:12:26.32	2026-06-13 22:14:26.32	\N	165fc672-0cfa-4540-a904-fac39d4b8db5	\N	\N	\N	\N	\N	\N	\N	\N	\N
d4ce5e6e-484b-435d-ac5e-f2817227a7c7	INBOUND	Hola, necesito información sobre envíos combinados de ambiente y refrigerado.	TEXT	sent	f	{}	f	2026-06-13 22:11:26.326	2026-06-13 22:14:26.326	\N	f549b89c-1531-443c-8d98-d3acac7cf851	\N	\N	\N	\N	\N	\N	\N	\N	\N
61b2a78d-2402-4539-bf13-8679ca59cb8a	OUTBOUND	Podemos preparar pedidos mixtos: agrupamos los productos ambiente y enviamos la parte refrigerada en un segundo pallet.	TEXT	sent	t	{"workspace": "BellItalia Info", "agentSelected": "INFO_AGENT"}	f	2026-06-13 22:12:26.328	2026-06-13 22:14:26.328	\N	f549b89c-1531-443c-8d98-d3acac7cf851	\N	\N	\N	\N	\N	\N	\N	\N	\N
2f552c94-9312-4829-9afb-fd1ecbb3c7d0	INBOUND	Olá! Gostaria de saber se enviam com camiões frigoríficos.	TEXT	sent	f	{}	f	2026-06-13 22:11:26.335	2026-06-13 22:14:26.335	\N	1f3f92d5-3a83-439d-b2e5-bb8bcba8f277	\N	\N	\N	\N	\N	\N	\N	\N	\N
3dfcce15-3b72-41c7-bd2a-8226f6575686	OUTBOUND	Olá! Trabalhamos com camiões frigoríficos certificados e entregamos em Portugal continental duas vezes por semana.	TEXT	sent	t	{"workspace": "BellItalia Info", "agentSelected": "INFO_AGENT"}	f	2026-06-13 22:12:26.336	2026-06-13 22:14:26.337	\N	1f3f92d5-3a83-439d-b2e5-bb8bcba8f277	\N	\N	\N	\N	\N	\N	\N	\N	\N
91ae8f7c-2ab2-4d45-bbd4-72900852f6d0	INBOUND	Hi, how much does the Enterprise plan cost with 5 workspaces?	TEXT	sent	f	{}	f	2026-06-13 22:10:26.585	2026-06-13 22:14:26.586	\N	c03b705c-f8fe-4404-9041-84805eb72439	\N	\N	\N	\N	\N	\N	\N	\N	\N
a0bd1234-c4fb-4fca-8e9a-2e1687380c6e	OUTBOUND	Hi Sara! Enterprise starts from €899/month and scales with active workspaces. I can share a tailored quote or connect you with a consultant.	TEXT	sent	t	{"agentSelected": "INFO_AGENT"}	f	2026-06-13 22:11:26.587	2026-06-13 22:14:26.588	\N	c03b705c-f8fe-4404-9041-84805eb72439	\N	\N	\N	\N	\N	\N	\N	\N	\N
6c7cf969-ba9a-4c24-b054-9689cf77512f	INBOUND	Ciao!	TEXT	sent	f	{}	f	2026-06-13 22:09:26.944	2026-06-13 22:14:26.945	\N	b2357c3e-040b-4f0b-9b8e-db0e19a675c4	\N	\N	\N	\N	\N	\N	\N	\N	\N
a91db28b-9fc1-4f34-9863-f01566bbfc19	OUTBOUND	Ciao! Benvenuto in BellItalia. Come posso aiutarti oggi?	TEXT	sent	t	{"sentBy": "AI", "agentSelected": "CHATBOT_DUAL_LLM"}	f	2026-06-13 22:10:26.945	2026-06-13 22:14:26.946	\N	b2357c3e-040b-4f0b-9b8e-db0e19a675c4	\N	\N	\N	\N	\N	\N	\N	\N	\N
1dc6ddb9-2ac5-42bd-ad85-07c3c44a2323	INBOUND	¡Hola!	TEXT	sent	f	{}	f	2026-06-13 22:13:26.949	2026-06-13 22:14:26.949	\N	1abdb4d6-d289-4a67-89cb-f9851df4a2ab	\N	\N	\N	\N	\N	\N	\N	\N	\N
24af626e-ca67-4041-b7dd-e28ecc08ee38	OUTBOUND	¡Hola, mucho gusto conocerte! ¿Cómo puedo ayudarte?	TEXT	sent	t	{"sentBy": "AI", "agentSelected": "CHATBOT_DUAL_LLM"}	f	2026-06-13 22:14:26.95	2026-06-13 22:14:26.95	\N	1abdb4d6-d289-4a67-89cb-f9851df4a2ab	\N	\N	\N	\N	\N	\N	\N	\N	\N
1fa96805-1c03-4d6e-b3cb-5cf0f301ab3b	INBOUND	Olá!	TEXT	sent	f	{}	f	2026-06-13 22:13:56.954	2026-06-13 22:14:26.954	\N	91288484-fcbc-4c8f-af59-95ff094d1d4c	\N	\N	\N	\N	\N	\N	\N	\N	\N
14951c29-a7e8-445c-b358-f7ad0cb4a579	OUTBOUND	Olá, prazer em conhecê-lo! Como posso ajudá-lo?	TEXT	sent	t	{"sentBy": "AI", "agentSelected": "CHATBOT_DUAL_LLM"}	f	2026-06-13 22:14:11.955	2026-06-13 22:14:26.955	\N	91288484-fcbc-4c8f-af59-95ff094d1d4c	\N	\N	\N	\N	\N	\N	\N	\N	\N
8b9553d4-2086-47c0-b3f1-3aa33b3d9334	INBOUND	Hello!	TEXT	sent	f	{}	f	2026-06-13 22:12:26.96	2026-06-13 22:14:26.961	\N	feae6cdb-6015-4655-b8f0-296272e12b82	\N	\N	\N	\N	\N	\N	\N	\N	\N
e266e4dd-5b36-4bd4-b381-e69dc3faf6ca	OUTBOUND	Hello! Welcome to BellItalia. How can I help you today?	TEXT	sent	t	{"sentBy": "AI", "agentSelected": "CHATBOT_DUAL_LLM"}	f	2026-06-13 22:13:26.961	2026-06-13 22:14:26.962	\N	feae6cdb-6015-4655-b8f0-296272e12b82	\N	\N	\N	\N	\N	\N	\N	\N	\N
\.


--
-- Data for Name: messages_archive; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.messages_archive (id, "originalId", direction, content, type, status, "aiGenerated", metadata, read, "createdAt", "updatedAt", "archivedAt", "chatSessionId", "workspaceId", "customerId", "functionCallsDebug", "processingSource", "translatedQuery", "processedPrompt", "debugInfo", "whatsappStatus", "whatsappError", "whatsappMessageId", "sentBy") FROM stdin;
\.


--
-- Data for Name: monthly_invoices; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.monthly_invoices (id, "userId", "invoiceNumber", "periodStart", "periodEnd", "periodMonth", "periodYear", "subscriptionAmount", "creditUsage", "creditDebt", "creditNotesTotal", "subtotalAmount", "taxRate", "taxAmount", "totalAmount", status, "paidAt", "paypalTransactionId", "paymentRetryCount", "adminNotes", "adminMarkedById", "adminMarkedAt", "planType", "itemsBreakdown", "createdAt", "updatedAt") FROM stdin;
cmqcwxr4h00m8ibngcupumpgx	fd566368-a330-47b4-9b11-3e44622cba2e	20250801-0001	2025-06-30 22:00:00	2025-07-31 21:59:59	7	2025	45.00	4.20	0.00	0.00	0.00	0.2200	0.00	49.20	PAID	2025-08-01 07:10:00	\N	0	\N	\N	\N	PREMIUM	{"orders": 4, "messages": 42, "pushNotifications": 1}	2026-06-13 22:14:27.472	2026-06-13 22:14:27.475
cmqcwxr4l00m9ibnguquxzf2o	fd566368-a330-47b4-9b11-3e44622cba2e	20250901-0002	2025-07-31 22:00:00	2025-08-31 21:59:59	8	2025	45.00	6.40	0.00	0.00	0.00	0.2200	0.00	51.40	PAID	2025-09-01 07:05:00	\N	0	\N	\N	\N	PREMIUM	{"orders": 6, "messages": 64, "pushNotifications": 1}	2026-06-13 22:14:27.476	2026-06-13 22:14:27.479
cmqcwxr4p00maibng0mfru1sj	fd566368-a330-47b4-9b11-3e44622cba2e	20251001-0003	2025-08-31 22:00:00	2025-09-30 21:59:59	9	2025	45.00	5.60	0.00	0.00	0.00	0.2200	0.00	50.60	PAID	2025-10-01 07:12:00	\N	0	\N	\N	\N	PREMIUM	{"orders": 6, "messages": 56, "pushNotifications": 1}	2026-06-13 22:14:27.48	2026-06-13 22:14:27.483
cmqcwxr4t00mbibngg8bs0h8q	fd566368-a330-47b4-9b11-3e44622cba2e	20251101-0004	2025-09-30 22:00:00	2025-10-31 22:59:59	10	2025	45.00	5.00	0.00	0.00	0.00	0.2200	0.00	50.00	PAID	2025-11-01 09:00:00	\N	0	\N	\N	\N	PREMIUM	{"orders": 5, "messages": 50, "pushNotifications": 2}	2026-06-13 22:14:27.484	2026-06-13 22:14:27.488
cmqcwxr5400mdibngup9y6se1	fd566368-a330-47b4-9b11-3e44622cba2e	\N	2025-11-30 23:00:00	2025-12-31 22:59:59	12	2025	45.00	2.60	0.00	0.00	0.00	0.2200	0.00	47.60	PENDING	\N	\N	0	Check credit note before payment	\N	\N	PREMIUM	{"orders": 2, "messages": 26, "pushNotifications": 0}	2026-06-13 22:14:27.495	2026-06-13 22:14:27.495
cmqcwxr5a00mfibngcip2lw53	fd566368-a330-47b4-9b11-3e44622cba2e	\N	2026-04-30 22:00:00	2026-05-31 21:59:59	5	2026	45.00	6.75	0.00	0.00	0.00	0.2200	0.00	51.75	PENDING	\N	\N	0	\N	\N	\N	PREMIUM	{"orders": 6, "messages": 60, "pushNotifications": 1}	2026-06-13 22:14:27.501	2026-06-13 22:14:27.501
cmqcwxr5h00miibng0tbxloo9	fd566368-a330-47b4-9b11-3e44622cba2e	\N	2026-03-31 22:00:00	2026-04-30 21:59:59	4	2026	45.00	4.10	0.00	0.00	0.00	0.2200	0.00	49.10	FAILED	\N	\N	0	Failed payment - retry later	\N	\N	PREMIUM	{"orders": 4, "messages": 41, "pushNotifications": 0}	2026-06-13 22:14:27.508	2026-06-13 22:14:27.508
cmqcwxr5000mcibngyz5axpt8	fd566368-a330-47b4-9b11-3e44622cba2e	20251201-0005	2025-10-31 23:00:00	2025-11-30 22:59:59	11	2025	45.00	3.50	0.00	0.00	0.00	0.2200	0.00	48.50	PAID	2025-12-01 09:00:00	\N	0	Paid after retry	\N	\N	PREMIUM	{"orders": 8, "messages": 35, "pushNotifications": 3}	2026-06-13 22:14:27.491	2026-06-13 22:14:27.51
cmqcwxr5700meibngpmt1ig3n	fd566368-a330-47b4-9b11-3e44622cba2e	\N	2026-05-31 22:00:00	2026-06-30 21:59:59	6	2026	160.00	5.30	0.00	0.00	160.00	0.2200	35.20	195.20	DRAFT	\N	\N	0	Current month review pending	\N	\N	PREMIUM	{"orders": {"count": 0, "amount": 0}, "messages": {"count": 3, "amount": 0.3}, "adjustments": {"count": 0, "amount": 0}, "totalConsumption": 5.3, "pushNotifications": {"count": 5, "amount": 5}}	2026-06-13 22:14:27.498	2026-06-14 13:39:20.487
\.


--
-- Data for Name: offers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.offers (id, name, description, "discountPercent", "startDate", "endDate", "isActive", "categoryId", "workspaceId", "createdAt", "updatedAt") FROM stdin;
cmqcwxqm90048ibng62wwyt61	Frozen Products 20% Offer	20% discount on all frozen products!	20	2025-01-01 00:00:00	2026-12-31 23:59:59.999	t	63377316-b0dd-478e-8b5a-60458c97f8f8	bellitalia-vip-ecommerce	2026-06-13 22:14:26.817	2026-06-13 22:14:26.817
cmqcwxqma0049ibngzmldlq5w	Black Friday Special	Huge discounts on all products for Black Friday weekend!	10	2025-11-25 00:00:00	2025-12-01 23:59:59.999	f	64c27872-f13e-4f7d-93e1-36554da37e06	bellitalia-vip-ecommerce	2026-06-13 22:14:26.818	2026-06-13 22:14:26.818
cmqcwxqmc004aibngahiqqtgw	Summer Sale	Special summer discounts on selected products!	10	2025-06-01 00:00:00	2025-08-31 23:59:59.999	f	64c27872-f13e-4f7d-93e1-36554da37e06	bellitalia-vip-ecommerce	2026-06-13 22:14:26.82	2026-06-13 22:14:26.82
\.


--
-- Data for Name: onboarding_questionnaires; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.onboarding_questionnaires (id, "createdAt", "fullName", email, phone, company, "stepIndustry", "stepGoal", "stepHumanSupport", "stepPushMarketing", "stepReminders", "stepWidget", "stepSalesAgents", "stepEcommerce", "stepEcommercePlatform", "stepIntegrations", "stepPrivacy", "stepOnPremise", "stepHelpful", "stepInterest", "stepOther", "stepDemo", lang, "wantsContact", "stepChannel", "stepTimeSaving", "stepDocuments", "stepIntegration", "stepHandoff", "stepMarketing", status, "adminNotes") FROM stdin;
\.


--
-- Data for Name: order_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.order_items (id, "itemType", quantity, "unitPrice", "totalPrice", "productVariant", "createdAt", "updatedAt", "deletedAt", "orderId", "productId", "serviceId") FROM stdin;
166c1df4-b0c4-4169-aa0a-47d9c6042f8d	PRODUCT	3	4.20	12.60	\N	2026-06-13 22:14:27.026	2026-06-13 22:14:27.026	\N	7e254f5c-14ff-4f25-a04b-57af5ed851e6	\N	\N
15134d02-2c43-4a69-a921-ce21ff1377c4	PRODUCT	3	4.20	12.60	\N	2026-06-13 22:14:27.039	2026-06-13 22:14:27.039	\N	27e64599-9b3d-4780-841b-62436c766102	\N	\N
e01320c5-cbe2-4a3a-b004-5cee767fd9ed	PRODUCT	1	4.20	4.20	\N	2026-06-13 22:14:27.098	2026-06-13 22:14:27.098	\N	5af2e857-c3ce-492c-8b05-28ba4881bf53	\N	\N
4169c5fd-9e0c-4ec0-aea0-a6d97ad2bc32	PRODUCT	2	4.20	8.40	\N	2026-06-13 22:14:27.12	2026-06-13 22:14:27.12	\N	f2f83167-4df7-494a-8b04-65bb19e082eb	\N	\N
29c36602-78be-49e3-a75a-f04378f86688	PRODUCT	1	4.20	4.20	\N	2026-06-13 22:14:27.131	2026-06-13 22:14:27.131	\N	1865fd78-b4ca-40eb-acb5-e48d8c975ad4	\N	\N
c4be1bb5-dffa-44c9-904b-84d46bb3d3bd	PRODUCT	1	4.20	4.20	\N	2026-06-13 22:14:27.163	2026-06-13 22:14:27.163	\N	193b34a5-4f6d-43cd-ba5c-bde95368a9ad	\N	\N
c8343225-82b6-4a6d-adbc-d323dee00cf9	PRODUCT	1	4.20	4.20	\N	2026-06-13 22:14:27.189	2026-06-13 22:14:27.189	\N	5a3935b4-c539-4161-9680-26b99e4ebe59	\N	\N
0a5defa9-1e2d-4f87-b995-27cab3b1e763	PRODUCT	1	4.20	4.20	\N	2026-06-13 22:14:27.205	2026-06-13 22:14:27.205	\N	f4bd5fa9-8053-4ef5-82c2-5b4b48644d5c	\N	\N
a09f526f-9e5c-44ce-902d-146f515ac164	PRODUCT	1	6.20	6.20	\N	2026-06-13 22:14:27.04	2026-06-13 22:14:27.04	\N	27e64599-9b3d-4780-841b-62436c766102	\N	\N
83a82c9f-7cda-4d87-9d07-535994ec7c76	PRODUCT	3	6.20	18.60	\N	2026-06-13 22:14:27.052	2026-06-13 22:14:27.052	\N	05bc22a7-8985-47cb-a91f-cc524befd509	\N	\N
a9e45553-1592-4759-afe2-30b54fc737dd	PRODUCT	1	6.20	6.20	\N	2026-06-13 22:14:27.059	2026-06-13 22:14:27.059	\N	6f424adf-6452-47d6-a785-c45513ec87f6	\N	\N
a250e1e4-4363-495c-a9a4-9ec81654ffb4	PRODUCT	1	6.20	6.20	\N	2026-06-13 22:14:27.168	2026-06-13 22:14:27.168	\N	f44826ad-ec06-4446-8e5a-38324e4aa03f	\N	\N
c82036cf-5edf-4633-89b6-46e02ccaeccc	PRODUCT	2	6.20	12.40	\N	2026-06-13 22:14:27.206	2026-06-13 22:14:27.206	\N	f4bd5fa9-8053-4ef5-82c2-5b4b48644d5c	\N	\N
949d054b-bbf8-43eb-a151-dd6e1f8543cd	PRODUCT	1	6.20	6.20	\N	2026-06-13 22:14:27.207	2026-06-13 22:14:27.207	\N	f4bd5fa9-8053-4ef5-82c2-5b4b48644d5c	\N	\N
1c5e6a78-d426-4b1c-ac05-020dea5544c0	PRODUCT	1	6.20	6.20	\N	2026-06-13 22:14:27.212	2026-06-13 22:14:27.212	\N	486d76eb-4487-4e0b-a1a3-77e1636a8955	\N	\N
e6012892-d808-4a87-bd98-3a5879004e82	PRODUCT	3	7.50	22.50	\N	2026-06-13 22:14:27.016	2026-06-13 22:14:27.016	\N	08a75e4b-3bc4-4508-9cfd-b0cc4029f068	\N	\N
6fc65224-02e2-433e-b8ce-69b861c6d78a	PRODUCT	3	7.50	22.50	\N	2026-06-13 22:14:27.036	2026-06-13 22:14:27.036	\N	db0ca7bb-fc53-406b-816f-a141866201e0	\N	\N
2e5a80ae-ff3a-44a4-95d5-df30bd47bd97	PRODUCT	3	7.50	22.50	\N	2026-06-13 22:14:27.077	2026-06-13 22:14:27.077	\N	6c6cb125-d775-49eb-a021-d517fb37f27d	\N	\N
e3dfe22b-3549-4818-84da-e39b38373805	PRODUCT	3	7.50	22.50	\N	2026-06-13 22:14:27.087	2026-06-13 22:14:27.087	\N	0f876b0c-57b2-4b5f-9efd-7dc4372fc4d2	\N	\N
261b4ced-1102-4d75-b4ac-e3ef419115b1	PRODUCT	1	7.50	7.50	\N	2026-06-13 22:14:27.098	2026-06-13 22:14:27.098	\N	5af2e857-c3ce-492c-8b05-28ba4881bf53	\N	\N
a4af218c-d2d5-4d60-9d40-e8f73bcb41a0	PRODUCT	2	7.50	15.00	\N	2026-06-13 22:14:27.115	2026-06-13 22:14:27.115	\N	fe89c65e-5728-4148-9ad5-aff02d90d343	\N	\N
2b9e2066-6cd6-4060-b083-6b9deed31ace	PRODUCT	1	7.50	7.50	\N	2026-06-13 22:14:27.148	2026-06-13 22:14:27.148	\N	c9e47afe-9174-414d-91f1-7d383cea9764	\N	\N
daf337d0-424f-4309-87b3-2d5c38cf5d35	PRODUCT	1	7.50	7.50	\N	2026-06-13 22:14:27.187	2026-06-13 22:14:27.187	\N	5a3935b4-c539-4161-9680-26b99e4ebe59	\N	\N
35b505e1-2985-4f8c-aa42-6952991c2980	PRODUCT	2	14.50	29.00	\N	2026-06-13 22:14:27.021	2026-06-13 22:14:27.021	\N	1e214c6f-17ca-42c3-85d7-a8ee77ba35e9	\N	\N
bcc7241c-0420-435e-a629-6dc4f0100f81	PRODUCT	1	14.50	14.50	\N	2026-06-13 22:14:27.047	2026-06-13 22:14:27.047	\N	840444f3-593e-495f-b634-076c9635b0ba	\N	\N
80494c20-6cc9-4f29-9311-3d14a274b217	PRODUCT	2	14.50	29.00	\N	2026-06-13 22:14:27.048	2026-06-13 22:14:27.048	\N	840444f3-593e-495f-b634-076c9635b0ba	\N	\N
35d02878-51d1-47c8-afed-6a1f00915ec5	PRODUCT	2	14.50	29.00	\N	2026-06-13 22:14:27.055	2026-06-13 22:14:27.055	\N	b015e2d4-3732-464a-80c3-110b64c1ba36	\N	\N
f51b5190-0fd9-4bc9-aca9-9e91bc3afb57	PRODUCT	1	14.50	14.50	\N	2026-06-13 22:14:27.076	2026-06-13 22:14:27.076	\N	6c6cb125-d775-49eb-a021-d517fb37f27d	\N	\N
837f3ef0-9364-44b1-aced-069b4da1694b	PRODUCT	3	14.50	43.50	\N	2026-06-13 22:14:27.084	2026-06-13 22:14:27.084	\N	72c5bc18-cc29-47a9-a8cd-d260f2988812	\N	\N
0f1fda6d-6bf6-48bd-bbaa-80a88259f132	PRODUCT	2	14.50	29.00	\N	2026-06-13 22:14:27.093	2026-06-13 22:14:27.093	\N	c7d5eb44-06f7-4686-b78c-f6c3430deb70	\N	\N
981f9f0a-3062-435e-be49-403a16918bdb	PRODUCT	2	14.50	29.00	\N	2026-06-13 22:14:27.103	2026-06-13 22:14:27.103	\N	169803fd-b86f-4b4a-8331-f1d979669aa7	\N	\N
5428f61c-853f-4c5d-a2e3-37be0216c6ad	PRODUCT	3	14.50	43.50	\N	2026-06-13 22:14:27.111	2026-06-13 22:14:27.111	\N	8b069aac-8de9-4bbb-ae4e-5779ec490336	\N	\N
f6150f42-906d-445c-bfd6-416d9034f2a1	PRODUCT	2	14.50	29.00	\N	2026-06-13 22:14:27.127	2026-06-13 22:14:27.127	\N	76a94256-0a3b-425c-b9f6-0eea171f9b11	\N	\N
2c5e5406-05de-4f28-a0ee-ea5abc98b0a7	PRODUCT	3	14.50	43.50	\N	2026-06-13 22:14:27.139	2026-06-13 22:14:27.139	\N	5aab94fb-6dd0-435e-a885-23e0ae964b36	\N	\N
f4e773d9-772c-4677-b1ab-293d986524be	PRODUCT	1	14.50	14.50	\N	2026-06-13 22:14:27.14	2026-06-13 22:14:27.14	\N	5aab94fb-6dd0-435e-a885-23e0ae964b36	\N	\N
8e64564c-5bd9-433f-a531-3bb2687c95af	PRODUCT	2	14.50	29.00	\N	2026-06-13 22:14:27.144	2026-06-13 22:14:27.144	\N	9163d666-8040-4e31-900a-1018ca51a16f	\N	\N
15120bcd-8074-4d62-84c5-f7f7ac3f94c2	PRODUCT	1	14.50	14.50	\N	2026-06-13 22:14:27.149	2026-06-13 22:14:27.149	\N	c9e47afe-9174-414d-91f1-7d383cea9764	\N	\N
37fca433-1d7f-42da-abab-4213f8a7c9ec	PRODUCT	1	8.90	8.90	\N	2026-06-13 22:14:27.02	2026-06-13 22:14:27.02	\N	1e214c6f-17ca-42c3-85d7-a8ee77ba35e9	\N	\N
b9bd25e9-7b15-470a-ad96-53e9744fa068	PRODUCT	1	8.90	8.90	\N	2026-06-13 22:14:27.027	2026-06-13 22:14:27.027	\N	7e254f5c-14ff-4f25-a04b-57af5ed851e6	\N	\N
eecf4699-eb3c-425e-af4e-64ff3d75c2e5	PRODUCT	1	8.90	8.90	\N	2026-06-13 22:14:27.034	2026-06-13 22:14:27.034	\N	3fe399e4-4c79-4f9a-8671-d16f235ca321	\N	\N
6e078f97-b3a3-467d-9753-3b0f58a61a5b	PRODUCT	3	8.90	26.70	\N	2026-06-13 22:14:27.066	2026-06-13 22:14:27.066	\N	72cfa127-0f5f-4e64-aa4e-b96f93a761ff	\N	\N
c73043e2-2bc1-43e3-9ae0-34f1260e33bf	PRODUCT	2	8.90	17.80	\N	2026-06-13 22:14:27.073	2026-06-13 22:14:27.073	\N	a2766dbb-05c9-4331-b6a4-654df52722ce	\N	\N
cf72736c-7b13-4e7f-a9c9-b19acd3af93c	PRODUCT	2	8.90	17.80	\N	2026-06-13 22:14:27.1	2026-06-13 22:14:27.1	\N	7a65a86e-d5fa-466d-af78-c6517d1ef2b0	\N	\N
9547af9f-5e6d-4a27-872e-9985a75a9123	PRODUCT	3	8.90	26.70	\N	2026-06-13 22:14:27.105	2026-06-13 22:14:27.105	\N	1649792d-8ab0-4328-8dfa-1d7f75179eff	\N	\N
b45c7726-9268-4b75-bfcd-2c541a199e9c	PRODUCT	2	8.90	17.80	\N	2026-06-13 22:14:27.124	2026-06-13 22:14:27.124	\N	06e36b6c-8c2a-4841-90ae-74a94c95c567	\N	\N
867afff7-46ce-4719-be2c-debc746747a7	PRODUCT	3	8.90	26.70	\N	2026-06-13 22:14:27.136	2026-06-13 22:14:27.136	\N	e0b08d45-f795-4e0d-9caa-e55b48c63cba	\N	\N
e5d98e96-e827-4235-913e-4ac44112ff02	PRODUCT	3	8.90	26.70	\N	2026-06-13 22:14:27.188	2026-06-13 22:14:27.188	\N	5a3935b4-c539-4161-9680-26b99e4ebe59	\N	\N
8d9353bb-42f9-41e4-80ca-eafae096515c	PRODUCT	2	12.80	25.60	\N	2026-06-13 22:14:27.047	2026-06-13 22:14:27.047	\N	840444f3-593e-495f-b634-076c9635b0ba	\N	\N
9d541f71-2ee7-4261-b91f-45ec805d7f84	PRODUCT	2	12.80	25.60	\N	2026-06-13 22:14:27.066	2026-06-13 22:14:27.066	\N	72cfa127-0f5f-4e64-aa4e-b96f93a761ff	\N	\N
4a1521ba-c07f-45f9-9498-8b8f6160e8f3	PRODUCT	1	12.80	12.80	\N	2026-06-13 22:14:27.083	2026-06-13 22:14:27.083	\N	72c5bc18-cc29-47a9-a8cd-d260f2988812	\N	\N
c493b34c-cdef-47a1-9363-db9983f9210c	PRODUCT	1	12.80	12.80	\N	2026-06-13 22:14:27.083	2026-06-13 22:14:27.083	\N	72c5bc18-cc29-47a9-a8cd-d260f2988812	\N	\N
519501cf-8c5f-4689-832c-1d327418c422	PRODUCT	2	12.80	25.60	\N	2026-06-13 22:14:27.091	2026-06-13 22:14:27.091	\N	06869d50-5db1-47dd-a6ed-c1ac547cf406	\N	\N
e6da5e61-f0ea-46b5-8d76-de3282e8a5a6	PRODUCT	2	12.80	25.60	\N	2026-06-13 22:14:27.097	2026-06-13 22:14:27.097	\N	5af2e857-c3ce-492c-8b05-28ba4881bf53	\N	\N
5f2e86a5-15c7-4a27-a2c1-6b627f2c80f9	PRODUCT	2	12.80	25.60	\N	2026-06-13 22:14:27.108	2026-06-13 22:14:27.108	\N	76992287-6f5a-41dc-80fc-ee609d14c9c9	\N	\N
ebd450d1-f9cf-4578-8052-a76a279b4077	PRODUCT	3	12.80	38.40	\N	2026-06-13 22:14:27.112	2026-06-13 22:14:27.112	\N	8b069aac-8de9-4bbb-ae4e-5779ec490336	\N	\N
815e4828-ff61-493f-a450-3bfe79082164	PRODUCT	3	12.80	38.40	\N	2026-06-13 22:14:27.135	2026-06-13 22:14:27.135	\N	e0b08d45-f795-4e0d-9caa-e55b48c63cba	\N	\N
fc872fe5-2699-4781-8d38-b067559d09ab	PRODUCT	3	12.80	38.40	\N	2026-06-13 22:14:27.173	2026-06-13 22:14:27.173	\N	ddf78a45-b2cb-4a9a-aa11-83a43a0c2863	\N	\N
3ff5d7d5-df73-494c-8978-054461dbf207	PRODUCT	1	12.80	12.80	\N	2026-06-13 22:14:27.195	2026-06-13 22:14:27.195	\N	3487bb77-b199-4808-b8a0-81131bf74088	\N	\N
9e1430ee-64df-4c07-9574-81e005de9b84	PRODUCT	3	9.50	28.50	\N	2026-06-13 22:14:27.025	2026-06-13 22:14:27.025	\N	7e254f5c-14ff-4f25-a04b-57af5ed851e6	\N	\N
1b5e17ca-23e9-4a36-84cc-2f8c09de5210	PRODUCT	2	9.50	19.00	\N	2026-06-13 22:14:27.033	2026-06-13 22:14:27.033	\N	3fe399e4-4c79-4f9a-8671-d16f235ca321	\N	\N
49b11b97-73dc-4aff-972c-9a571408c26c	PRODUCT	1	9.50	9.50	\N	2026-06-13 22:14:27.034	2026-06-13 22:14:27.034	\N	3fe399e4-4c79-4f9a-8671-d16f235ca321	\N	\N
5d5bc60f-0dc4-4437-a888-4bc9a624ed2b	PRODUCT	1	9.50	9.50	\N	2026-06-13 22:14:27.043	2026-06-13 22:14:27.043	\N	e238966d-679a-4444-8eac-2dc9a7f8c8c9	\N	\N
e7299b9a-6461-4e0f-867e-e4a56c791e1d	PRODUCT	3	9.50	28.50	\N	2026-06-13 22:14:27.063	2026-06-13 22:14:27.063	\N	f0619d2d-aea2-4b39-8e49-2d8ce45b9218	\N	\N
1e93de8a-a48c-4b99-bfaf-65c043965862	PRODUCT	2	9.50	19.00	\N	2026-06-13 22:14:27.094	2026-06-13 22:14:27.094	\N	c7d5eb44-06f7-4686-b78c-f6c3430deb70	\N	\N
6ee38f8c-71f2-40fc-b153-6014489f9ea5	PRODUCT	3	9.50	28.50	\N	2026-06-13 22:14:27.115	2026-06-13 22:14:27.115	\N	fe89c65e-5728-4148-9ad5-aff02d90d343	\N	\N
342ee133-669f-4799-8ce9-c32aa2b8cc52	PRODUCT	2	9.50	19.00	\N	2026-06-13 22:14:27.117	2026-06-13 22:14:27.117	\N	77b074a0-63d4-4309-9a5b-a4f53442e9bd	\N	\N
15f169d7-f38b-4c84-a13e-00d749bd9608	PRODUCT	2	9.50	19.00	\N	2026-06-13 22:14:27.129	2026-06-13 22:14:27.129	\N	76a94256-0a3b-425c-b9f6-0eea171f9b11	\N	\N
f0305450-b2d8-43cd-bfd5-de5581192866	PRODUCT	1	9.50	9.50	\N	2026-06-13 22:14:27.143	2026-06-13 22:14:27.143	\N	9163d666-8040-4e31-900a-1018ca51a16f	\N	\N
2b61d13b-73f7-49ee-8f3b-80d66d17f4d4	PRODUCT	3	9.50	28.50	\N	2026-06-13 22:14:27.179	2026-06-13 22:14:27.179	\N	a576d931-0638-4db0-908e-cec770085c22	\N	\N
3f25950a-0388-406d-9b22-c1d69c2dc0eb	PRODUCT	3	9.50	28.50	\N	2026-06-13 22:14:27.196	2026-06-13 22:14:27.196	\N	3487bb77-b199-4808-b8a0-81131bf74088	\N	\N
4cfa1718-57f9-4262-8ae5-9a6c29baf08d	PRODUCT	1	5.90	5.90	\N	2026-06-13 22:14:27.014	2026-06-13 22:14:27.014	\N	08a75e4b-3bc4-4508-9cfd-b0cc4029f068	\N	\N
e12e1127-b4cb-4772-8978-95337263ec8b	PRODUCT	3	5.90	17.70	\N	2026-06-13 22:14:27.02	2026-06-13 22:14:27.02	\N	1e214c6f-17ca-42c3-85d7-a8ee77ba35e9	\N	\N
f4048dc1-0d73-46d6-adcf-81f4002326a5	PRODUCT	3	5.90	17.70	\N	2026-06-13 22:14:27.029	2026-06-13 22:14:27.029	\N	00042e80-7bc9-4121-a572-67b9ad3baa5d	\N	\N
237f88d5-716b-49bb-89fa-a30f5ea975b9	PRODUCT	3	5.90	17.70	\N	2026-06-13 22:14:27.043	2026-06-13 22:14:27.043	\N	e238966d-679a-4444-8eac-2dc9a7f8c8c9	\N	\N
6a5ee136-d29d-4bf8-9b81-0c3b58963f38	PRODUCT	2	5.90	11.80	\N	2026-06-13 22:14:27.053	2026-06-13 22:14:27.053	\N	05bc22a7-8985-47cb-a91f-cc524befd509	\N	\N
22daf6a4-048a-4e4b-8d4b-1cf2ef54162a	PRODUCT	2	5.90	11.80	\N	2026-06-13 22:14:27.069	2026-06-13 22:14:27.069	\N	2e9a683b-e430-4c16-9484-87e150759872	\N	\N
143d6a8d-511b-4204-a33e-eabe0e04f3cd	PRODUCT	3	5.90	17.70	\N	2026-06-13 22:14:27.079	2026-06-13 22:14:27.079	\N	454fecfa-821e-4514-9624-8cfd253a65c8	\N	\N
1cc11438-8450-4a7f-ade5-ffefa204e509	PRODUCT	1	5.90	5.90	\N	2026-06-13 22:14:27.128	2026-06-13 22:14:27.128	\N	76a94256-0a3b-425c-b9f6-0eea171f9b11	\N	\N
08f93fc1-9826-4e62-a9f7-f59f95908d37	PRODUCT	2	5.90	11.80	\N	2026-06-13 22:14:27.135	2026-06-13 22:14:27.135	\N	e0b08d45-f795-4e0d-9caa-e55b48c63cba	\N	\N
73d73b86-60ac-4a6c-a92c-806e3bb3d408	PRODUCT	3	5.90	17.70	\N	2026-06-13 22:14:27.144	2026-06-13 22:14:27.144	\N	9163d666-8040-4e31-900a-1018ca51a16f	\N	\N
429645e4-7d74-485b-af9e-33dfb7e68362	PRODUCT	1	5.90	5.90	\N	2026-06-13 22:14:27.169	2026-06-13 22:14:27.169	\N	f44826ad-ec06-4446-8e5a-38324e4aa03f	\N	\N
e9ddd3f4-6027-43ea-a205-c610a6b94498	PRODUCT	3	5.90	17.70	\N	2026-06-13 22:14:27.175	2026-06-13 22:14:27.175	\N	ddf78a45-b2cb-4a9a-aa11-83a43a0c2863	\N	\N
56ab64a3-2415-4163-8b34-7ac8fb0e8790	PRODUCT	1	5.90	5.90	\N	2026-06-13 22:14:27.18	2026-06-13 22:14:27.18	\N	a576d931-0638-4db0-908e-cec770085c22	\N	\N
b2c3206b-000b-4a5f-9210-f28d5329325a	PRODUCT	1	9.80	9.80	\N	2026-06-13 22:14:27.06	2026-06-13 22:14:27.06	\N	6f424adf-6452-47d6-a785-c45513ec87f6	\N	\N
559a6243-ac16-4c04-8dc8-e947fc7f826a	PRODUCT	2	9.80	19.60	\N	2026-06-13 22:14:27.069	2026-06-13 22:14:27.069	\N	2e9a683b-e430-4c16-9484-87e150759872	\N	\N
ff1d6823-48e0-4ec6-acef-80110b4a77d5	PRODUCT	3	9.80	29.40	\N	2026-06-13 22:14:27.073	2026-06-13 22:14:27.073	\N	a2766dbb-05c9-4331-b6a4-654df52722ce	\N	\N
b44984ff-1327-4731-a216-d924630ada12	PRODUCT	3	9.80	29.40	\N	2026-06-13 22:14:27.086	2026-06-13 22:14:27.086	\N	0f876b0c-57b2-4b5f-9efd-7dc4372fc4d2	\N	\N
3557135c-4200-4c90-a5e8-57b86bd9c042	PRODUCT	2	9.80	19.60	\N	2026-06-13 22:14:27.111	2026-06-13 22:14:27.111	\N	8b069aac-8de9-4bbb-ae4e-5779ec490336	\N	\N
fc9c38a1-b9b7-486f-905d-bbd27cf83454	PRODUCT	2	9.80	19.60	\N	2026-06-13 22:14:27.121	2026-06-13 22:14:27.121	\N	f2f83167-4df7-494a-8b04-65bb19e082eb	\N	\N
52543839-6d64-4f28-933d-1155fd1fe9df	PRODUCT	3	9.80	29.40	\N	2026-06-13 22:14:27.124	2026-06-13 22:14:27.124	\N	06e36b6c-8c2a-4841-90ae-74a94c95c567	\N	\N
5f1d4137-e7a3-49c2-992a-4ac6811367d1	PRODUCT	3	9.80	29.40	\N	2026-06-13 22:14:27.159	2026-06-13 22:14:27.159	\N	59204620-60da-4553-9e68-a82cc895eb66	\N	\N
c5057d04-f85e-4890-b75b-9e6bafa59be0	PRODUCT	3	9.80	29.40	\N	2026-06-13 22:14:27.198	2026-06-13 22:14:27.198	\N	3487bb77-b199-4808-b8a0-81131bf74088	\N	\N
1235472d-d09f-4f62-89d6-70d163470ca8	PRODUCT	1	8.50	8.50	\N	2026-06-13 22:14:27.051	2026-06-13 22:14:27.051	\N	05bc22a7-8985-47cb-a91f-cc524befd509	\N	\N
84c1ad30-24c0-4fc8-b9d0-b7732a0c50e6	PRODUCT	3	8.50	25.50	\N	2026-06-13 22:14:27.06	2026-06-13 22:14:27.06	\N	6f424adf-6452-47d6-a785-c45513ec87f6	\N	\N
453fe908-0b06-4d12-a659-21a376114385	PRODUCT	3	8.50	25.50	\N	2026-06-13 22:14:27.079	2026-06-13 22:14:27.079	\N	454fecfa-821e-4514-9624-8cfd253a65c8	\N	\N
ae1678e9-208f-475b-bba3-b384b524f5d3	PRODUCT	2	8.50	17.00	\N	2026-06-13 22:14:27.09	2026-06-13 22:14:27.09	\N	06869d50-5db1-47dd-a6ed-c1ac547cf406	\N	\N
bdf9e747-cbe2-49f8-ab67-747f7602c960	PRODUCT	3	8.50	25.50	\N	2026-06-13 22:14:27.103	2026-06-13 22:14:27.103	\N	169803fd-b86f-4b4a-8331-f1d979669aa7	\N	\N
57d63acf-20a8-4ad9-afd4-c7b90d358dec	PRODUCT	3	8.50	25.50	\N	2026-06-13 22:14:27.15	2026-06-13 22:14:27.15	\N	c9e47afe-9174-414d-91f1-7d383cea9764	\N	\N
075e54d0-efb0-4134-824a-f3460b03620b	PRODUCT	1	8.50	8.50	\N	2026-06-13 22:14:27.155	2026-06-13 22:14:27.155	\N	5a03fadc-3003-4dd1-a33b-077f76dee964	\N	\N
3fa4d6a5-e1c9-487a-a35b-3e7c92b25532	PRODUCT	2	8.50	17.00	\N	2026-06-13 22:14:27.213	2026-06-13 22:14:27.213	\N	486d76eb-4487-4e0b-a1a3-77e1636a8955	\N	\N
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.orders (id, "orderCode", status, "paymentMethod", "paymentStatus", "totalAmount", "shippingAmount", "taxAmount", "shippingAddress", "billingAddress", notes, "discountCode", "discountAmount", "createdAt", "updatedAt", "deletedAt", "billedAt", "customerId", "workspaceId", "trackingNumber", "invoiceUrl", "invoiceKey", "invoiceDate") FROM stdin;
08a75e4b-3bc4-4508-9cfd-b0cc4029f068	ORD-001-2025-4	DELIVERED	\N	PENDING	28.40	0.00	0.00	\N	\N	\N	\N	0.00	2025-04-04 22:00:00	2026-06-13 22:14:27.013	\N	\N	e47d0970-59a7-4c6e-bf3d-abae59964db0	bellitalia-vip-ecommerce	\N	\N	\N	\N
1e214c6f-17ca-42c3-85d7-a8ee77ba35e9	ORD-002-2025-4	DELIVERED	\N	PENDING	55.60	0.00	0.00	\N	\N	\N	\N	0.00	2025-04-07 22:00:00	2026-06-13 22:14:27.018	\N	\N	768079dc-ade2-47c9-ae94-fa839d96b5dc	bellitalia-vip-ecommerce	\N	\N	\N	\N
7e254f5c-14ff-4f25-a04b-57af5ed851e6	ORD-003-2025-4	DELIVERED	\N	PENDING	50.00	0.00	0.00	\N	\N	\N	\N	0.00	2025-04-11 22:00:00	2026-06-13 22:14:27.025	\N	\N	1b70a5b5-7d8f-4b7f-a25f-13406c6d2b4c	bellitalia-vip-ecommerce	\N	\N	\N	\N
00042e80-7bc9-4121-a572-67b9ad3baa5d	ORD-004-2025-4	CONFIRMED	\N	PENDING	17.70	0.00	0.00	\N	\N	\N	\N	0.00	2025-04-14 22:00:00	2026-06-13 22:14:27.028	\N	\N	2766c7a0-c110-4405-a1bb-3904e3b822bb	bellitalia-vip-ecommerce	\N	\N	\N	\N
3fe399e4-4c79-4f9a-8671-d16f235ca321	ORD-005-2025-4	CONFIRMED	\N	PENDING	37.40	0.00	0.00	\N	\N	\N	\N	0.00	2025-04-17 22:00:00	2026-06-13 22:14:27.032	\N	\N	6fc43406-b2ef-48ba-a1dd-3171316d3cf3	bellitalia-vip-ecommerce	\N	\N	\N	\N
db0ca7bb-fc53-406b-816f-a141866201e0	ORD-006-2025-4	CONFIRMED	\N	PENDING	22.50	0.00	0.00	\N	\N	\N	\N	0.00	2025-04-21 22:00:00	2026-06-13 22:14:27.036	\N	\N	e47d0970-59a7-4c6e-bf3d-abae59964db0	bellitalia-vip-ecommerce	\N	\N	\N	\N
27e64599-9b3d-4780-841b-62436c766102	ORD-007-2025-4	DELIVERED	\N	PENDING	18.80	0.00	0.00	\N	\N	\N	\N	0.00	2025-04-24 22:00:00	2026-06-13 22:14:27.038	\N	\N	768079dc-ade2-47c9-ae94-fa839d96b5dc	bellitalia-vip-ecommerce	\N	\N	\N	\N
e238966d-679a-4444-8eac-2dc9a7f8c8c9	ORD-008-2025-4	DELIVERED	\N	PENDING	27.20	0.00	0.00	\N	\N	\N	\N	0.00	2025-04-27 22:00:00	2026-06-13 22:14:27.042	\N	\N	1b70a5b5-7d8f-4b7f-a25f-13406c6d2b4c	bellitalia-vip-ecommerce	\N	\N	\N	\N
840444f3-593e-495f-b634-076c9635b0ba	ORD-009-2025-5	CONFIRMED	\N	PENDING	69.10	0.00	0.00	\N	\N	\N	\N	0.00	2025-05-02 22:00:00	2026-06-13 22:14:27.046	\N	\N	2766c7a0-c110-4405-a1bb-3904e3b822bb	bellitalia-vip-ecommerce	\N	\N	\N	\N
05bc22a7-8985-47cb-a91f-cc524befd509	ORD-010-2025-5	DELIVERED	\N	PENDING	38.90	0.00	0.00	\N	\N	\N	\N	0.00	2025-05-06 22:00:00	2026-06-13 22:14:27.051	\N	\N	6fc43406-b2ef-48ba-a1dd-3171316d3cf3	bellitalia-vip-ecommerce	\N	\N	\N	\N
b015e2d4-3732-464a-80c3-110b64c1ba36	ORD-011-2025-5	DELIVERED	\N	PENDING	29.00	0.00	0.00	\N	\N	\N	\N	0.00	2025-05-10 22:00:00	2026-06-13 22:14:27.054	\N	\N	e47d0970-59a7-4c6e-bf3d-abae59964db0	bellitalia-vip-ecommerce	\N	\N	\N	\N
6f424adf-6452-47d6-a785-c45513ec87f6	ORD-012-2025-5	DELIVERED	\N	PENDING	41.50	0.00	0.00	\N	\N	\N	\N	0.00	2025-05-13 22:00:00	2026-06-13 22:14:27.058	\N	\N	768079dc-ade2-47c9-ae94-fa839d96b5dc	bellitalia-vip-ecommerce	\N	\N	\N	\N
f0619d2d-aea2-4b39-8e49-2d8ce45b9218	ORD-013-2025-5	DELIVERED	\N	PENDING	28.50	0.00	0.00	\N	\N	\N	\N	0.00	2025-05-18 22:00:00	2026-06-13 22:14:27.062	\N	\N	1b70a5b5-7d8f-4b7f-a25f-13406c6d2b4c	bellitalia-vip-ecommerce	\N	\N	\N	\N
72cfa127-0f5f-4e64-aa4e-b96f93a761ff	ORD-014-2025-5	DELIVERED	\N	PENDING	52.30	0.00	0.00	\N	\N	\N	\N	0.00	2025-05-22 22:00:00	2026-06-13 22:14:27.065	\N	\N	2766c7a0-c110-4405-a1bb-3904e3b822bb	bellitalia-vip-ecommerce	\N	\N	\N	\N
2e9a683b-e430-4c16-9484-87e150759872	ORD-015-2025-5	CONFIRMED	\N	PENDING	31.40	0.00	0.00	\N	\N	\N	\N	0.00	2025-05-25 22:00:00	2026-06-13 22:14:27.068	\N	\N	6fc43406-b2ef-48ba-a1dd-3171316d3cf3	bellitalia-vip-ecommerce	\N	\N	\N	\N
a2766dbb-05c9-4331-b6a4-654df52722ce	ORD-016-2025-5	DELIVERED	\N	PENDING	47.20	0.00	0.00	\N	\N	\N	\N	0.00	2025-05-29 22:00:00	2026-06-13 22:14:27.072	\N	\N	e47d0970-59a7-4c6e-bf3d-abae59964db0	bellitalia-vip-ecommerce	\N	\N	\N	\N
6c6cb125-d775-49eb-a021-d517fb37f27d	ORD-017-2025-6	DELIVERED	\N	PENDING	37.00	0.00	0.00	\N	\N	\N	\N	0.00	2025-06-01 22:00:00	2026-06-13 22:14:27.075	\N	\N	768079dc-ade2-47c9-ae94-fa839d96b5dc	bellitalia-vip-ecommerce	\N	\N	\N	\N
454fecfa-821e-4514-9624-8cfd253a65c8	ORD-018-2025-6	DELIVERED	\N	PENDING	43.20	0.00	0.00	\N	\N	\N	\N	0.00	2025-06-05 22:00:00	2026-06-13 22:14:27.078	\N	\N	1b70a5b5-7d8f-4b7f-a25f-13406c6d2b4c	bellitalia-vip-ecommerce	\N	\N	\N	\N
72c5bc18-cc29-47a9-a8cd-d260f2988812	ORD-019-2025-6	DELIVERED	\N	PENDING	69.10	0.00	0.00	\N	\N	\N	\N	0.00	2025-06-09 22:00:00	2026-06-13 22:14:27.082	\N	\N	2766c7a0-c110-4405-a1bb-3904e3b822bb	bellitalia-vip-ecommerce	\N	\N	\N	\N
0f876b0c-57b2-4b5f-9efd-7dc4372fc4d2	ORD-020-2025-6	DELIVERED	\N	PENDING	51.90	0.00	0.00	\N	\N	\N	\N	0.00	2025-06-12 22:00:00	2026-06-13 22:14:27.086	\N	\N	6fc43406-b2ef-48ba-a1dd-3171316d3cf3	bellitalia-vip-ecommerce	\N	\N	\N	\N
06869d50-5db1-47dd-a6ed-c1ac547cf406	ORD-021-2025-6	CONFIRMED	\N	PENDING	42.60	0.00	0.00	\N	\N	\N	\N	0.00	2025-06-16 22:00:00	2026-06-13 22:14:27.089	\N	\N	e47d0970-59a7-4c6e-bf3d-abae59964db0	bellitalia-vip-ecommerce	\N	\N	\N	\N
c7d5eb44-06f7-4686-b78c-f6c3430deb70	ORD-022-2025-6	DELIVERED	\N	PENDING	48.00	0.00	0.00	\N	\N	\N	\N	0.00	2025-06-20 22:00:00	2026-06-13 22:14:27.092	\N	\N	768079dc-ade2-47c9-ae94-fa839d96b5dc	bellitalia-vip-ecommerce	\N	\N	\N	\N
5af2e857-c3ce-492c-8b05-28ba4881bf53	ORD-023-2025-6	DELIVERED	\N	PENDING	37.30	0.00	0.00	\N	\N	\N	\N	0.00	2025-06-23 22:00:00	2026-06-13 22:14:27.096	\N	\N	1b70a5b5-7d8f-4b7f-a25f-13406c6d2b4c	bellitalia-vip-ecommerce	\N	\N	\N	\N
7a65a86e-d5fa-466d-af78-c6517d1ef2b0	ORD-024-2025-6	CONFIRMED	\N	PENDING	17.80	0.00	0.00	\N	\N	\N	\N	0.00	2025-06-27 22:00:00	2026-06-13 22:14:27.1	\N	\N	2766c7a0-c110-4405-a1bb-3904e3b822bb	bellitalia-vip-ecommerce	\N	\N	\N	\N
169803fd-b86f-4b4a-8331-f1d979669aa7	ORD-025-2025-7	CONFIRMED	\N	PENDING	54.50	0.00	0.00	\N	\N	\N	\N	0.00	2025-06-30 22:00:00	2026-06-13 22:14:27.102	\N	\N	6fc43406-b2ef-48ba-a1dd-3171316d3cf3	bellitalia-vip-ecommerce	\N	\N	\N	\N
1649792d-8ab0-4328-8dfa-1d7f75179eff	ORD-026-2025-7	DELIVERED	\N	PENDING	26.70	0.00	0.00	\N	\N	\N	\N	0.00	2025-07-04 22:00:00	2026-06-13 22:14:27.105	\N	\N	e47d0970-59a7-4c6e-bf3d-abae59964db0	bellitalia-vip-ecommerce	\N	\N	\N	\N
76992287-6f5a-41dc-80fc-ee609d14c9c9	ORD-027-2025-7	DELIVERED	\N	PENDING	25.60	0.00	0.00	\N	\N	\N	\N	0.00	2025-07-08 22:00:00	2026-06-13 22:14:27.107	\N	\N	768079dc-ade2-47c9-ae94-fa839d96b5dc	bellitalia-vip-ecommerce	\N	\N	\N	\N
8b069aac-8de9-4bbb-ae4e-5779ec490336	ORD-028-2025-7	DELIVERED	\N	PENDING	101.50	0.00	0.00	\N	\N	\N	\N	0.00	2025-07-11 22:00:00	2026-06-13 22:14:27.11	\N	\N	1b70a5b5-7d8f-4b7f-a25f-13406c6d2b4c	bellitalia-vip-ecommerce	\N	\N	\N	\N
fe89c65e-5728-4148-9ad5-aff02d90d343	ORD-029-2025-7	CONFIRMED	\N	PENDING	43.50	0.00	0.00	\N	\N	\N	\N	0.00	2025-07-15 22:00:00	2026-06-13 22:14:27.114	\N	\N	2766c7a0-c110-4405-a1bb-3904e3b822bb	bellitalia-vip-ecommerce	\N	\N	\N	\N
77b074a0-63d4-4309-9a5b-a4f53442e9bd	ORD-030-2025-7	DELIVERED	\N	PENDING	19.00	0.00	0.00	\N	\N	\N	\N	0.00	2025-07-19 22:00:00	2026-06-13 22:14:27.117	\N	\N	6fc43406-b2ef-48ba-a1dd-3171316d3cf3	bellitalia-vip-ecommerce	\N	\N	\N	\N
f2f83167-4df7-494a-8b04-65bb19e082eb	ORD-031-2025-7	CONFIRMED	\N	PENDING	28.00	0.00	0.00	\N	\N	\N	\N	0.00	2025-07-22 22:00:00	2026-06-13 22:14:27.12	\N	\N	e47d0970-59a7-4c6e-bf3d-abae59964db0	bellitalia-vip-ecommerce	\N	\N	\N	\N
06e36b6c-8c2a-4841-90ae-74a94c95c567	ORD-032-2025-7	CONFIRMED	\N	PENDING	47.20	0.00	0.00	\N	\N	\N	\N	0.00	2025-07-26 22:00:00	2026-06-13 22:14:27.123	\N	\N	768079dc-ade2-47c9-ae94-fa839d96b5dc	bellitalia-vip-ecommerce	\N	\N	\N	\N
76a94256-0a3b-425c-b9f6-0eea171f9b11	ORD-033-2025-8	CONFIRMED	\N	PENDING	53.90	0.00	0.00	\N	\N	\N	\N	0.00	2025-08-03 22:00:00	2026-06-13 22:14:27.127	\N	\N	1b70a5b5-7d8f-4b7f-a25f-13406c6d2b4c	bellitalia-vip-ecommerce	\N	\N	\N	\N
1865fd78-b4ca-40eb-acb5-e48d8c975ad4	ORD-034-2025-8	CONFIRMED	\N	PENDING	4.20	0.00	0.00	\N	\N	\N	\N	0.00	2025-08-07 22:00:00	2026-06-13 22:14:27.131	\N	\N	2766c7a0-c110-4405-a1bb-3904e3b822bb	bellitalia-vip-ecommerce	\N	\N	\N	\N
e0b08d45-f795-4e0d-9caa-e55b48c63cba	ORD-035-2025-8	DELIVERED	\N	PENDING	76.90	0.00	0.00	\N	\N	\N	\N	0.00	2025-08-10 22:00:00	2026-06-13 22:14:27.134	\N	\N	6fc43406-b2ef-48ba-a1dd-3171316d3cf3	bellitalia-vip-ecommerce	\N	\N	\N	\N
5aab94fb-6dd0-435e-a885-23e0ae964b36	ORD-036-2025-8	DELIVERED	\N	PENDING	58.00	0.00	0.00	\N	\N	\N	\N	0.00	2025-08-14 22:00:00	2026-06-13 22:14:27.138	\N	\N	e47d0970-59a7-4c6e-bf3d-abae59964db0	bellitalia-vip-ecommerce	\N	\N	\N	\N
9163d666-8040-4e31-900a-1018ca51a16f	ORD-037-2025-8	CONFIRMED	\N	PENDING	56.20	0.00	0.00	\N	\N	\N	\N	0.00	2025-08-18 22:00:00	2026-06-13 22:14:27.142	\N	\N	768079dc-ade2-47c9-ae94-fa839d96b5dc	bellitalia-vip-ecommerce	\N	\N	\N	\N
c9e47afe-9174-414d-91f1-7d383cea9764	ORD-038-2025-8	DELIVERED	\N	PENDING	47.50	0.00	0.00	\N	\N	\N	\N	0.00	2025-08-21 22:00:00	2026-06-13 22:14:27.147	\N	\N	1b70a5b5-7d8f-4b7f-a25f-13406c6d2b4c	bellitalia-vip-ecommerce	\N	\N	\N	\N
5a03fadc-3003-4dd1-a33b-077f76dee964	ORD-039-2025-8	CONFIRMED	\N	PENDING	8.50	0.00	0.00	\N	\N	\N	\N	0.00	2025-08-25 22:00:00	2026-06-13 22:14:27.153	\N	\N	2766c7a0-c110-4405-a1bb-3904e3b822bb	bellitalia-vip-ecommerce	\N	\N	\N	\N
59204620-60da-4553-9e68-a82cc895eb66	ORD-040-2025-8	DELIVERED	\N	PENDING	29.40	0.00	0.00	\N	\N	\N	\N	0.00	2025-08-28 22:00:00	2026-06-13 22:14:27.157	\N	\N	6fc43406-b2ef-48ba-a1dd-3171316d3cf3	bellitalia-vip-ecommerce	\N	\N	\N	\N
193b34a5-4f6d-43cd-ba5c-bde95368a9ad	ORD-041-2025-9	DELIVERED	\N	PENDING	4.20	0.00	0.00	\N	\N	\N	\N	0.00	2025-09-01 22:00:00	2026-06-13 22:14:27.161	\N	\N	e47d0970-59a7-4c6e-bf3d-abae59964db0	bellitalia-vip-ecommerce	\N	\N	\N	\N
f44826ad-ec06-4446-8e5a-38324e4aa03f	ORD-042-2025-9	DELIVERED	\N	PENDING	12.10	0.00	0.00	\N	\N	\N	\N	0.00	2025-09-05 22:00:00	2026-06-13 22:14:27.166	\N	\N	768079dc-ade2-47c9-ae94-fa839d96b5dc	bellitalia-vip-ecommerce	\N	\N	\N	\N
ddf78a45-b2cb-4a9a-aa11-83a43a0c2863	ORD-043-2025-9	CONFIRMED	\N	PENDING	56.10	0.00	0.00	\N	\N	\N	\N	0.00	2025-09-09 22:00:00	2026-06-13 22:14:27.172	\N	\N	1b70a5b5-7d8f-4b7f-a25f-13406c6d2b4c	bellitalia-vip-ecommerce	\N	\N	\N	\N
a576d931-0638-4db0-908e-cec770085c22	ORD-044-2025-9	DELIVERED	\N	PENDING	34.40	0.00	0.00	\N	\N	\N	\N	0.00	2025-09-14 22:00:00	2026-06-13 22:14:27.178	\N	\N	2766c7a0-c110-4405-a1bb-3904e3b822bb	bellitalia-vip-ecommerce	\N	\N	\N	\N
5a3935b4-c539-4161-9680-26b99e4ebe59	ORD-045-2025-9	CONFIRMED	\N	PENDING	38.40	0.00	0.00	\N	\N	\N	\N	0.00	2025-09-18 22:00:00	2026-06-13 22:14:27.185	\N	\N	6fc43406-b2ef-48ba-a1dd-3171316d3cf3	bellitalia-vip-ecommerce	\N	\N	\N	\N
3487bb77-b199-4808-b8a0-81131bf74088	ORD-046-2025-9	DELIVERED	\N	PENDING	70.70	0.00	0.00	\N	\N	\N	\N	0.00	2025-09-22 22:00:00	2026-06-13 22:14:27.193	\N	\N	e47d0970-59a7-4c6e-bf3d-abae59964db0	bellitalia-vip-ecommerce	\N	\N	\N	\N
f4bd5fa9-8053-4ef5-82c2-5b4b48644d5c	ORD-047-2025-9	CONFIRMED	\N	PENDING	22.80	0.00	0.00	\N	\N	\N	\N	0.00	2025-09-26 22:00:00	2026-06-13 22:14:27.204	\N	\N	768079dc-ade2-47c9-ae94-fa839d96b5dc	bellitalia-vip-ecommerce	\N	\N	\N	\N
486d76eb-4487-4e0b-a1a3-77e1636a8955	ORD-048-2025-9	DELIVERED	\N	PENDING	23.20	0.00	0.00	\N	\N	\N	\N	0.00	2025-09-29 22:00:00	2026-06-13 22:14:27.21	\N	\N	1b70a5b5-7d8f-4b7f-a25f-13406c6d2b4c	bellitalia-vip-ecommerce	\N	\N	\N	\N
\.


--
-- Data for Name: password_resets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.password_resets (id, "userId", token, "expiresAt", "usedAt", "createdAt") FROM stdin;
\.


--
-- Data for Name: payment_details; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payment_details (id, provider, status, amount, currency, "providerResponse", "createdAt", "updatedAt", "orderId") FROM stdin;
\.


--
-- Data for Name: paypal_transactions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.paypal_transactions (id, "userId", "invoiceId", amount, currency, status, notes, "createdAt", "adminUserId", "paypalOrderId") FROM stdin;
cmqcwxr5k00mjibngqzuoknue	fd566368-a330-47b4-9b11-3e44622cba2e	cmqcwxr4h00m8ibngcupumpgx	49.20	EUR	SUCCESS	Invoice 07/2025 paid	2025-08-01 07:10:00	fd566368-a330-47b4-9b11-3e44622cba2e	\N
cmqcwxr5k00mkibngok5jr4g1	fd566368-a330-47b4-9b11-3e44622cba2e	cmqcwxr4l00m9ibnguquxzf2o	51.40	EUR	SUCCESS	Invoice 08/2025 paid	2025-09-01 07:05:00	fd566368-a330-47b4-9b11-3e44622cba2e	\N
cmqcwxr5k00mlibnglevk5jkp	fd566368-a330-47b4-9b11-3e44622cba2e	cmqcwxr4p00maibng0mfru1sj	50.60	EUR	SUCCESS	Invoice 09/2025 paid	2025-10-01 07:12:00	fd566368-a330-47b4-9b11-3e44622cba2e	\N
cmqcwxr5k00mmibngsouvq534	fd566368-a330-47b4-9b11-3e44622cba2e	cmqcwxr4t00mbibngg8bs0h8q	50.00	EUR	SUCCESS	October invoice paid	2025-11-01 09:05:00	fd566368-a330-47b4-9b11-3e44622cba2e	\N
cmqcwxr5k00mnibngeibm67oc	fd566368-a330-47b4-9b11-3e44622cba2e	cmqcwxr5000mcibngyz5axpt8	48.50	EUR	FAILED	Card declined - retry scheduled	2025-12-01 09:02:00	fd566368-a330-47b4-9b11-3e44622cba2e	\N
cmqcwxr5k00moibngwnmfie4v	fd566368-a330-47b4-9b11-3e44622cba2e	cmqcwxr5000mcibngyz5axpt8	48.50	EUR	SUCCESS	November invoice paid on retry	2025-12-02 08:15:00	fd566368-a330-47b4-9b11-3e44622cba2e	\N
cmqcwxr5k00mpibngfilsq3yh	fd566368-a330-47b4-9b11-3e44622cba2e	cmqcwxr5400mdibngup9y6se1	47.60	EUR	FAILED	Insufficient funds	2025-12-31 17:40:00	fd566368-a330-47b4-9b11-3e44622cba2e	\N
cmqcwxr5k00mqibng7yevho3x	fd566368-a330-47b4-9b11-3e44622cba2e	\N	12.00	EUR	SUCCESS	Manual adjustment	2025-12-20 14:05:00	fd566368-a330-47b4-9b11-3e44622cba2e	\N
\.


--
-- Data for Name: paypal_webhook_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.paypal_webhook_events (id, "eventId", "eventType", "receivedAt") FROM stdin;
\.


--
-- Data for Name: plan_configurations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.plan_configurations (id, "planType", "displayName", "monthlyFee", "maxChannels", "maxProducts", "maxCustomers", max_team_members, "messageCost", "orderCost", "pushCost", "reminderCost", "lowBalanceThreshold", "trialDays", "initialCredit", features, "isActive", "createdAt", "updatedAt") FROM stdin;
cmqcwxqxt00jzibngx3f11xqj	FREE_TRIAL	Free Trial	0.00	1	9999	50	0	0.10	1.00	1.00	0.50	5.00	14	22.00	"[\\"14 giorni di prova gratuita\\",\\"€22 di credito iniziale\\",\\"1 canale WhatsApp\\",\\"50 clienti\\"]"	t	2026-06-13 22:14:27.233	2026-06-13 22:14:27.233
cmqcwxqxv00k0ibng66sxat7d	BASIC	Basic	22.00	1	9999	50	0	0.10	1.00	1.00	0.50	5.00	0	0.00	"[\\"1 canale WhatsApp\\",\\"50 clienti\\",\\"Multi-language support\\",\\"Analytics dashboard\\"]"	t	2026-06-13 22:14:27.235	2026-06-13 22:14:27.235
cmqcwxqxx00k1ibngdni95i7k	PREMIUM	Premium	45.00	2	9999	100	3	0.10	1.00	1.00	0.50	5.00	0	0.00	"[\\"2 canali WhatsApp\\",\\"100 clienti\\",\\"Multi-language support\\",\\"Analytics avanzati\\",\\"Brand customization\\",\\"Priority support\\",\\"Team members illimitati\\"]"	t	2026-06-13 22:14:27.237	2026-06-13 22:14:27.237
cmqcwxqxy00k2ibng6qu0gwhr	ENTERPRISE	Enterprise	160.00	999	9999	9999	\N	0.10	1.00	1.00	0.50	10.00	0	0.00	"[\\"Canali illimitati\\",\\"Clienti illimitati\\",\\"Sconti volume sui costi\\",\\"Server dedicato\\",\\"CRM integrato\\",\\"Support 24/7\\",\\"Account manager dedicato\\",\\"Team members illimitati\\"]"	t	2026-06-13 22:14:27.238	2026-06-13 22:14:27.238
\.


--
-- Data for Name: platform_config; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.platform_config (id, type, key, value, "originalValue", description, "isActive", "createdAt", "updatedAt") FROM stdin;
cmqcwxqg30036ibngn07i8fjy	PRICE	FREE_MONTHLY	0	\N	Free plan - $0/month for 14 days trial with $22 credit included	t	2026-06-13 22:14:26.595	2026-06-13 22:14:26.595
cmqcwxqg50037ibngez1ff2if	PRICE	BASIC_MONTHLY	22	34	Basic plan - $22/month for growing businesses (was $34)	t	2026-06-13 22:14:26.597	2026-06-13 22:14:26.597
cmqcwxqg70038ibngqevv3glr	PRICE	PREMIUM_MONTHLY	45	58	Premium plan - $45/month for established businesses (was $58)	t	2026-06-13 22:14:26.599	2026-06-13 22:14:26.599
cmqcwxqg90039ibng4s1xarc7	PRICE	ENTERPRISE_MONTHLY	160	175	Enterprise plan - $160/month for large scale operations (was $175)	t	2026-06-13 22:14:26.601	2026-06-13 22:14:26.601
cmqcwxqgb003aibngcobhrskm	PRICE	MESSAGE	0.10	\N	Cost per message (AI-powered responses, including support conversations)	t	2026-06-13 22:14:26.603	2026-06-13 22:14:26.603
cmqcwxqgd003bibngcyw65tmb	PRICE	WIDGET_MESSAGE	0.005	\N	Cost per web widget message (site chat)	t	2026-06-13 22:14:26.605	2026-06-13 22:14:26.605
cmqcwxqge003cibngpbqpbxfa	PRICE	PUSH_CAMPAIGN	1.00	\N	Cost per push notification sent (all types)	t	2026-06-13 22:14:26.606	2026-06-13 22:14:26.606
cmqcwxqgg003dibng8i8qvjao	PRICE	APPOINTMENT_REMINDER_WHATSAPP	0.50	\N	Cost per WhatsApp appointment reminder (24h, 1h, or 30min before appointment)	t	2026-06-13 22:14:26.608	2026-06-13 22:14:26.608
cmqcwxqgh003eibngzm075pyk	FLAG	canLogin	true	\N	Allow user login. When false: show maintenance mode	t	2026-06-13 22:14:26.609	2026-06-13 22:14:26.609
cmqcwxqgj003fibngvn7divhn	FLAG	canRegister	true	\N	Allow new user registration. When false: show WIP popup, disable register button	t	2026-06-13 22:14:26.611	2026-06-13 22:14:26.611
cmqcwxqgl003gibng3176wj0t	FLAG	workingInProgress	false	\N	Show Work in Progress badge to communicate service status	t	2026-06-13 22:14:26.613	2026-06-13 22:14:26.613
cmqcwxqgm003hibngx56o5ed1	FLAG	registerFirst	false	\N	When true, default auth view is registration instead of login	t	2026-06-13 22:14:26.614	2026-06-13 22:14:26.614
cmqcwxqgn003iibngtywnf06u	FLAG	landingPageEnabled	true	\N	When true, /index redirects to landing page. When false, redirect users to /auth/login	t	2026-06-13 22:14:26.615	2026-06-13 22:14:26.615
cmqcwxqgp003jibng61a7haqi	FLAG	cantryDemo	true	\N	Allow users to try live demo. When false: show WIP popup, disable demo button	t	2026-06-13 22:14:26.617	2026-06-13 22:14:26.617
cmqcwxqgq003kibngcdinse9c	FLAG	showWidgetChatbot	true	\N	Show chatbot widget on login page. When true: display the widget embed code	t	2026-06-13 22:14:26.618	2026-06-13 22:14:26.618
cmqcwxqgr003libngorv4sb81	FLAG	widgetChatbotCode	<!-- eChatbot Widget -->\n<script>\n  window.eChatbotConfig = {\n    "workspaceId": "echatbot-hq-support",\n    "apiUrl": "https://echatbot-app-1cba28556df2.herokuapp.com/api/v1",\n    "title": "Chat with us",\n    "language": "it",\n    "primaryColor": "#22c55e"\n  };\n</script>\n<script src="https://www.echatbot.ai/widget.js" async></script>	\N	Widget chatbot embed code for login page (HTML/JS snippet)	t	2026-06-13 22:14:26.619	2026-06-13 22:14:26.619
cmqcwxqgt003mibng8gz0aeyw	LIMIT	FREE_CLIENTS	50	\N	Maximum clients for Free plan	t	2026-06-13 22:14:26.621	2026-06-13 22:14:26.621
cmqcwxqgu003nibngf4biktgu	LIMIT	BASIC_CLIENTS	50	\N	Maximum clients for Basic plan	t	2026-06-13 22:14:26.622	2026-06-13 22:14:26.622
cmqcwxqgv003oibngr6m6t6j9	LIMIT	PREMIUM_CLIENTS	100	\N	Maximum clients for Premium plan	t	2026-06-13 22:14:26.623	2026-06-13 22:14:26.623
cmqcwxqgw003pibng1rvrv625	LIMIT	WHATSAPP_RATE_LIMIT_CUSTOMER_PER_MIN	15	\N	Max inbound WhatsApp messages per CUSTOMER per minute (refill rate)	t	2026-06-13 22:14:26.624	2026-06-13 22:14:26.624
cmqcwxqgy003qibngw1j7usak	LIMIT	WHATSAPP_RATE_LIMIT_CUSTOMER_BURST	10	\N	Extra burst tokens for CUSTOMER inbound WhatsApp messages	t	2026-06-13 22:14:26.626	2026-06-13 22:14:26.626
cmqcwxqh0003ribngvwwtpjmf	LIMIT	WHATSAPP_RATE_LIMIT_WORKSPACE_PER_MIN	300	\N	Max inbound WhatsApp messages per WORKSPACE per minute (refill rate)	t	2026-06-13 22:14:26.628	2026-06-13 22:14:26.628
cmqcwxqh1003sibngj2yoyhbd	LIMIT	WHATSAPP_RATE_LIMIT_WORKSPACE_BURST	150	\N	Extra burst tokens for WORKSPACE inbound WhatsApp messages	t	2026-06-13 22:14:26.629	2026-06-13 22:14:26.629
cmqcwxqh3003tibnghjsm0ate	LIMIT	WHATSAPP_RATE_LIMIT_IP_PER_MIN	600	\N	Max inbound WhatsApp requests per IP per minute (edge protection)	t	2026-06-13 22:14:26.631	2026-06-13 22:14:26.631
cmqcwxqh4003uibngpjdfy0we	LIMIT	WHATSAPP_RATE_LIMIT_IP_BURST	300	\N	Extra burst tokens for inbound WhatsApp requests per IP	t	2026-06-13 22:14:26.632	2026-06-13 22:14:26.632
cmqcwxqh6003vibngx195wzoz	LIMIT	ENTERPRISE_CLIENTS	999999	\N	Unlimited clients for Enterprise plan	t	2026-06-13 22:14:26.634	2026-06-13 22:14:26.634
cmqcwxqh8003wibng51dh6ju5	LIMIT	FREE_CHANNELS	1	\N	Maximum WhatsApp channels for Free plan	t	2026-06-13 22:14:26.636	2026-06-13 22:14:26.636
cmqcwxqh9003xibngbrxm4bw5	LIMIT	BASIC_CHANNELS	1	\N	Maximum WhatsApp channels for Basic plan	t	2026-06-13 22:14:26.637	2026-06-13 22:14:26.637
cmqcwxqhb003yibngi1ngksyo	LIMIT	PREMIUM_CHANNELS	2	\N	Maximum WhatsApp channels for Premium plan	t	2026-06-13 22:14:26.639	2026-06-13 22:14:26.639
cmqcwxqhc003zibng3e6t043l	LIMIT	ENTERPRISE_CHANNELS	999999	\N	Unlimited WhatsApp channels for Enterprise plan	t	2026-06-13 22:14:26.64	2026-06-13 22:14:26.64
cmqcwxqhe0040ibnghzx4qhj0	LIMIT	FREE_TEAM_MEMBERS	0	\N	Maximum team members for Free plan	t	2026-06-13 22:14:26.642	2026-06-13 22:14:26.642
cmqcwxqhf0041ibngknfkp5iw	LIMIT	BASIC_TEAM_MEMBERS	0	\N	Maximum team members for Basic plan	t	2026-06-13 22:14:26.643	2026-06-13 22:14:26.643
cmqcwxqhg0042ibngyf33shi6	LIMIT	PREMIUM_TEAM_MEMBERS	3	\N	Maximum team members for Premium plan	t	2026-06-13 22:14:26.644	2026-06-13 22:14:26.644
cmqcwxqhi0043ibng19i0s082	LIMIT	ENTERPRISE_TEAM_MEMBERS	999999	\N	Unlimited team members for Enterprise plan	t	2026-06-13 22:14:26.646	2026-06-13 22:14:26.646
cmqcwxqhj0044ibng51vs8vmk	LIMIT	PUSH_THROTTLE_PER_SEC	10	\N	Default throttle for push campaigns (messages per second)	t	2026-06-13 22:14:26.647	2026-06-13 22:14:26.647
cmqcwxqhl0045ibngs0qp5wyo	LIMIT	PUSH_BATCH_SIZE	50	\N	Default batch size for push campaigns	t	2026-06-13 22:14:26.649	2026-06-13 22:14:26.649
219bd065-df33-49a8-a81c-cda72bb68fce	LIMIT	TRIAL_WARNING_DAYS	3	\N	Days before trialEndsAt when the owner is warned by email that the free trial is ending (daily trial-expiry job)	t	2026-09-14 13:21:49.23	2026-09-14 13:21:49.23
\.


--
-- Data for Name: playground_comments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.playground_comments (id, "todoId", "commentText", "createdBy", color, "createdAt", "authorKind") FROM stdin;
\.


--
-- Data for Name: playground_todos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.playground_todos (id, "workspaceId", "dialogId", "messageType", "messageContent", "chatbotResponse", "commentTitle", priority, status, "position", "createdBy", "createdAt", "updatedAt", "authorKind") FROM stdin;
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.products (id, name, sku, description, formato, price, stock, "createdAt", "updatedAt", "isActive", "workspaceId", slug, link, status, "imageUrl", "imageKey", type, region, allergens) FROM stdin;
\.


--
-- Data for Name: push_campaign_recipients; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.push_campaign_recipients (id, "campaignId", "workspaceId", "customerId", phone, status, "errorCode", "errorMessage", "sentAt", "messageId", "priceCharged", "isBlacklisted", "isBlocked", "isFake", "optOutAt", "createdAt", "updatedAt", "stayKey") FROM stdin;
\.


--
-- Data for Name: push_campaigns; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.push_campaigns (id, "workspaceId", "createdByUserId", name, status, channel, frequency, "isActive", "targetingType", "targetCustomerIds", "tagId", message, "sendAt", "nextRunAt", "lastRunAt", "templateId", "templateLocale", "bodyPreview", "targetTags", "mediaUrl", "expectedRecipients", "actualSent", "actualFailed", "actualSkipped", "costPerMessage", "billingStatus", "throttlePerSecond", "batchSize", "lastError", metadata, "createdAt", "updatedAt", "merchantId", "merchantPushId", "validFrom", "validTo", "sendWindowStart", "sendWindowEnd", "mediaBase64", "isSystem", "stayEndSendHour", "stayEndDelayDays") FROM stdin;
cmqcwxqpe005tibng2o6o1k4g	bellitalia-vip-ecommerce	\N	Richiesta Feedback Trimestrale	DRAFT	WHATSAPP	ONCE	t	ALL	{}	\N	Ciao {{nome}}! 👋\n\nCi piacerebbe sapere cosa pensi dei nostri prodotti. [FEEDBACK]\n\nGrazie per il tuo tempo! 🙏	\N	\N	2025-10-20 08:00:00.03	\N	\N	Ciao {{nome}}! 👋\n\nCi piacerebbe sapere cosa pensi dei nostri prodotti. [FEEDBACK]\n\nGrazie per il tuo tempo! 🙏	{}	\N	0	0	0	0	1.00	PENDING	10	50	\N	\N	2026-06-13 22:14:26.93	2026-06-13 22:14:26.93	\N	\N	\N	\N	8	19	\N	f	10	1
\.


--
-- Data for Name: registration_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.registration_tokens (id, token, "phoneNumber", "workspaceId", "expiresAt", "usedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: reminder_locks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.reminder_locks (id, "workspaceId", "appointmentId", "googleEventId", "reminderType", "lockKey", "sentAt", "expiresAt") FROM stdin;
\.


--
-- Data for Name: sales; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sales (id, "firstName", "lastName", email, phone, "createdAt", "updatedAt", "isActive", "workspaceId") FROM stdin;
be9f5a8f-8469-46b0-863c-76c5bd6a3036	Alessandro	Romano	gelsogrove@gmail.com	+39 333 890 1234	2026-06-13 22:14:26.931	2026-06-13 22:14:26.931	t	bellitalia-vip-ecommerce
54426f86-3e59-42d3-908f-5d0d2dc8d42c	Marco	Bianchi	marco.bianchi@altrogusto.com	+393331234567	2026-06-13 22:14:26.932	2026-06-13 22:14:26.932	t	bellitalia-vip-ecommerce
27c2a0d8-563a-4878-9657-eeb7f50a9b85	Laura	Conti	laura.conti@altrogusto.com	+393337654321	2026-06-13 22:14:26.933	2026-06-13 22:14:26.933	t	bellitalia-vip-ecommerce
a749bee2-de90-415c-aa14-51c7138db11c	Giuseppe	Ferretti	giuseppe.ferretti@altrogusto.com	+393339876543	2026-06-13 22:14:26.933	2026-06-13 22:14:26.933	t	bellitalia-vip-ecommerce
7f5aa6d0-b3aa-4d47-a961-65980b7a95af	Francesca	Moretti	francesca.moretti@altrogusto.com	+393334567890	2026-06-13 22:14:26.934	2026-06-13 22:14:26.934	t	bellitalia-vip-ecommerce
\.


--
-- Data for Name: scheduler_job_status; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.scheduler_job_status (id, "jobName", "isActive", "lastRunAt", "lastStatus", "lastError", "lastDuration", "nextRunAt", "createdAt", "updatedAt") FROM stdin;
cmqcwxr5n00mribng49b3cb0g	whatsapp-channel-queue	t	\N	NEVER_RUN	\N	\N	\N	2026-06-13 22:14:27.514	2026-06-13 22:14:27.514
cmqcwxr5q00msibngj1dwoiw4	short-urls-cleanup	t	\N	NEVER_RUN	\N	\N	\N	2026-06-13 22:14:27.517	2026-06-13 22:14:27.517
cmqcwxr5s00mtibngncuu7t59	unused-images-cleanup	f	\N	NEVER_RUN	\N	\N	\N	2026-06-13 22:14:27.519	2026-06-13 22:14:27.519
cmqcwxr5u00muibngres5d0nz	messages-archive	t	\N	NEVER_RUN	\N	\N	\N	2026-06-13 22:14:27.521	2026-06-13 22:14:27.521
cmqcwxr5x00mvibng9eg24nt6	whatsapp-queue-cleanup	t	\N	NEVER_RUN	\N	\N	\N	2026-06-13 22:14:27.524	2026-06-13 22:14:27.524
cmqcwxr5z00mwibng2oz7mbn6	soft-delete-cleanup	t	\N	NEVER_RUN	\N	\N	\N	2026-06-13 22:14:27.526	2026-06-13 22:14:27.526
cmqcwxr6100mxibngrwnf0f0i	support-attachments-cleanup	t	\N	NEVER_RUN	\N	\N	\N	2026-06-13 22:14:27.529	2026-06-13 22:14:27.529
cmqcwxr6400myibngatj0grzu	monthly-billing	t	\N	NEVER_RUN	\N	\N	\N	2026-06-13 22:14:27.531	2026-06-13 22:14:27.531
cmsw1mi5s0002i0ngu9a411nj	soft-delete-hard-delete	t	2026-08-16 16:53:32.603	SUCCESS	\N	41	2026-08-17 09:20:00	2026-08-16 16:52:42.736	2026-08-16 16:53:32.603
\.


--
-- Data for Name: search_conversations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.search_conversations (id, "sessionId", "workspaceId", "customerId", state, "activeAgent", "lastQuery", "lastResponse", metadata, "createdAt", "updatedAt", "expiresAt") FROM stdin;
\.


--
-- Data for Name: secure_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.secure_tokens (id, token, type, "workspaceId", "userId", "phoneNumber", payload, "expiresAt", "usedAt", "ipAddress", "createdAt", "updatedAt", "customerId") FROM stdin;
\.


--
-- Data for Name: services; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.services (id, code, name, description, price, currency, "isActive", "workspaceId", "createdAt", "updatedAt", duration, "imageUrl", "imageKey", "enableForBooking", "bufferTime", color) FROM stdin;
cmqcwxqm50046ibngvzjcvnpy	GFT001	Confezione Regalo	Servizio di confezione regalo di lusso con messaggio personalizzato e materiali premium.	30.00	EUR	t	bellitalia-vip-ecommerce	2026-06-13 22:14:26.813	2026-06-13 22:14:26.813	60	{/uploads/services/GFT001_1760563067773_otbvy8.webp}	\N	f	0	#3b82f6
cmqcwxqm70047ibnga0piy6ra	SHP001	Spedizione Express	Consegna garantita in 24 ore lavorative. Tracciamento in tempo reale e assicurazione inclusa.	15.00	EUR	t	bellitalia-vip-ecommerce	2026-06-13 22:14:26.815	2026-06-13 22:14:26.815	60	{}	\N	f	0	#3b82f6
\.


--
-- Data for Name: soft_delete_audit_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.soft_delete_audit_logs (id, "workspaceId", "entityType", "deletedIds", "deletedIdCount", reason, "deletedByUserId", "deletedAt") FROM stdin;
\.


--
-- Data for Name: support_attachments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.support_attachments (id, "messageId", filename, url, "storageKey", "mimeType", size, "createdAt") FROM stdin;
\.


--
-- Data for Name: support_messages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.support_messages (id, "ticketId", "senderId", "senderType", content, "isRead", "createdAt") FROM stdin;
\.


--
-- Data for Name: support_tickets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.support_tickets (id, "ticketCode", "userId", "workspaceId", "issueType", subject, status, "createdAt", "updatedAt", "closedAt") FROM stdin;
\.


--
-- Data for Name: tourist_apartments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tourist_apartments (id, "workspaceId", name, description, category, location, "streetNumber", phone, mobile, email, rooms, beds, bathrooms, link, "videoUrl", "order", "isActive", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: tourist_castles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tourist_castles (id, "workspaceId", name, description, century, "visitInfo", location, phone, link, "videoUrl", "order", "isActive", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: tourist_churches; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tourist_churches (id, "workspaceId", name, description, century, style, location, phone, link, "videoUrl", "order", "isActive", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: tourist_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tourist_events (id, "workspaceId", title, description, location, "startDate", "endDate", price, "ticketInfo", link, "ticketLink", "videoUrl", "order", "isActive", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: tourist_excursions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tourist_excursions (id, "workspaceId", name, description, difficulty, duration, location, link, "videoUrl", "order", "isActive", "createdAt", "updatedAt", season) FROM stdin;
\.


--
-- Data for Name: tourist_hotels; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tourist_hotels (id, "workspaceId", name, description, stars, location, phone, link, "videoUrl", "order", "isActive", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: tourist_photos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tourist_photos (id, "workspaceId", "contentType", "contentId", "imageBase64", caption, "order", "createdAt") FROM stdin;
\.


--
-- Data for Name: tourist_refuges; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tourist_refuges (id, "workspaceId", name, description, "climbTime", difficulty, "openFrom", "openTo", location, phone, link, "videoUrl", "order", "isActive", "createdAt", "updatedAt", email) FROM stdin;
\.


--
-- Data for Name: tourist_restaurants; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tourist_restaurants (id, "workspaceId", name, description, "cuisineType", "celiacFriendly", "needsReservation", location, phone, link, "videoUrl", "order", "isActive", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: tourist_ski_facilities; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tourist_ski_facilities (id, "workspaceId", name, description, "slopeType", location, link, "videoUrl", "order", "isActive", "createdAt", "updatedAt") FROM stdin;
cmthv5axi00049fngqwz4ol6r	cmqcx3fcx0000cgng9dml0qbh	Seggiovia Pian dei Nidi	Seggiovia del comprensorio Monte Siera–Pian dei Nidi, sempre perfettamente innevato: il passo successivo ideale per chi ha appena iniziato a sciare. Skipass: tel 0435 469122 — skipass@travelone.it	\N	Pian dei Nidi / Monte Siera	https://www.sappadaski.it	\N	0	t	2026-08-31 23:22:18.39	2026-08-31 23:22:18.39
cmthv5axk00059fng7eex3l6q	cmqcx3fcx0000cgng9dml0qbh	Seggiovia Monte Siera	Seggiovia che sale verso il Monte Siera e le piste del suo comprensorio.	\N	Monte Siera	https://www.sappadaski.it	\N	1	t	2026-08-31 23:22:18.392	2026-08-31 23:22:18.392
cmthv5axl00069fngwtbqzkli	cmqcx3fcx0000cgng9dml0qbh	Sappada 2000 – Seggiovie Miravalle e Hochbolt	Comprensorio in quota sempre soleggiato e con panorama strepitoso, raggiungibile con il bus-navetta gratuito (per chi ha lo skipass) da Pian dei Nidi. Le due seggiovie Miravalle e Hochbolt servono le piste più impegnative, rosse e nere.	rossa, nera	Sappada 2000	https://www.sappadaski.it	\N	2	t	2026-08-31 23:22:18.393	2026-08-31 23:22:18.393
cmthv5axm00079fng6uic0uiu	cmqcx3fcx0000cgng9dml0qbh	Pista Eiben – Col dei Mughi	Pista nera in centro paese, servita dalla seggiovia Eiben–Col dei Mughi.	nera	Centro paese, accanto a Nevelandia	https://www.sappadaski.it	\N	3	t	2026-08-31 23:22:18.394	2026-08-31 23:22:18.394
cmthv5axn00089fngjdgabbts	cmqcx3fcx0000cgng9dml0qbh	Campetti scuola – Sciovia Campetto	Vasti campi scuola in centro paese, ideali per principianti e famiglie.	blu	Centro paese	https://www.sappadaski.it	\N	4	t	2026-08-31 23:22:18.395	2026-08-31 23:22:18.395
cmthv5axp00099fngw9i9b1ei	cmqcx3fcx0000cgng9dml0qbh	Nevelandia	Baby park sulla neve gestito dalla scuola sci locale: piste per slittini, tubing, pattinaggio su ghiaccio e attività per bambini.	\N	Centro paese	https://www.sappadaski.it	\N	5	t	2026-08-31 23:22:18.397	2026-08-31 23:22:18.397
\.


--
-- Data for Name: tourist_sports_facilities; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tourist_sports_facilities (id, "workspaceId", name, description, sport, location, link, "videoUrl", "order", "isActive", "createdAt", "updatedAt", season) FROM stdin;
cmthv5ax500009fng7h4hqu1r	cmqcx3fcx0000cgng9dml0qbh	Golf Club Sappada	Campo a 9 buche (giocabile anche su 18) a 1.250 metri di quota, tra prati ondulati e boschi con vista sulle Dolomiti. Par 30, 1.428 metri totali. Area pratica, putting green, noleggio sacche, spogliatoi e club house in una tipica casa sappadina in legno con bar-ristorante. Aperto da maggio a ottobre. Tel: 0435 469585 — info@golfclubsappada.com	golf	Borgata Bach 96	https://www.golfclubsappada.com	\N	0	t	2026-08-31 23:22:18.377	2026-08-31 23:22:18.377	estiva
cmthv5axb00019fng9brn90sr	cmqcx3fcx0000cgng9dml0qbh	Tennis Eiben – Pista Nera	Campo da tennis in località Eiben/Pista Nera. Prenotazioni sul posto o presso Punto Sport Kratter, borgata Bach — tel 0435 469102.	tennis	Località Eiben / Pista Nera	https://www.sappadadolomiti.com/attivita/tennis/	\N	1	t	2026-08-31 23:22:18.383	2026-08-31 23:22:18.383	estiva
cmthv5axd00029fng35bhvj9c	cmqcx3fcx0000cgng9dml0qbh	Campo polivalente Cima Sappada	Campo polivalente per tennis, calcetto e pallavolo. Info e prenotazioni presso Alimentari Ciotti, borgata Cima — tel 0435 469208 / 338 8472028.	tennis, calcetto, pallavolo	Cima Sappada	https://www.sappadadolomiti.com/attivita/tennis/	\N	2	t	2026-08-31 23:22:18.385	2026-08-31 23:22:18.385	estiva
cmthv5axf00039fngy394jez8	cmqcx3fcx0000cgng9dml0qbh	Pista di sci nordico	Anello di sci nordico di circa 15 km che si snoda nella valle soleggiata e nei boschi. Sappada è terra di campioni del fondo e del biathlon — 13 medaglie olimpiche, da Silvio Fauner a Pietro Piller Cottrer e Lisa Vittozzi — e lo stadio del fondo ospita eventi internazionali.	sci di fondo	Sappada	https://www.sappadadolomiti.com/tipo-attivita/sport-sappada/	\N	3	t	2026-08-31 23:22:18.387	2026-08-31 23:22:18.387	invernale
\.


--
-- Data for Name: tourist_venues; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tourist_venues (id, "workspaceId", name, description, "venueType", "openingHours", location, phone, link, "videoUrl", "order", "isActive", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: tourist_viewpoints; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tourist_viewpoints (id, "workspaceId", name, description, altitude, access, difficulty, location, link, "videoUrl", "order", "isActive", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: two_factor_reset_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.two_factor_reset_tokens (id, "userId", token, "expiresAt", "usedAt", "createdAt", "createdByAdminId", "passwordAttempts", "lockedUntil") FROM stdin;
\.


--
-- Data for Name: usage; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.usage (id, "workspaceId", "clientId", price, "createdAt") FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, email, "passwordHash", "firstName", "lastName", status, "lastLogin", "createdAt", "updatedAt", "deletedAt", role, "isPlatformAdmin", "isDeveloperUser", "twoFactorSecret", "twoFactorEnabled", "twoFactorEnabledAt", "recoveryCodes", "authProvider", "profilePicture", logo, "linkedProviders", "gdprAccepted", "phoneNumber", language, "companyName", "vatNumber", website, "billingPhone", "billingAddress", "planType", "creditBalance", "trialEndsAt", "planStartedAt", "nextBillingDate", "lowBalanceNotifiedAt", "subscriptionStatus", "pausedAt", "pauseRequestedAt", "pendingPlanType", "pendingPlanEffectiveDate", "lastPaymentFailedAt", "paymentFailureCount", "paypalStatus", "isPaymentConnected", "paypalClientId", "paypalMerchantId", "paypalEmail", "paypalEnvironment", "paypalConnectedAt", "paypalAccessTokenEncrypted", "paypalRefreshTokenEncrypted", "paypalTokenExpiresAt", "paypalTokenScope", "paypalSubscriptionId", "paypalPlanId", "paypalSubscriptionStatus", "paypalNextBillingTime", "paypalLastPaymentTime", "paypalFailedPaymentsCount", "paypalCyclesCompleted", "paypalOutstandingBalance", "paypalSubscriptionApprovedAt", "isDemoUser", "taxRate", "trialExpiringNotifiedAt") FROM stdin;
fd566368-a330-47b4-9b11-3e44622cba2e	gelsogrove@gmail.com	$2b$10$j0x49A.99H3CYoT3NYIJQORJFE/YvYBWivcpsSAATe6.XmA/dUQpe	Andrea	Gelsomino	ACTIVE	2026-08-26 17:19:58.808	2026-06-13 22:14:26.25	2026-08-26 17:19:58.813	\N	ADMIN	t	t	\N	f	\N	{}	email	https://lh3.googleusercontent.com/a/ACg8ocKNHtTdnjqwDFICuKSi_3y8cJa-6osTP3AkmwZKu1p81XMoPQ9C=s96-c	\N	[]	\N	\N	ENG	eChatbot Italia S.r.l.	IT12345678901	https://www.echatbot.it	+39 06 1234567	Via Roma 123, 00100 Roma, Italia	ENTERPRISE	169.90	\N	2026-06-13 22:14:26.25	\N	\N	ACTIVE	\N	\N	\N	\N	\N	0	CONNECTED	t	paypal-client-demo-1234	paypal-merchant-5678	gelsogrove@gmail.com	sandbox	2025-11-01 08:30:00	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	0.00	\N	f	0.2200	\N
25dd4967-6382-4f95-a318-cabc0d3ad114	characteristics-test-1785518874320@test.com	\N	Characteristics	Test	ACTIVE	\N	2026-07-31 17:27:54.625	2026-07-31 17:27:54.625	\N	MEMBER	f	f	\N	f	\N	{}	email	\N	\N	[]	\N	\N	ENG	\N	\N	\N	\N	\N	PREMIUM	100.00	\N	2026-07-31 17:27:54.625	\N	\N	ACTIVE	\N	\N	\N	\N	\N	0	DISCONNECTED	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	0.00	\N	f	0.2200	\N
88701424-9c88-4309-87e5-fb584e744331	characteristics-test-1785614818887@test.com	\N	Characteristics	Test	ACTIVE	\N	2026-08-01 20:06:59.09	2026-08-01 20:06:59.09	\N	MEMBER	f	f	\N	f	\N	{}	email	\N	\N	[]	\N	\N	ENG	\N	\N	\N	\N	\N	PREMIUM	100.00	\N	2026-08-01 20:06:59.09	\N	\N	ACTIVE	\N	\N	\N	\N	\N	0	DISCONNECTED	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	0	0.00	\N	f	0.2200	\N
\.


--
-- Data for Name: whatsapp_queue; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.whatsapp_queue (id, "workspaceId", "customerId", "phoneNumber", "messageContent", status, "errorMessage", "createdAt", "deliveredAt", "conversationMessageId", "pushCampaignId", "pushCampaignRecipientId", channel, "visitorId", "isAnonymous", "expiresAt", "responsePayload", "pollingAttempts", "lastPolledAt", "isPlayground", "skipSecurityCheck", "retryCount", "maxRetries", "nextRetryAt", "mediaUrl") FROM stdin;
9ef8dd37-908e-46a1-861c-65b7eba4a065	bellitalia-vip-ecommerce	768079dc-ade2-47c9-ae94-fa839d96b5dc	+390212345678	¡Hola! Tu pedido ha sido enviado con éxito.	sent	\N	2026-06-13 22:11:27.221	2026-06-13 22:12:27.221	\N	\N	\N	whatsapp	\N	f	\N	\N	0	\N	f	f	0	3	\N	\N
6f331e0c-a27e-44f0-9e9d-8cc9427916bb	bellitalia-vip-ecommerce	6fc43406-b2ef-48ba-a1dd-3171316d3cf3	+34666777888	Messaggio bloccato per sicurezza	error	Safety validation failed	2026-06-13 22:09:27.224	\N	\N	\N	\N	whatsapp	\N	f	\N	\N	0	\N	f	f	0	3	\N	\N
9e3f79d6-0fd5-4b1c-ac02-5747e227ed5e	bellitalia-vip-ecommerce	e47d0970-59a7-4c6e-bf3d-abae59964db0	invalid-phone	Test message with invalid phone	error	Invalid phone number format	2026-06-13 22:10:27.227	\N	\N	\N	\N	whatsapp	\N	f	\N	\N	0	\N	f	f	0	3	\N	\N
ac92faa1-57d0-4017-940f-384ac524a17c	bellitalia-vip-ecommerce	e47d0970-59a7-4c6e-bf3d-abae59964db0		Quali sono le offerte attive?	sent	\N	2026-06-13 22:12:27.23	2026-06-13 22:13:27.23	\N	\N	\N	widget	visitor_1726262001000_b8l3n0y2	t	2026-06-14 22:14:27.23	{"response": "Abbiamo diverse offerte attive! Ti consiglio di dare un'occhiata alla sezione Offerte.", "processedAt": "2026-06-13T22:13:27.230Z"}	5	2026-06-13 22:14:22.23	f	f	0	3	\N	\N
4e651407-5a3d-45be-9c5f-b8d7c04f05e0	bellitalia-vip-ecommerce	6fc43406-b2ef-48ba-a1dd-3171316d3cf3		Ciao! Vorrei informazioni sui prodotti	error	Invalid phone number: empty	2026-06-13 22:13:57.229	\N	\N	\N	\N	widget	visitor_1726262000000_a7k2m9x1	t	2026-06-14 22:14:27.229	\N	0	\N	f	f	0	3	\N	\N
\.


--
-- Data for Name: whatsapp_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.whatsapp_settings (id, "phoneNumber", "apiKey", "appName", "appSecret", "webhookUrl", "webhookId", "webhookToken", "businessAccountId", settings, "adminEmail", "smtpHost", "smtpPort", "smtpSecure", "smtpUser", "smtpPass", "smtpFrom", "createdAt", "updatedAt", "workspaceId", gdpr) FROM stdin;
86a3c653-bc55-435b-9f88-23b82f5b5584	+34654728752	dummy-api-key	\N	\N	https://echatbot.ai/webhook	webhook-bellitalia-info-workspace	token-info-1781388866289	\N	{}	gelsogrove@gmail.com	smtp.gmail.com	465	t	gelsogrove@gmail.com	bhfg vynq uwqm jckm	eChatbot <gelsogrove@gmail.com>	2026-06-13 22:14:26.29	2026-06-13 22:14:26.29	bellitalia-info-workspace	\N
e45e4097-a442-46ec-9529-2df1dd4e1df7	+34654728753	dummy-api-key	\N	\N	https://echatbot.ai/webhook	webhook-echatbot-hq-support	token-support-1781388866495	\N	{}	gelsogrove@gmail.com	smtp.gmail.com	465	t	gelsogrove@gmail.com	bhfg vynq uwqm jckm	eChatbot <gelsogrove@gmail.com>	2026-06-13 22:14:26.495	2026-06-13 22:14:26.495	echatbot-hq-support	\N
\.


--
-- Data for Name: whatsapp_webhook_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.whatsapp_webhook_events (id, "workspaceId", "externalMessageId", channel, "receivedAt") FROM stdin;
\.


--
-- Data for Name: workspace_business_hours; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.workspace_business_hours (id, "workspaceId", "dayOfWeek", "startTime", "endTime", "isActive") FROM stdin;
6cf539e5-c94a-4dc1-956d-cf81c0b0520f	bellitalia-vip-ecommerce	1	09:00	17:00	t
42ebe7c9-98b2-4871-8a73-24db77beec95	bellitalia-vip-ecommerce	2	09:00	17:00	t
c21f9144-92b3-468b-88d1-8563c5bce09e	bellitalia-vip-ecommerce	3	09:00	17:00	t
03e6a832-abf7-47b7-87f4-80852b0aa43d	bellitalia-vip-ecommerce	4	09:00	17:00	t
d0129130-a523-4ca8-a01d-053b23851ee7	bellitalia-vip-ecommerce	5	09:00	17:00	t
1b8bacb4-575b-4046-81e7-ef7294283b02	bellitalia-vip-ecommerce	6	09:00	13:00	t
\.


--
-- Data for Name: workspace_calling_functions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.workspace_calling_functions (id, "workspaceId", "functionName", description, "responseInstructions", parameters, "isSystemFunction", "executionType", "attachedLlm", "attachedFlowKey", "webhookUrl", "credentialsMapping", "isActive", "createdAt", "updatedAt") FROM stdin;
cmqcwxqnt0058ibngzv5cnvyb	bellitalia-vip-ecommerce	listAvailableSlots	Show available slots for appointment booking. Use when customer wants to book an appointment, asks about availability.	\N	{"type": "object", "required": [], "properties": {"daysAhead": {"type": "number", "description": "How many days ahead to search (default 7, max 14). Ignored when targetDate is specified."}, "serviceId": {"type": "string", "description": "ID of the service to book (optional - auto-selected if only one service exists)"}, "targetDate": {"type": "string", "description": "Specific date in YYYY-MM-DD format. Use when customer asks for availability on a specific day (e.g. next Thursday, this Friday). Example: 2026-04-17"}}}	t	INTERNAL	\N	\N	\N	\N	t	2026-06-13 22:14:26.872	2026-06-13 22:14:26.872
cmqcwxqny0059ibngokq6m3qe	bellitalia-vip-ecommerce	bookAppointment	Confirm an appointment booking. Use when customer has chosen a slot and confirms. Requires appointmentTypeId and startTime.	\N	{"type": "object", "required": ["appointmentTypeId", "startTime"], "properties": {"startTime": {"type": "string", "description": "Start time in ISO 8601 format"}, "customerNotes": {"type": "string", "description": "Optional customer notes"}, "appointmentTypeId": {"type": "string", "description": "ID of appointment type"}}}	t	INTERNAL	\N	\N	\N	\N	t	2026-06-13 22:14:26.877	2026-06-13 22:14:26.877
cmqcwxqo2005aibng2vgatmfr	bellitalia-vip-ecommerce	cancelAppointment	Cancel an existing appointment. Use when customer wants to cancel a booked appointment.	\N	{"type": "object", "required": ["appointmentId"], "properties": {"reason": {"type": "string", "description": "Cancellation reason (optional)"}, "appointmentId": {"type": "string", "description": "ID of appointment to cancel"}}}	t	INTERNAL	\N	\N	\N	\N	t	2026-06-13 22:14:26.881	2026-06-13 22:14:26.881
cmqcwxqo5005bibnga3b26dd0	bellitalia-vip-ecommerce	getCustomerAppointments	Show customer's upcoming appointments. Use when customer asks about their bookings.	\N	{"type": "object", "required": [], "properties": {}}	t	INTERNAL	\N	\N	\N	\N	t	2026-06-13 22:14:26.884	2026-06-13 22:14:26.884
cmqcwxqo7005cibng8cs62tg8	bellitalia-vip-ecommerce	rescheduleAppointment	Reschedule an existing appointment to a new time. Use when customer wants to move their appointment to a different slot.	\N	{"type": "object", "required": ["appointmentId", "newStartTime"], "properties": {"reason": {"type": "string", "description": "Reason for rescheduling (optional)"}, "newStartTime": {"type": "string", "description": "New start time in ISO 8601 format"}, "appointmentId": {"type": "string", "description": "ID of appointment to reschedule"}}}	t	INTERNAL	\N	\N	\N	\N	t	2026-06-13 22:14:26.886	2026-06-13 22:14:26.886
cmqcwxqoa005dibngvz9tnbfn	bellitalia-info-workspace	listAvailableSlots	Show available slots for appointment booking. Use when customer wants to book an appointment, asks about availability.	\N	{"type": "object", "required": [], "properties": {"daysAhead": {"type": "number", "description": "How many days ahead to search (default 7, max 14). Ignored when targetDate is specified."}, "serviceId": {"type": "string", "description": "ID of the service to book (optional - auto-selected if only one service exists)"}, "targetDate": {"type": "string", "description": "Specific date in YYYY-MM-DD format. Use when customer asks for availability on a specific day (e.g. next Thursday, this Friday). Example: 2026-04-17"}}}	t	INTERNAL	\N	\N	\N	\N	t	2026-06-13 22:14:26.889	2026-06-13 22:14:26.889
cmqcwxqod005eibng9uusni0v	bellitalia-info-workspace	bookAppointment	Confirm an appointment booking. Use when customer has chosen a slot and confirms. Requires appointmentTypeId and startTime.	\N	{"type": "object", "required": ["appointmentTypeId", "startTime"], "properties": {"startTime": {"type": "string", "description": "Start time in ISO 8601 format"}, "customerNotes": {"type": "string", "description": "Optional customer notes"}, "appointmentTypeId": {"type": "string", "description": "ID of appointment type"}}}	t	INTERNAL	\N	\N	\N	\N	t	2026-06-13 22:14:26.892	2026-06-13 22:14:26.892
cmqcwxqof005fibngo7bsyetw	bellitalia-info-workspace	cancelAppointment	Cancel an existing appointment. Use when customer wants to cancel a booked appointment.	\N	{"type": "object", "required": ["appointmentId"], "properties": {"reason": {"type": "string", "description": "Cancellation reason (optional)"}, "appointmentId": {"type": "string", "description": "ID of appointment to cancel"}}}	t	INTERNAL	\N	\N	\N	\N	t	2026-06-13 22:14:26.894	2026-06-13 22:14:26.894
cmqcwxqoi005gibng6vha5ku4	bellitalia-info-workspace	getCustomerAppointments	Show customer's upcoming appointments. Use when customer asks about their bookings.	\N	{"type": "object", "required": [], "properties": {}}	t	INTERNAL	\N	\N	\N	\N	t	2026-06-13 22:14:26.897	2026-06-13 22:14:26.897
cmqcwxqol005hibngz1ge4p6t	bellitalia-info-workspace	rescheduleAppointment	Reschedule an existing appointment to a new time. Use when customer wants to move their appointment to a different slot.	\N	{"type": "object", "required": ["appointmentId", "newStartTime"], "properties": {"reason": {"type": "string", "description": "Reason for rescheduling (optional)"}, "newStartTime": {"type": "string", "description": "New start time in ISO 8601 format"}, "appointmentId": {"type": "string", "description": "ID of appointment to reschedule"}}}	t	INTERNAL	\N	\N	\N	\N	t	2026-06-13 22:14:26.9	2026-06-13 22:14:26.9
cmqcwxqon005iibngz2rv1pjx	bellitalia-vip-ecommerce	changeLanguage	Change the customer's preferred language. Supported: Italian (it), English (en), Spanish (es), Portuguese (pt).	\N	{"type": "object", "required": ["language"], "properties": {"language": {"enum": ["it", "en", "es", "pt"], "type": "string", "description": "ISO 639-1 language code"}}}	t	INTERNAL	\N	\N	\N	\N	t	2026-06-13 22:14:26.903	2026-06-13 22:14:26.903
cmqcwxqoq005jibngs5ussjap	bellitalia-info-workspace	changeLanguage	Change the customer's preferred language. Supported: Italian (it), English (en), Spanish (es), Portuguese (pt).	\N	{"type": "object", "required": ["language"], "properties": {"language": {"enum": ["it", "en", "es", "pt"], "type": "string", "description": "ISO 639-1 language code"}}}	t	INTERNAL	\N	\N	\N	\N	t	2026-06-13 22:14:26.905	2026-06-13 22:14:26.905
cmqcwxqot005kibngw9j1zb57	bellitalia-vip-ecommerce	customerSupportAgent	Delegate to Customer Support Agent for complaints, issues, human operator contact. Use when customer is frustrated or has problems. NOT for notification management.	\N	{"type": "object", "required": ["query"], "properties": {"query": {"type": "string", "description": "Support request"}}}	t	DELEGATE_TO_AGENT	CUSTOMER_SUPPORT	\N	\N	\N	t	2026-06-13 22:14:26.908	2026-06-13 22:14:26.908
cmqcwxqov005libngfh6zf1qj	bellitalia-vip-ecommerce	profileManagementAgent	Delegate to Profile Management Agent for email updates, notification preferences, profile data changes. Use for notification subscribe/unsubscribe, email change.	\N	{"type": "object", "required": ["query"], "properties": {"query": {"type": "string", "description": "Profile-related request"}}}	t	DELEGATE_TO_AGENT	PROFILE_MANAGEMENT	\N	\N	\N	t	2026-06-13 22:14:26.91	2026-06-13 22:14:26.91
cmqcwxqox005mibngvli23kyw	bellitalia-vip-ecommerce	manageNotifications	Manage push notification preferences (subscribe/unsubscribe).	\N	{"type": "object", "required": ["action"], "properties": {"action": {"enum": ["subscribe", "unsubscribe"], "type": "string", "description": "Action to perform"}}}	t	INTERNAL	\N	\N	\N	\N	t	2026-06-13 22:14:26.912	2026-06-13 22:14:26.912
cmqcwxqp0005nibngjfjkl6hi	bellitalia-info-workspace	customerSupportAgent	Delegate to Customer Support Agent for complaints, issues, human operator contact. Use when customer is frustrated or has problems. NOT for notification management.	\N	{"type": "object", "required": ["query"], "properties": {"query": {"type": "string", "description": "Support request"}}}	t	DELEGATE_TO_AGENT	CUSTOMER_SUPPORT	\N	\N	\N	t	2026-06-13 22:14:26.915	2026-06-13 22:14:26.915
cmqcwxqp2005oibngfazf7zsr	bellitalia-info-workspace	profileManagementAgent	Delegate to Profile Management Agent for email updates, notification preferences, profile data changes. Use for notification subscribe/unsubscribe, email change.	\N	{"type": "object", "required": ["query"], "properties": {"query": {"type": "string", "description": "Profile-related request"}}}	t	DELEGATE_TO_AGENT	PROFILE_MANAGEMENT	\N	\N	\N	t	2026-06-13 22:14:26.918	2026-06-13 22:14:26.918
cmqcwxqp5005pibnge4oxpg4w	bellitalia-info-workspace	manageNotifications	Manage push notification preferences (subscribe/unsubscribe).	\N	{"type": "object", "required": ["action"], "properties": {"action": {"enum": ["subscribe", "unsubscribe"], "type": "string", "description": "Action to perform"}}}	t	INTERNAL	\N	\N	\N	\N	t	2026-06-13 22:14:26.92	2026-06-13 22:14:26.92
cmqcwxqp7005qibngpzc7vmfv	bellitalia-vip-ecommerce	productSearchAgent	Delegate to Product Search Agent for product catalog browsing, search, filters. Use when customer asks about products, prices, categories, certifications.	\N	{"type": "object", "required": ["query"], "properties": {"query": {"type": "string", "description": "Customer's product search query"}}}	t	DELEGATE_TO_AGENT	PRODUCT_SEARCH	\N	\N	\N	t	2026-06-13 22:14:26.923	2026-06-13 22:14:26.923
cmqcwxqp9005ribngh11wfz30	bellitalia-vip-ecommerce	cartManagementAgent	Delegate to Cart Management Agent for add/remove products, view cart, modify quantities. Use when customer wants to add to cart or modify cart contents.	\N	{"type": "object", "required": ["query"], "properties": {"query": {"type": "string", "description": "Cart-related request"}}}	t	DELEGATE_TO_AGENT	CART_MANAGEMENT	\N	\N	\N	t	2026-06-13 22:14:26.925	2026-06-13 22:14:26.925
cmqcwxqpc005sibngf5tw198y	bellitalia-vip-ecommerce	orderTrackingAgent	Delegate to Order Tracking Agent for order history, tracking, checkout confirmation. Use for orders, delivery status, checkout.	\N	{"type": "object", "required": ["query"], "properties": {"query": {"type": "string", "description": "Order-related question"}}}	t	DELEGATE_TO_AGENT	ORDER_TRACKING	\N	\N	\N	t	2026-06-13 22:14:26.927	2026-06-13 22:14:26.927
cmt7c82x60000gwngjs844rkw	cmqcx3fcx0000cgng9dml0qbh	changeLanguage	Change the customer's preferred language. Supported: Italian (it), English (en), Spanish (es), Portuguese (pt).	\N	{"type": "object", "required": ["language"], "properties": {"language": {"enum": ["it", "en", "es", "pt"], "type": "string", "description": "ISO 639-1 language code"}}}	t	INTERNAL	\N	\N	\N	\N	t	2026-08-24 14:34:53.514	2026-08-24 14:34:53.514
\.


--
-- Data for Name: workspace_environment_variables; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.workspace_environment_variables (id, "workspaceId", "variableName", "encryptedValue", nonce, description, "createdBy", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: workspace_invitations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.workspace_invitations (id, email, "firstName", "lastName", "workspaceId", "tokenHash", "invitedById", status, "expiresAt", "createdAt", "acceptedAt") FROM stdin;
\.


--
-- Name: Billing Billing_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Billing"
    ADD CONSTRAINT "Billing_pkey" PRIMARY KEY (id);


--
-- Name: Certification Certification_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Certification"
    ADD CONSTRAINT "Certification_pkey" PRIMARY KEY (id);


--
-- Name: ProductCategory ProductCategory_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ProductCategory"
    ADD CONSTRAINT "ProductCategory_pkey" PRIMARY KEY ("productId", "categoryId");


--
-- Name: ProductCertification ProductCertification_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ProductCertification"
    ADD CONSTRAINT "ProductCertification_pkey" PRIMARY KEY ("productId", "certificationId");


--
-- Name: ProductCharacteristic ProductCharacteristic_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ProductCharacteristic"
    ADD CONSTRAINT "ProductCharacteristic_pkey" PRIMARY KEY (id);


--
-- Name: ProductType ProductType_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ProductType"
    ADD CONSTRAINT "ProductType_pkey" PRIMARY KEY ("productId", "typeId");


--
-- Name: ShortUrls ShortUrls_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ShortUrls"
    ADD CONSTRAINT "ShortUrls_pkey" PRIMARY KEY (id);


--
-- Name: Type Type_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Type"
    ADD CONSTRAINT "Type_pkey" PRIMARY KEY (id);


--
-- Name: UserWorkspace UserWorkspace_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."UserWorkspace"
    ADD CONSTRAINT "UserWorkspace_pkey" PRIMARY KEY ("userId", "workspaceId");


--
-- Name: Workspace Workspace_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Workspace"
    ADD CONSTRAINT "Workspace_pkey" PRIMARY KEY (id);


--
-- Name: _OfferCategories _OfferCategories_AB_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."_OfferCategories"
    ADD CONSTRAINT "_OfferCategories_AB_pkey" PRIMARY KEY ("A", "B");


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: admin_sessions admin_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_sessions
    ADD CONSTRAINT admin_sessions_pkey PRIMARY KEY (id);


--
-- Name: agent_configs agent_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_configs
    ADD CONSTRAINT agent_configs_pkey PRIMARY KEY (id);


--
-- Name: agent_conversation_logs agent_conversation_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_conversation_logs
    ADD CONSTRAINT agent_conversation_logs_pkey PRIMARY KEY (id);


--
-- Name: appointments appointments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_pkey PRIMARY KEY (id);


--
-- Name: authentication_attempts authentication_attempts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.authentication_attempts
    ADD CONSTRAINT authentication_attempts_pkey PRIMARY KEY (id);


--
-- Name: billing_transactions billing_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.billing_transactions
    ADD CONSTRAINT billing_transactions_pkey PRIMARY KEY (id);


--
-- Name: blackout_periods blackout_periods_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.blackout_periods
    ADD CONSTRAINT blackout_periods_pkey PRIMARY KEY (id);


--
-- Name: cart_items cart_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cart_items
    ADD CONSTRAINT cart_items_pkey PRIMARY KEY (id);


--
-- Name: carts carts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.carts
    ADD CONSTRAINT carts_pkey PRIMARY KEY (id);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: chat_sessions chat_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_sessions
    ADD CONSTRAINT chat_sessions_pkey PRIMARY KEY (id);


--
-- Name: conversation_messages conversation_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversation_messages
    ADD CONSTRAINT conversation_messages_pkey PRIMARY KEY (id);


--
-- Name: credit_notes credit_notes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_notes
    ADD CONSTRAINT credit_notes_pkey PRIMARY KEY (id);


--
-- Name: customer_feedback customer_feedback_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_feedback
    ADD CONSTRAINT customer_feedback_pkey PRIMARY KEY (id);


--
-- Name: customers customers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_pkey PRIMARY KEY (id);


--
-- Name: demorobot_assets demorobot_assets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.demorobot_assets
    ADD CONSTRAINT demorobot_assets_pkey PRIMARY KEY (id);


--
-- Name: demorobot_flow_edges demorobot_flow_edges_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.demorobot_flow_edges
    ADD CONSTRAINT demorobot_flow_edges_pkey PRIMARY KEY (id);


--
-- Name: demorobot_flow_node_attachments demorobot_flow_node_attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.demorobot_flow_node_attachments
    ADD CONSTRAINT demorobot_flow_node_attachments_pkey PRIMARY KEY ("nodeId", "assetId");


--
-- Name: demorobot_flow_nodes demorobot_flow_nodes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.demorobot_flow_nodes
    ADD CONSTRAINT demorobot_flow_nodes_pkey PRIMARY KEY (id);


--
-- Name: demorobot_flows demorobot_flows_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.demorobot_flows
    ADD CONSTRAINT demorobot_flows_pkey PRIMARY KEY (id);


--
-- Name: faqs faqs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.faqs
    ADD CONSTRAINT faqs_pkey PRIMARY KEY (id);


--
-- Name: flow_categories flow_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.flow_categories
    ADD CONSTRAINT flow_categories_pkey PRIMARY KEY (id);


--
-- Name: flow_node_configs flow_node_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.flow_node_configs
    ADD CONSTRAINT flow_node_configs_pkey PRIMARY KEY (id);


--
-- Name: gdpr_content gdpr_content_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gdpr_content
    ADD CONSTRAINT gdpr_content_pkey PRIMARY KEY (id);


--
-- Name: google_calendar_connections google_calendar_connections_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.google_calendar_connections
    ADD CONSTRAINT google_calendar_connections_pkey PRIMARY KEY (id);


--
-- Name: invoice_adjustments invoice_adjustments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_adjustments
    ADD CONSTRAINT invoice_adjustments_pkey PRIMARY KEY (id);


--
-- Name: invoice_credit_notes invoice_credit_notes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_credit_notes
    ADD CONSTRAINT invoice_credit_notes_pkey PRIMARY KEY (id);


--
-- Name: invoice_year_sequences invoice_year_sequences_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_year_sequences
    ADD CONSTRAINT invoice_year_sequences_pkey PRIMARY KEY (year);


--
-- Name: languages languages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.languages
    ADD CONSTRAINT languages_pkey PRIMARY KEY (id);


--
-- Name: late_cancellation_attempts late_cancellation_attempts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.late_cancellation_attempts
    ADD CONSTRAINT late_cancellation_attempts_pkey PRIMARY KEY (id);


--
-- Name: merchant_pushes merchant_pushes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.merchant_pushes
    ADD CONSTRAINT merchant_pushes_pkey PRIMARY KEY (id);


--
-- Name: merchant_quota_topups merchant_quota_topups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.merchant_quota_topups
    ADD CONSTRAINT merchant_quota_topups_pkey PRIMARY KEY (id);


--
-- Name: merchants merchants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.merchants
    ADD CONSTRAINT merchants_pkey PRIMARY KEY (id);


--
-- Name: message_attachments message_attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message_attachments
    ADD CONSTRAINT message_attachments_pkey PRIMARY KEY (id);


--
-- Name: messages_archive messages_archive_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages_archive
    ADD CONSTRAINT messages_archive_pkey PRIMARY KEY (id);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id);


--
-- Name: monthly_invoices monthly_invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.monthly_invoices
    ADD CONSTRAINT monthly_invoices_pkey PRIMARY KEY (id);


--
-- Name: offers offers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.offers
    ADD CONSTRAINT offers_pkey PRIMARY KEY (id);


--
-- Name: onboarding_questionnaires onboarding_questionnaires_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.onboarding_questionnaires
    ADD CONSTRAINT onboarding_questionnaires_pkey PRIMARY KEY (id);


--
-- Name: order_items order_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_pkey PRIMARY KEY (id);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: password_resets password_resets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.password_resets
    ADD CONSTRAINT password_resets_pkey PRIMARY KEY (id);


--
-- Name: payment_details payment_details_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_details
    ADD CONSTRAINT payment_details_pkey PRIMARY KEY (id);


--
-- Name: paypal_transactions paypal_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.paypal_transactions
    ADD CONSTRAINT paypal_transactions_pkey PRIMARY KEY (id);


--
-- Name: paypal_webhook_events paypal_webhook_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.paypal_webhook_events
    ADD CONSTRAINT paypal_webhook_events_pkey PRIMARY KEY (id);


--
-- Name: plan_configurations plan_configurations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plan_configurations
    ADD CONSTRAINT plan_configurations_pkey PRIMARY KEY (id);


--
-- Name: platform_config platform_config_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.platform_config
    ADD CONSTRAINT platform_config_pkey PRIMARY KEY (id);


--
-- Name: playground_comments playground_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.playground_comments
    ADD CONSTRAINT playground_comments_pkey PRIMARY KEY (id);


--
-- Name: playground_todos playground_todos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.playground_todos
    ADD CONSTRAINT playground_todos_pkey PRIMARY KEY (id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: push_campaign_recipients push_campaign_recipients_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.push_campaign_recipients
    ADD CONSTRAINT push_campaign_recipients_pkey PRIMARY KEY (id);


--
-- Name: push_campaigns push_campaigns_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.push_campaigns
    ADD CONSTRAINT push_campaigns_pkey PRIMARY KEY (id);


--
-- Name: registration_tokens registration_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.registration_tokens
    ADD CONSTRAINT registration_tokens_pkey PRIMARY KEY (id);


--
-- Name: reminder_locks reminder_locks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reminder_locks
    ADD CONSTRAINT reminder_locks_pkey PRIMARY KEY (id);


--
-- Name: sales sales_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT sales_pkey PRIMARY KEY (id);


--
-- Name: scheduler_job_status scheduler_job_status_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scheduler_job_status
    ADD CONSTRAINT scheduler_job_status_pkey PRIMARY KEY (id);


--
-- Name: search_conversations search_conversations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.search_conversations
    ADD CONSTRAINT search_conversations_pkey PRIMARY KEY (id);


--
-- Name: secure_tokens secure_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.secure_tokens
    ADD CONSTRAINT secure_tokens_pkey PRIMARY KEY (id);


--
-- Name: services services_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_pkey PRIMARY KEY (id);


--
-- Name: soft_delete_audit_logs soft_delete_audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.soft_delete_audit_logs
    ADD CONSTRAINT soft_delete_audit_logs_pkey PRIMARY KEY (id);


--
-- Name: support_attachments support_attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.support_attachments
    ADD CONSTRAINT support_attachments_pkey PRIMARY KEY (id);


--
-- Name: support_messages support_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.support_messages
    ADD CONSTRAINT support_messages_pkey PRIMARY KEY (id);


--
-- Name: support_tickets support_tickets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.support_tickets
    ADD CONSTRAINT support_tickets_pkey PRIMARY KEY (id);


--
-- Name: tourist_apartments tourist_apartments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tourist_apartments
    ADD CONSTRAINT tourist_apartments_pkey PRIMARY KEY (id);


--
-- Name: tourist_castles tourist_castles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tourist_castles
    ADD CONSTRAINT tourist_castles_pkey PRIMARY KEY (id);


--
-- Name: tourist_churches tourist_churches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tourist_churches
    ADD CONSTRAINT tourist_churches_pkey PRIMARY KEY (id);


--
-- Name: tourist_events tourist_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tourist_events
    ADD CONSTRAINT tourist_events_pkey PRIMARY KEY (id);


--
-- Name: tourist_excursions tourist_excursions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tourist_excursions
    ADD CONSTRAINT tourist_excursions_pkey PRIMARY KEY (id);


--
-- Name: tourist_hotels tourist_hotels_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tourist_hotels
    ADD CONSTRAINT tourist_hotels_pkey PRIMARY KEY (id);


--
-- Name: tourist_photos tourist_photos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tourist_photos
    ADD CONSTRAINT tourist_photos_pkey PRIMARY KEY (id);


--
-- Name: tourist_refuges tourist_refuges_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tourist_refuges
    ADD CONSTRAINT tourist_refuges_pkey PRIMARY KEY (id);


--
-- Name: tourist_restaurants tourist_restaurants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tourist_restaurants
    ADD CONSTRAINT tourist_restaurants_pkey PRIMARY KEY (id);


--
-- Name: tourist_ski_facilities tourist_ski_facilities_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tourist_ski_facilities
    ADD CONSTRAINT tourist_ski_facilities_pkey PRIMARY KEY (id);


--
-- Name: tourist_sports_facilities tourist_sports_facilities_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tourist_sports_facilities
    ADD CONSTRAINT tourist_sports_facilities_pkey PRIMARY KEY (id);


--
-- Name: tourist_venues tourist_venues_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tourist_venues
    ADD CONSTRAINT tourist_venues_pkey PRIMARY KEY (id);


--
-- Name: tourist_viewpoints tourist_viewpoints_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tourist_viewpoints
    ADD CONSTRAINT tourist_viewpoints_pkey PRIMARY KEY (id);


--
-- Name: two_factor_reset_tokens two_factor_reset_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.two_factor_reset_tokens
    ADD CONSTRAINT two_factor_reset_tokens_pkey PRIMARY KEY (id);


--
-- Name: usage usage_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usage
    ADD CONSTRAINT usage_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: whatsapp_queue whatsapp_queue_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.whatsapp_queue
    ADD CONSTRAINT whatsapp_queue_pkey PRIMARY KEY (id);


--
-- Name: whatsapp_settings whatsapp_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.whatsapp_settings
    ADD CONSTRAINT whatsapp_settings_pkey PRIMARY KEY (id);


--
-- Name: whatsapp_webhook_events whatsapp_webhook_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.whatsapp_webhook_events
    ADD CONSTRAINT whatsapp_webhook_events_pkey PRIMARY KEY (id);


--
-- Name: workspace_business_hours workspace_business_hours_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_business_hours
    ADD CONSTRAINT workspace_business_hours_pkey PRIMARY KEY (id);


--
-- Name: workspace_calling_functions workspace_calling_functions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_calling_functions
    ADD CONSTRAINT workspace_calling_functions_pkey PRIMARY KEY (id);


--
-- Name: workspace_environment_variables workspace_environment_variables_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_environment_variables
    ADD CONSTRAINT workspace_environment_variables_pkey PRIMARY KEY (id);


--
-- Name: workspace_invitations workspace_invitations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_invitations
    ADD CONSTRAINT workspace_invitations_pkey PRIMARY KEY (id);


--
-- Name: Billing_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Billing_createdAt_idx" ON public."Billing" USING btree ("createdAt");


--
-- Name: Billing_customerId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Billing_customerId_idx" ON public."Billing" USING btree ("customerId");


--
-- Name: Billing_type_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Billing_type_idx" ON public."Billing" USING btree (type);


--
-- Name: Billing_workspaceId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Billing_workspaceId_idx" ON public."Billing" USING btree ("workspaceId");


--
-- Name: Certification_workspaceId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Certification_workspaceId_idx" ON public."Certification" USING btree ("workspaceId");


--
-- Name: Certification_workspaceId_name_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Certification_workspaceId_name_key" ON public."Certification" USING btree ("workspaceId", name);


--
-- Name: ProductCategory_categoryId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "ProductCategory_categoryId_idx" ON public."ProductCategory" USING btree ("categoryId");


--
-- Name: ProductCategory_productId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "ProductCategory_productId_idx" ON public."ProductCategory" USING btree ("productId");


--
-- Name: ProductCertification_certificationId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "ProductCertification_certificationId_idx" ON public."ProductCertification" USING btree ("certificationId");


--
-- Name: ProductCharacteristic_name_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "ProductCharacteristic_name_idx" ON public."ProductCharacteristic" USING btree (name);


--
-- Name: ProductCharacteristic_productId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "ProductCharacteristic_productId_idx" ON public."ProductCharacteristic" USING btree ("productId");


--
-- Name: ProductType_productId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "ProductType_productId_idx" ON public."ProductType" USING btree ("productId");


--
-- Name: ProductType_typeId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "ProductType_typeId_idx" ON public."ProductType" USING btree ("typeId");


--
-- Name: ShortUrls_expiresAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "ShortUrls_expiresAt_idx" ON public."ShortUrls" USING btree ("expiresAt");


--
-- Name: ShortUrls_shortCode_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "ShortUrls_shortCode_idx" ON public."ShortUrls" USING btree ("shortCode");


--
-- Name: ShortUrls_shortCode_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "ShortUrls_shortCode_key" ON public."ShortUrls" USING btree ("shortCode");


--
-- Name: ShortUrls_workspaceId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "ShortUrls_workspaceId_idx" ON public."ShortUrls" USING btree ("workspaceId");


--
-- Name: Type_isActive_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Type_isActive_idx" ON public."Type" USING btree ("isActive");


--
-- Name: Type_workspaceId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Type_workspaceId_idx" ON public."Type" USING btree ("workspaceId");


--
-- Name: Type_workspaceId_name_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Type_workspaceId_name_key" ON public."Type" USING btree ("workspaceId", name);


--
-- Name: Workspace_deletedAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Workspace_deletedAt_idx" ON public."Workspace" USING btree ("deletedAt");


--
-- Name: Workspace_ownerId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Workspace_ownerId_idx" ON public."Workspace" USING btree ("ownerId");


--
-- Name: Workspace_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Workspace_slug_key" ON public."Workspace" USING btree (slug);


--
-- Name: Workspace_wasenderApiKey_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Workspace_wasenderApiKey_idx" ON public."Workspace" USING btree ("wasenderApiKey");


--
-- Name: _OfferCategories_B_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "_OfferCategories_B_index" ON public."_OfferCategories" USING btree ("B");


--
-- Name: admin_sessions_expiresAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "admin_sessions_expiresAt_idx" ON public.admin_sessions USING btree ("expiresAt");


--
-- Name: admin_sessions_isActive_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "admin_sessions_isActive_idx" ON public.admin_sessions USING btree ("isActive");


--
-- Name: admin_sessions_sessionId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "admin_sessions_sessionId_idx" ON public.admin_sessions USING btree ("sessionId");


--
-- Name: admin_sessions_sessionId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "admin_sessions_sessionId_key" ON public.admin_sessions USING btree ("sessionId");


--
-- Name: admin_sessions_userId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "admin_sessions_userId_idx" ON public.admin_sessions USING btree ("userId");


--
-- Name: agent_configs_order_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_configs_order_idx ON public.agent_configs USING btree ("order");


--
-- Name: agent_configs_workspaceId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "agent_configs_workspaceId_idx" ON public.agent_configs USING btree ("workspaceId");


--
-- Name: agent_configs_workspaceId_type_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "agent_configs_workspaceId_type_key" ON public.agent_configs USING btree ("workspaceId", type);


--
-- Name: agent_conversation_logs_agentType_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "agent_conversation_logs_agentType_idx" ON public.agent_conversation_logs USING btree ("agentType");


--
-- Name: agent_conversation_logs_conversationId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "agent_conversation_logs_conversationId_idx" ON public.agent_conversation_logs USING btree ("conversationId");


--
-- Name: agent_conversation_logs_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "agent_conversation_logs_createdAt_idx" ON public.agent_conversation_logs USING btree ("createdAt");


--
-- Name: agent_conversation_logs_hasError_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "agent_conversation_logs_hasError_idx" ON public.agent_conversation_logs USING btree ("hasError");


--
-- Name: agent_conversation_logs_workspaceId_customerId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "agent_conversation_logs_workspaceId_customerId_idx" ON public.agent_conversation_logs USING btree ("workspaceId", "customerId");


--
-- Name: appointments_customerId_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "appointments_customerId_status_idx" ON public.appointments USING btree ("customerId", status);


--
-- Name: appointments_googleEventId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "appointments_googleEventId_idx" ON public.appointments USING btree ("googleEventId");


--
-- Name: appointments_startTime_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "appointments_startTime_idx" ON public.appointments USING btree ("startTime");


--
-- Name: appointments_workspaceId_startTime_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "appointments_workspaceId_startTime_idx" ON public.appointments USING btree ("workspaceId", "startTime");


--
-- Name: appointments_workspaceId_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "appointments_workspaceId_status_idx" ON public.appointments USING btree ("workspaceId", status);


--
-- Name: appointments_zoomMeetingId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "appointments_zoomMeetingId_idx" ON public.appointments USING btree ("zoomMeetingId");


--
-- Name: authentication_attempts_attemptType_success_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "authentication_attempts_attemptType_success_idx" ON public.authentication_attempts USING btree ("attemptType", success);


--
-- Name: authentication_attempts_email_timestamp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX authentication_attempts_email_timestamp_idx ON public.authentication_attempts USING btree (email, "timestamp");


--
-- Name: authentication_attempts_ipAddress_timestamp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "authentication_attempts_ipAddress_timestamp_idx" ON public.authentication_attempts USING btree ("ipAddress", "timestamp");


--
-- Name: authentication_attempts_timestamp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX authentication_attempts_timestamp_idx ON public.authentication_attempts USING btree ("timestamp");


--
-- Name: billing_transactions_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "billing_transactions_createdAt_idx" ON public.billing_transactions USING btree ("createdAt");


--
-- Name: billing_transactions_type_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX billing_transactions_type_idx ON public.billing_transactions USING btree (type);


--
-- Name: billing_transactions_userId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "billing_transactions_userId_idx" ON public.billing_transactions USING btree ("userId");


--
-- Name: billing_transactions_workspaceId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "billing_transactions_workspaceId_idx" ON public.billing_transactions USING btree ("workspaceId");


--
-- Name: blackout_periods_workspaceId_startDate_endDate_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "blackout_periods_workspaceId_startDate_endDate_idx" ON public.blackout_periods USING btree ("workspaceId", "startDate", "endDate");


--
-- Name: cart_items_cartId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "cart_items_cartId_idx" ON public.cart_items USING btree ("cartId");


--
-- Name: carts_customerId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "carts_customerId_key" ON public.carts USING btree ("customerId");


--
-- Name: categories_slug_workspaceId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "categories_slug_workspaceId_key" ON public.categories USING btree (slug, "workspaceId");


--
-- Name: chat_sessions_channel_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX chat_sessions_channel_idx ON public.chat_sessions USING btree (channel);


--
-- Name: chat_sessions_customerId_status_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "chat_sessions_customerId_status_key" ON public.chat_sessions USING btree ("customerId", status);


--
-- Name: chat_sessions_deletedAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "chat_sessions_deletedAt_idx" ON public.chat_sessions USING btree ("deletedAt");


--
-- Name: chat_sessions_expiresAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "chat_sessions_expiresAt_idx" ON public.chat_sessions USING btree ("expiresAt");


--
-- Name: chat_sessions_visitorId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "chat_sessions_visitorId_idx" ON public.chat_sessions USING btree ("visitorId");


--
-- Name: chat_sessions_workspaceId_deletedAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "chat_sessions_workspaceId_deletedAt_idx" ON public.chat_sessions USING btree ("workspaceId", "deletedAt");


--
-- Name: conversation_messages_conversationId_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "conversation_messages_conversationId_createdAt_idx" ON public.conversation_messages USING btree ("conversationId", "createdAt");


--
-- Name: conversation_messages_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "conversation_messages_createdAt_idx" ON public.conversation_messages USING btree ("createdAt");


--
-- Name: conversation_messages_whatsappMessageId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "conversation_messages_whatsappMessageId_idx" ON public.conversation_messages USING btree ("whatsappMessageId");


--
-- Name: conversation_messages_workspaceId_customerId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "conversation_messages_workspaceId_customerId_idx" ON public.conversation_messages USING btree ("workspaceId", "customerId");


--
-- Name: credit_notes_creditNoteCode_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "credit_notes_creditNoteCode_key" ON public.credit_notes USING btree ("creditNoteCode");


--
-- Name: credit_notes_orderId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "credit_notes_orderId_idx" ON public.credit_notes USING btree ("orderId");


--
-- Name: customer_feedback_customerId_stayKey_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "customer_feedback_customerId_stayKey_key" ON public.customer_feedback USING btree ("customerId", "stayKey");


--
-- Name: customer_feedback_workspaceId_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "customer_feedback_workspaceId_createdAt_idx" ON public.customer_feedback USING btree ("workspaceId", "createdAt");


--
-- Name: customers_customId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "customers_customId_key" ON public.customers USING btree ("customId");


--
-- Name: customers_deletedAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "customers_deletedAt_idx" ON public.customers USING btree ("deletedAt");


--
-- Name: customers_phone_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX customers_phone_idx ON public.customers USING btree (phone);


--
-- Name: customers_workspaceId_deletedAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "customers_workspaceId_deletedAt_idx" ON public.customers USING btree ("workspaceId", "deletedAt");


--
-- Name: customers_workspaceId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "customers_workspaceId_idx" ON public.customers USING btree ("workspaceId");


--
-- Name: customers_workspaceId_phone_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "customers_workspaceId_phone_key" ON public.customers USING btree ("workspaceId", phone);


--
-- Name: demorobot_assets_flowCategoryId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "demorobot_assets_flowCategoryId_idx" ON public.demorobot_assets USING btree ("flowCategoryId");


--
-- Name: demorobot_flow_edges_sourceNodeId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "demorobot_flow_edges_sourceNodeId_idx" ON public.demorobot_flow_edges USING btree ("sourceNodeId");


--
-- Name: demorobot_flow_edges_targetFlowId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "demorobot_flow_edges_targetFlowId_idx" ON public.demorobot_flow_edges USING btree ("targetFlowId");


--
-- Name: demorobot_flow_edges_targetNodeId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "demorobot_flow_edges_targetNodeId_idx" ON public.demorobot_flow_edges USING btree ("targetNodeId");


--
-- Name: demorobot_flow_node_attachments_assetId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "demorobot_flow_node_attachments_assetId_idx" ON public.demorobot_flow_node_attachments USING btree ("assetId");


--
-- Name: demorobot_flow_node_attachments_nodeId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "demorobot_flow_node_attachments_nodeId_idx" ON public.demorobot_flow_node_attachments USING btree ("nodeId");


--
-- Name: demorobot_flow_nodes_flowId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "demorobot_flow_nodes_flowId_idx" ON public.demorobot_flow_nodes USING btree ("flowId");


--
-- Name: demorobot_flows_flowCategoryId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "demorobot_flows_flowCategoryId_idx" ON public.demorobot_flows USING btree ("flowCategoryId");


--
-- Name: demorobot_flows_workspaceId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "demorobot_flows_workspaceId_idx" ON public.demorobot_flows USING btree ("workspaceId");


--
-- Name: faqs_category_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX faqs_category_idx ON public.faqs USING btree (category);


--
-- Name: faqs_keywords_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX faqs_keywords_idx ON public.faqs USING btree (keywords);


--
-- Name: faqs_workspaceId_isActive_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "faqs_workspaceId_isActive_idx" ON public.faqs USING btree ("workspaceId", "isActive");


--
-- Name: flow_categories_workspaceId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "flow_categories_workspaceId_idx" ON public.flow_categories USING btree ("workspaceId");


--
-- Name: flow_categories_workspaceId_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "flow_categories_workspaceId_slug_key" ON public.flow_categories USING btree ("workspaceId", slug);


--
-- Name: flow_node_configs_workspaceId_flowKey_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "flow_node_configs_workspaceId_flowKey_key" ON public.flow_node_configs USING btree ("workspaceId", "flowKey");


--
-- Name: flow_node_configs_workspaceId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "flow_node_configs_workspaceId_idx" ON public.flow_node_configs USING btree ("workspaceId");


--
-- Name: gdpr_content_workspaceId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "gdpr_content_workspaceId_key" ON public.gdpr_content USING btree ("workspaceId");


--
-- Name: google_calendar_connections_workspaceId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "google_calendar_connections_workspaceId_idx" ON public.google_calendar_connections USING btree ("workspaceId");


--
-- Name: google_calendar_connections_workspaceId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "google_calendar_connections_workspaceId_key" ON public.google_calendar_connections USING btree ("workspaceId");


--
-- Name: idx_chat_session_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_chat_session_created ON public.chat_sessions USING btree ("createdAt");


--
-- Name: idx_customer_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_customer_status ON public.chat_sessions USING btree ("customerId", status);


--
-- Name: idx_direction_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_direction_created ON public.messages USING btree (direction, "createdAt");


--
-- Name: idx_message_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_message_created ON public.messages USING btree ("createdAt");


--
-- Name: idx_msg_session_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_msg_session_created ON public.messages USING btree ("chatSessionId", "createdAt");


--
-- Name: idx_session_direction; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_session_direction ON public.messages USING btree ("chatSessionId", direction);


--
-- Name: idx_workspace; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_workspace ON public.chat_sessions USING btree ("workspaceId");


--
-- Name: idx_workspace_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_workspace_created ON public.chat_sessions USING btree ("workspaceId", "createdAt");


--
-- Name: idx_workspace_customer; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_workspace_customer ON public.chat_sessions USING btree ("workspaceId", "customerId");


--
-- Name: invoice_adjustments_invoiceId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "invoice_adjustments_invoiceId_idx" ON public.invoice_adjustments USING btree ("invoiceId");


--
-- Name: invoice_adjustments_userId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "invoice_adjustments_userId_idx" ON public.invoice_adjustments USING btree ("userId");


--
-- Name: invoice_credit_notes_invoiceId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "invoice_credit_notes_invoiceId_idx" ON public.invoice_credit_notes USING btree ("invoiceId");


--
-- Name: invoice_credit_notes_userId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "invoice_credit_notes_userId_idx" ON public.invoice_credit_notes USING btree ("userId");


--
-- Name: late_cancellation_attempts_attemptedAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "late_cancellation_attempts_attemptedAt_idx" ON public.late_cancellation_attempts USING btree ("attemptedAt");


--
-- Name: late_cancellation_attempts_workspaceId_customerId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "late_cancellation_attempts_workspaceId_customerId_idx" ON public.late_cancellation_attempts USING btree ("workspaceId", "customerId");


--
-- Name: merchant_pushes_workspaceId_merchantId_isActive_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "merchant_pushes_workspaceId_merchantId_isActive_idx" ON public.merchant_pushes USING btree ("workspaceId", "merchantId", "isActive");


--
-- Name: merchant_quota_topups_workspaceId_merchantId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "merchant_quota_topups_workspaceId_merchantId_idx" ON public.merchant_quota_topups USING btree ("workspaceId", "merchantId");


--
-- Name: merchants_workspaceId_isActive_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "merchants_workspaceId_isActive_idx" ON public.merchants USING btree ("workspaceId", "isActive");


--
-- Name: message_attachments_conversationMessageId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "message_attachments_conversationMessageId_idx" ON public.message_attachments USING btree ("conversationMessageId");


--
-- Name: message_attachments_workspaceId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "message_attachments_workspaceId_idx" ON public.message_attachments USING btree ("workspaceId");


--
-- Name: messages_archive_archivedAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "messages_archive_archivedAt_idx" ON public.messages_archive USING btree ("archivedAt");


--
-- Name: messages_archive_chatSessionId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "messages_archive_chatSessionId_idx" ON public.messages_archive USING btree ("chatSessionId");


--
-- Name: messages_archive_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "messages_archive_createdAt_idx" ON public.messages_archive USING btree ("createdAt");


--
-- Name: messages_archive_customerId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "messages_archive_customerId_idx" ON public.messages_archive USING btree ("customerId");


--
-- Name: messages_archive_originalId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "messages_archive_originalId_idx" ON public.messages_archive USING btree ("originalId");


--
-- Name: messages_archive_workspaceId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "messages_archive_workspaceId_idx" ON public.messages_archive USING btree ("workspaceId");


--
-- Name: messages_chatSessionId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "messages_chatSessionId_idx" ON public.messages USING btree ("chatSessionId");


--
-- Name: messages_deletedAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "messages_deletedAt_idx" ON public.messages USING btree ("deletedAt");


--
-- Name: messages_sentBy_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "messages_sentBy_idx" ON public.messages USING btree ("sentBy");


--
-- Name: messages_whatsappMessageId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "messages_whatsappMessageId_idx" ON public.messages USING btree ("whatsappMessageId");


--
-- Name: messages_whatsappStatus_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "messages_whatsappStatus_idx" ON public.messages USING btree ("whatsappStatus");


--
-- Name: monthly_invoices_invoiceNumber_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "monthly_invoices_invoiceNumber_key" ON public.monthly_invoices USING btree ("invoiceNumber");


--
-- Name: monthly_invoices_periodYear_periodMonth_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "monthly_invoices_periodYear_periodMonth_idx" ON public.monthly_invoices USING btree ("periodYear", "periodMonth");


--
-- Name: monthly_invoices_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX monthly_invoices_status_idx ON public.monthly_invoices USING btree (status);


--
-- Name: monthly_invoices_userId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "monthly_invoices_userId_idx" ON public.monthly_invoices USING btree ("userId");


--
-- Name: monthly_invoices_userId_periodYear_periodMonth_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "monthly_invoices_userId_periodYear_periodMonth_key" ON public.monthly_invoices USING btree ("userId", "periodYear", "periodMonth");


--
-- Name: offers_workspaceId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "offers_workspaceId_idx" ON public.offers USING btree ("workspaceId");


--
-- Name: order_items_deletedAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "order_items_deletedAt_idx" ON public.order_items USING btree ("deletedAt");


--
-- Name: order_items_orderId_deletedAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "order_items_orderId_deletedAt_idx" ON public.order_items USING btree ("orderId", "deletedAt");


--
-- Name: order_items_orderId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "order_items_orderId_idx" ON public.order_items USING btree ("orderId");


--
-- Name: orders_customerId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "orders_customerId_idx" ON public.orders USING btree ("customerId");


--
-- Name: orders_deletedAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "orders_deletedAt_idx" ON public.orders USING btree ("deletedAt");


--
-- Name: orders_invoiceKey_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "orders_invoiceKey_idx" ON public.orders USING btree ("invoiceKey");


--
-- Name: orders_orderCode_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "orders_orderCode_key" ON public.orders USING btree ("orderCode");


--
-- Name: orders_workspaceId_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "orders_workspaceId_createdAt_idx" ON public.orders USING btree ("workspaceId", "createdAt");


--
-- Name: orders_workspaceId_deletedAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "orders_workspaceId_deletedAt_idx" ON public.orders USING btree ("workspaceId", "deletedAt");


--
-- Name: orders_workspaceId_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "orders_workspaceId_status_idx" ON public.orders USING btree ("workspaceId", status);


--
-- Name: password_resets_token_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX password_resets_token_key ON public.password_resets USING btree (token);


--
-- Name: payment_details_orderId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "payment_details_orderId_key" ON public.payment_details USING btree ("orderId");


--
-- Name: paypal_transactions_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "paypal_transactions_createdAt_idx" ON public.paypal_transactions USING btree ("createdAt");


--
-- Name: paypal_transactions_invoiceId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "paypal_transactions_invoiceId_idx" ON public.paypal_transactions USING btree ("invoiceId");


--
-- Name: paypal_transactions_paypalOrderId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "paypal_transactions_paypalOrderId_key" ON public.paypal_transactions USING btree ("paypalOrderId");


--
-- Name: paypal_transactions_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX paypal_transactions_status_idx ON public.paypal_transactions USING btree (status);


--
-- Name: paypal_transactions_userId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "paypal_transactions_userId_idx" ON public.paypal_transactions USING btree ("userId");


--
-- Name: paypal_webhook_events_eventId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "paypal_webhook_events_eventId_key" ON public.paypal_webhook_events USING btree ("eventId");


--
-- Name: paypal_webhook_events_receivedAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "paypal_webhook_events_receivedAt_idx" ON public.paypal_webhook_events USING btree ("receivedAt");


--
-- Name: plan_configurations_isActive_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "plan_configurations_isActive_idx" ON public.plan_configurations USING btree ("isActive");


--
-- Name: plan_configurations_planType_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "plan_configurations_planType_idx" ON public.plan_configurations USING btree ("planType");


--
-- Name: plan_configurations_planType_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "plan_configurations_planType_key" ON public.plan_configurations USING btree ("planType");


--
-- Name: platform_config_isActive_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "platform_config_isActive_idx" ON public.platform_config USING btree ("isActive");


--
-- Name: platform_config_key_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX platform_config_key_idx ON public.platform_config USING btree (key);


--
-- Name: platform_config_key_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX platform_config_key_key ON public.platform_config USING btree (key);


--
-- Name: platform_config_type_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX platform_config_type_idx ON public.platform_config USING btree (type);


--
-- Name: playground_comments_todoId_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "playground_comments_todoId_createdAt_idx" ON public.playground_comments USING btree ("todoId", "createdAt");


--
-- Name: playground_todos_dialogId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "playground_todos_dialogId_idx" ON public.playground_todos USING btree ("dialogId");


--
-- Name: playground_todos_workspaceId_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "playground_todos_workspaceId_status_idx" ON public.playground_todos USING btree ("workspaceId", status);


--
-- Name: products_allergens_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX products_allergens_idx ON public.products USING btree (allergens);


--
-- Name: products_imageKey_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "products_imageKey_idx" ON public.products USING btree ("imageKey");


--
-- Name: products_slug_workspaceId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "products_slug_workspaceId_key" ON public.products USING btree (slug, "workspaceId");


--
-- Name: products_workspaceId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "products_workspaceId_idx" ON public.products USING btree ("workspaceId");


--
-- Name: products_workspaceId_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "products_workspaceId_status_idx" ON public.products USING btree ("workspaceId", status);


--
-- Name: push_campaign_recipients_campaignId_customerId_stayKey_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "push_campaign_recipients_campaignId_customerId_stayKey_key" ON public.push_campaign_recipients USING btree ("campaignId", "customerId", "stayKey");


--
-- Name: push_campaign_recipients_campaignId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "push_campaign_recipients_campaignId_idx" ON public.push_campaign_recipients USING btree ("campaignId");


--
-- Name: push_campaign_recipients_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX push_campaign_recipients_status_idx ON public.push_campaign_recipients USING btree (status);


--
-- Name: push_campaign_recipients_workspaceId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "push_campaign_recipients_workspaceId_idx" ON public.push_campaign_recipients USING btree ("workspaceId");


--
-- Name: push_campaigns_nextRunAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "push_campaigns_nextRunAt_idx" ON public.push_campaigns USING btree ("nextRunAt");


--
-- Name: push_campaigns_sendAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "push_campaigns_sendAt_idx" ON public.push_campaigns USING btree ("sendAt");


--
-- Name: push_campaigns_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX push_campaigns_status_idx ON public.push_campaigns USING btree (status);


--
-- Name: push_campaigns_workspaceId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "push_campaigns_workspaceId_idx" ON public.push_campaigns USING btree ("workspaceId");


--
-- Name: push_campaigns_workspaceId_merchantId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "push_campaigns_workspaceId_merchantId_idx" ON public.push_campaigns USING btree ("workspaceId", "merchantId");


--
-- Name: registration_tokens_token_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX registration_tokens_token_key ON public.registration_tokens USING btree (token);


--
-- Name: reminder_locks_appointmentId_reminderType_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "reminder_locks_appointmentId_reminderType_key" ON public.reminder_locks USING btree ("appointmentId", "reminderType");


--
-- Name: reminder_locks_expiresAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "reminder_locks_expiresAt_idx" ON public.reminder_locks USING btree ("expiresAt");


--
-- Name: reminder_locks_lockKey_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "reminder_locks_lockKey_key" ON public.reminder_locks USING btree ("lockKey");


--
-- Name: scheduler_job_status_jobName_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "scheduler_job_status_jobName_key" ON public.scheduler_job_status USING btree ("jobName");


--
-- Name: search_conversations_customerId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "search_conversations_customerId_idx" ON public.search_conversations USING btree ("customerId");


--
-- Name: search_conversations_expiresAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "search_conversations_expiresAt_idx" ON public.search_conversations USING btree ("expiresAt");


--
-- Name: search_conversations_sessionId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "search_conversations_sessionId_idx" ON public.search_conversations USING btree ("sessionId");


--
-- Name: search_conversations_sessionId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "search_conversations_sessionId_key" ON public.search_conversations USING btree ("sessionId");


--
-- Name: secure_tokens_customerId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "secure_tokens_customerId_idx" ON public.secure_tokens USING btree ("customerId");


--
-- Name: secure_tokens_expiresAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "secure_tokens_expiresAt_idx" ON public.secure_tokens USING btree ("expiresAt");


--
-- Name: secure_tokens_token_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX secure_tokens_token_idx ON public.secure_tokens USING btree (token);


--
-- Name: secure_tokens_token_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX secure_tokens_token_key ON public.secure_tokens USING btree (token);


--
-- Name: secure_tokens_workspaceId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "secure_tokens_workspaceId_idx" ON public.secure_tokens USING btree ("workspaceId");


--
-- Name: services_code_workspaceId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "services_code_workspaceId_key" ON public.services USING btree (code, "workspaceId");


--
-- Name: services_imageKey_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "services_imageKey_idx" ON public.services USING btree ("imageKey");


--
-- Name: services_workspaceId_enableForBooking_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "services_workspaceId_enableForBooking_idx" ON public.services USING btree ("workspaceId", "enableForBooking");


--
-- Name: services_workspaceId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "services_workspaceId_idx" ON public.services USING btree ("workspaceId");


--
-- Name: soft_delete_audit_logs_deletedAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "soft_delete_audit_logs_deletedAt_idx" ON public.soft_delete_audit_logs USING btree ("deletedAt");


--
-- Name: soft_delete_audit_logs_workspaceId_deletedAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "soft_delete_audit_logs_workspaceId_deletedAt_idx" ON public.soft_delete_audit_logs USING btree ("workspaceId", "deletedAt");


--
-- Name: support_attachments_messageId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "support_attachments_messageId_idx" ON public.support_attachments USING btree ("messageId");


--
-- Name: support_messages_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "support_messages_createdAt_idx" ON public.support_messages USING btree ("createdAt");


--
-- Name: support_messages_senderId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "support_messages_senderId_idx" ON public.support_messages USING btree ("senderId");


--
-- Name: support_messages_ticketId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "support_messages_ticketId_idx" ON public.support_messages USING btree ("ticketId");


--
-- Name: support_tickets_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "support_tickets_createdAt_idx" ON public.support_tickets USING btree ("createdAt");


--
-- Name: support_tickets_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX support_tickets_status_idx ON public.support_tickets USING btree (status);


--
-- Name: support_tickets_ticketCode_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "support_tickets_ticketCode_key" ON public.support_tickets USING btree ("ticketCode");


--
-- Name: support_tickets_userId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "support_tickets_userId_idx" ON public.support_tickets USING btree ("userId");


--
-- Name: support_tickets_workspaceId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "support_tickets_workspaceId_idx" ON public.support_tickets USING btree ("workspaceId");


--
-- Name: tourist_apartments_workspaceId_isActive_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "tourist_apartments_workspaceId_isActive_idx" ON public.tourist_apartments USING btree ("workspaceId", "isActive");


--
-- Name: tourist_castles_workspaceId_isActive_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "tourist_castles_workspaceId_isActive_idx" ON public.tourist_castles USING btree ("workspaceId", "isActive");


--
-- Name: tourist_churches_workspaceId_isActive_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "tourist_churches_workspaceId_isActive_idx" ON public.tourist_churches USING btree ("workspaceId", "isActive");


--
-- Name: tourist_events_workspaceId_isActive_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "tourist_events_workspaceId_isActive_idx" ON public.tourist_events USING btree ("workspaceId", "isActive");


--
-- Name: tourist_excursions_workspaceId_isActive_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "tourist_excursions_workspaceId_isActive_idx" ON public.tourist_excursions USING btree ("workspaceId", "isActive");


--
-- Name: tourist_hotels_workspaceId_isActive_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "tourist_hotels_workspaceId_isActive_idx" ON public.tourist_hotels USING btree ("workspaceId", "isActive");


--
-- Name: tourist_photos_workspaceId_contentType_contentId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "tourist_photos_workspaceId_contentType_contentId_idx" ON public.tourist_photos USING btree ("workspaceId", "contentType", "contentId");


--
-- Name: tourist_refuges_workspaceId_isActive_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "tourist_refuges_workspaceId_isActive_idx" ON public.tourist_refuges USING btree ("workspaceId", "isActive");


--
-- Name: tourist_restaurants_workspaceId_isActive_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "tourist_restaurants_workspaceId_isActive_idx" ON public.tourist_restaurants USING btree ("workspaceId", "isActive");


--
-- Name: tourist_ski_facilities_workspaceId_isActive_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "tourist_ski_facilities_workspaceId_isActive_idx" ON public.tourist_ski_facilities USING btree ("workspaceId", "isActive");


--
-- Name: tourist_sports_facilities_workspaceId_isActive_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "tourist_sports_facilities_workspaceId_isActive_idx" ON public.tourist_sports_facilities USING btree ("workspaceId", "isActive");


--
-- Name: tourist_venues_workspaceId_isActive_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "tourist_venues_workspaceId_isActive_idx" ON public.tourist_venues USING btree ("workspaceId", "isActive");


--
-- Name: tourist_viewpoints_workspaceId_isActive_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "tourist_viewpoints_workspaceId_isActive_idx" ON public.tourist_viewpoints USING btree ("workspaceId", "isActive");


--
-- Name: two_factor_reset_tokens_expiresAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "two_factor_reset_tokens_expiresAt_idx" ON public.two_factor_reset_tokens USING btree ("expiresAt");


--
-- Name: two_factor_reset_tokens_token_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX two_factor_reset_tokens_token_idx ON public.two_factor_reset_tokens USING btree (token);


--
-- Name: two_factor_reset_tokens_token_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX two_factor_reset_tokens_token_key ON public.two_factor_reset_tokens USING btree (token);


--
-- Name: two_factor_reset_tokens_userId_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "two_factor_reset_tokens_userId_createdAt_idx" ON public.two_factor_reset_tokens USING btree ("userId", "createdAt");


--
-- Name: unique_customer_token_non_null; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX unique_customer_token_non_null ON public.secure_tokens USING btree ("customerId", type, "workspaceId");


--
-- Name: usage_clientId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "usage_clientId_idx" ON public.usage USING btree ("clientId");


--
-- Name: usage_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "usage_createdAt_idx" ON public.usage USING btree ("createdAt");


--
-- Name: usage_workspaceId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "usage_workspaceId_idx" ON public.usage USING btree ("workspaceId");


--
-- Name: users_deletedAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "users_deletedAt_idx" ON public.users USING btree ("deletedAt");


--
-- Name: users_email_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX users_email_key ON public.users USING btree (email);


--
-- Name: users_planType_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "users_planType_idx" ON public.users USING btree ("planType");


--
-- Name: users_subscriptionStatus_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "users_subscriptionStatus_idx" ON public.users USING btree ("subscriptionStatus");


--
-- Name: whatsapp_queue_conversationMessageId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "whatsapp_queue_conversationMessageId_idx" ON public.whatsapp_queue USING btree ("conversationMessageId");


--
-- Name: whatsapp_queue_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "whatsapp_queue_createdAt_idx" ON public.whatsapp_queue USING btree ("createdAt");


--
-- Name: whatsapp_queue_customerId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "whatsapp_queue_customerId_idx" ON public.whatsapp_queue USING btree ("customerId");


--
-- Name: whatsapp_queue_expiresAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "whatsapp_queue_expiresAt_idx" ON public.whatsapp_queue USING btree ("expiresAt");


--
-- Name: whatsapp_queue_pushCampaignRecipientId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "whatsapp_queue_pushCampaignRecipientId_key" ON public.whatsapp_queue USING btree ("pushCampaignRecipientId");


--
-- Name: whatsapp_queue_visitorId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "whatsapp_queue_visitorId_idx" ON public.whatsapp_queue USING btree ("visitorId");


--
-- Name: whatsapp_queue_workspaceId_channel_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "whatsapp_queue_workspaceId_channel_idx" ON public.whatsapp_queue USING btree ("workspaceId", channel);


--
-- Name: whatsapp_queue_workspaceId_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "whatsapp_queue_workspaceId_status_idx" ON public.whatsapp_queue USING btree ("workspaceId", status);


--
-- Name: whatsapp_settings_phoneNumber_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "whatsapp_settings_phoneNumber_key" ON public.whatsapp_settings USING btree ("phoneNumber");


--
-- Name: whatsapp_settings_webhookId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "whatsapp_settings_webhookId_key" ON public.whatsapp_settings USING btree ("webhookId");


--
-- Name: whatsapp_settings_workspaceId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "whatsapp_settings_workspaceId_key" ON public.whatsapp_settings USING btree ("workspaceId");


--
-- Name: whatsapp_webhook_events_receivedAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "whatsapp_webhook_events_receivedAt_idx" ON public.whatsapp_webhook_events USING btree ("receivedAt");


--
-- Name: whatsapp_webhook_events_workspaceId_channel_externalMessage_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "whatsapp_webhook_events_workspaceId_channel_externalMessage_key" ON public.whatsapp_webhook_events USING btree ("workspaceId", channel, "externalMessageId");


--
-- Name: whatsapp_webhook_events_workspaceId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "whatsapp_webhook_events_workspaceId_idx" ON public.whatsapp_webhook_events USING btree ("workspaceId");


--
-- Name: workspace_business_hours_workspaceId_dayOfWeek_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "workspace_business_hours_workspaceId_dayOfWeek_key" ON public.workspace_business_hours USING btree ("workspaceId", "dayOfWeek");


--
-- Name: workspace_business_hours_workspaceId_isActive_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "workspace_business_hours_workspaceId_isActive_idx" ON public.workspace_business_hours USING btree ("workspaceId", "isActive");


--
-- Name: workspace_calling_functions_workspaceId_functionName_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "workspace_calling_functions_workspaceId_functionName_key" ON public.workspace_calling_functions USING btree ("workspaceId", "functionName");


--
-- Name: workspace_calling_functions_workspaceId_isActive_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "workspace_calling_functions_workspaceId_isActive_idx" ON public.workspace_calling_functions USING btree ("workspaceId", "isActive");


--
-- Name: workspace_environment_variables_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "workspace_environment_variables_createdAt_idx" ON public.workspace_environment_variables USING btree ("createdAt");


--
-- Name: workspace_environment_variables_workspaceId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "workspace_environment_variables_workspaceId_idx" ON public.workspace_environment_variables USING btree ("workspaceId");


--
-- Name: workspace_environment_variables_workspaceId_variableName_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "workspace_environment_variables_workspaceId_variableName_key" ON public.workspace_environment_variables USING btree ("workspaceId", "variableName");


--
-- Name: workspace_invitations_email_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX workspace_invitations_email_idx ON public.workspace_invitations USING btree (email);


--
-- Name: workspace_invitations_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX workspace_invitations_status_idx ON public.workspace_invitations USING btree (status);


--
-- Name: workspace_invitations_tokenHash_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "workspace_invitations_tokenHash_idx" ON public.workspace_invitations USING btree ("tokenHash");


--
-- Name: workspace_invitations_tokenHash_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "workspace_invitations_tokenHash_key" ON public.workspace_invitations USING btree ("tokenHash");


--
-- Name: workspace_invitations_workspaceId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "workspace_invitations_workspaceId_idx" ON public.workspace_invitations USING btree ("workspaceId");


--
-- Name: Billing Billing_customerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Billing"
    ADD CONSTRAINT "Billing_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES public.customers(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Billing Billing_workspaceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Billing"
    ADD CONSTRAINT "Billing_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES public."Workspace"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Certification Certification_workspaceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Certification"
    ADD CONSTRAINT "Certification_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES public."Workspace"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ProductCategory ProductCategory_categoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ProductCategory"
    ADD CONSTRAINT "ProductCategory_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES public.categories(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ProductCategory ProductCategory_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ProductCategory"
    ADD CONSTRAINT "ProductCategory_productId_fkey" FOREIGN KEY ("productId") REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ProductCertification ProductCertification_certificationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ProductCertification"
    ADD CONSTRAINT "ProductCertification_certificationId_fkey" FOREIGN KEY ("certificationId") REFERENCES public."Certification"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ProductCertification ProductCertification_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ProductCertification"
    ADD CONSTRAINT "ProductCertification_productId_fkey" FOREIGN KEY ("productId") REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ProductCharacteristic ProductCharacteristic_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ProductCharacteristic"
    ADD CONSTRAINT "ProductCharacteristic_productId_fkey" FOREIGN KEY ("productId") REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ProductType ProductType_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ProductType"
    ADD CONSTRAINT "ProductType_productId_fkey" FOREIGN KEY ("productId") REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ProductType ProductType_typeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ProductType"
    ADD CONSTRAINT "ProductType_typeId_fkey" FOREIGN KEY ("typeId") REFERENCES public."Type"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ShortUrls ShortUrls_workspaceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ShortUrls"
    ADD CONSTRAINT "ShortUrls_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES public."Workspace"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Type Type_workspaceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Type"
    ADD CONSTRAINT "Type_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES public."Workspace"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: UserWorkspace UserWorkspace_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."UserWorkspace"
    ADD CONSTRAINT "UserWorkspace_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: UserWorkspace UserWorkspace_workspaceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."UserWorkspace"
    ADD CONSTRAINT "UserWorkspace_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES public."Workspace"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Workspace Workspace_ownerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Workspace"
    ADD CONSTRAINT "Workspace_ownerId_fkey" FOREIGN KEY ("ownerId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: _OfferCategories _OfferCategories_A_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."_OfferCategories"
    ADD CONSTRAINT "_OfferCategories_A_fkey" FOREIGN KEY ("A") REFERENCES public.categories(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: _OfferCategories _OfferCategories_B_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."_OfferCategories"
    ADD CONSTRAINT "_OfferCategories_B_fkey" FOREIGN KEY ("B") REFERENCES public.offers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: admin_sessions admin_sessions_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_sessions
    ADD CONSTRAINT "admin_sessions_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: admin_sessions admin_sessions_workspaceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_sessions
    ADD CONSTRAINT "admin_sessions_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES public."Workspace"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: agent_configs agent_configs_workspaceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_configs
    ADD CONSTRAINT "agent_configs_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES public."Workspace"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: agent_conversation_logs agent_conversation_logs_customerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_conversation_logs
    ADD CONSTRAINT "agent_conversation_logs_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES public.customers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: agent_conversation_logs agent_conversation_logs_workspaceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_conversation_logs
    ADD CONSTRAINT "agent_conversation_logs_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES public."Workspace"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: appointments appointments_customerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT "appointments_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES public.customers(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: appointments appointments_serviceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT "appointments_serviceId_fkey" FOREIGN KEY ("serviceId") REFERENCES public.services(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: appointments appointments_workspaceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT "appointments_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES public."Workspace"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: authentication_attempts authentication_attempts_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.authentication_attempts
    ADD CONSTRAINT "authentication_attempts_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: billing_transactions billing_transactions_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.billing_transactions
    ADD CONSTRAINT "billing_transactions_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: billing_transactions billing_transactions_workspaceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.billing_transactions
    ADD CONSTRAINT "billing_transactions_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES public."Workspace"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: blackout_periods blackout_periods_workspaceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.blackout_periods
    ADD CONSTRAINT "blackout_periods_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES public."Workspace"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: cart_items cart_items_cartId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cart_items
    ADD CONSTRAINT "cart_items_cartId_fkey" FOREIGN KEY ("cartId") REFERENCES public.carts(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: cart_items cart_items_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cart_items
    ADD CONSTRAINT "cart_items_productId_fkey" FOREIGN KEY ("productId") REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: cart_items cart_items_serviceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cart_items
    ADD CONSTRAINT "cart_items_serviceId_fkey" FOREIGN KEY ("serviceId") REFERENCES public.services(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: carts carts_customerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.carts
    ADD CONSTRAINT "carts_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES public.customers(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: carts carts_workspaceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.carts
    ADD CONSTRAINT "carts_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES public."Workspace"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: categories categories_workspaceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT "categories_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES public."Workspace"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: chat_sessions chat_sessions_customerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_sessions
    ADD CONSTRAINT "chat_sessions_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES public.customers(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: chat_sessions chat_sessions_workspaceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_sessions
    ADD CONSTRAINT "chat_sessions_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES public."Workspace"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: conversation_messages conversation_messages_customerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversation_messages
    ADD CONSTRAINT "conversation_messages_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES public.customers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: conversation_messages conversation_messages_workspaceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversation_messages
    ADD CONSTRAINT "conversation_messages_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES public."Workspace"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: credit_notes credit_notes_orderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_notes
    ADD CONSTRAINT "credit_notes_orderId_fkey" FOREIGN KEY ("orderId") REFERENCES public.orders(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: customer_feedback customer_feedback_customerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_feedback
    ADD CONSTRAINT "customer_feedback_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES public.customers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: customer_feedback customer_feedback_workspaceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_feedback
    ADD CONSTRAINT "customer_feedback_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES public."Workspace"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: customers customers_salesId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT "customers_salesId_fkey" FOREIGN KEY ("salesId") REFERENCES public.sales(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: customers customers_workspaceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT "customers_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES public."Workspace"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: demorobot_assets demorobot_assets_flowCategoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.demorobot_assets
    ADD CONSTRAINT "demorobot_assets_flowCategoryId_fkey" FOREIGN KEY ("flowCategoryId") REFERENCES public.flow_categories(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: demorobot_flow_edges demorobot_flow_edges_sourceNodeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.demorobot_flow_edges
    ADD CONSTRAINT "demorobot_flow_edges_sourceNodeId_fkey" FOREIGN KEY ("sourceNodeId") REFERENCES public.demorobot_flow_nodes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: demorobot_flow_edges demorobot_flow_edges_targetFlowId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.demorobot_flow_edges
    ADD CONSTRAINT "demorobot_flow_edges_targetFlowId_fkey" FOREIGN KEY ("targetFlowId") REFERENCES public.demorobot_flows(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: demorobot_flow_node_attachments demorobot_flow_node_attachments_assetId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.demorobot_flow_node_attachments
    ADD CONSTRAINT "demorobot_flow_node_attachments_assetId_fkey" FOREIGN KEY ("assetId") REFERENCES public.demorobot_assets(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: demorobot_flow_node_attachments demorobot_flow_node_attachments_nodeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.demorobot_flow_node_attachments
    ADD CONSTRAINT "demorobot_flow_node_attachments_nodeId_fkey" FOREIGN KEY ("nodeId") REFERENCES public.demorobot_flow_nodes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: demorobot_flow_nodes demorobot_flow_nodes_flowId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.demorobot_flow_nodes
    ADD CONSTRAINT "demorobot_flow_nodes_flowId_fkey" FOREIGN KEY ("flowId") REFERENCES public.demorobot_flows(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: demorobot_flows demorobot_flows_flowCategoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.demorobot_flows
    ADD CONSTRAINT "demorobot_flows_flowCategoryId_fkey" FOREIGN KEY ("flowCategoryId") REFERENCES public.flow_categories(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: demorobot_flows demorobot_flows_workspaceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.demorobot_flows
    ADD CONSTRAINT "demorobot_flows_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES public."Workspace"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: faqs faqs_workspaceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.faqs
    ADD CONSTRAINT "faqs_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES public."Workspace"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: flow_categories flow_categories_workspaceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.flow_categories
    ADD CONSTRAINT "flow_categories_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES public."Workspace"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: flow_node_configs flow_node_configs_workspaceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.flow_node_configs
    ADD CONSTRAINT "flow_node_configs_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES public."Workspace"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: gdpr_content gdpr_content_workspaceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gdpr_content
    ADD CONSTRAINT "gdpr_content_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES public."Workspace"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: google_calendar_connections google_calendar_connections_workspaceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.google_calendar_connections
    ADD CONSTRAINT "google_calendar_connections_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES public."Workspace"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: invoice_adjustments invoice_adjustments_invoiceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_adjustments
    ADD CONSTRAINT "invoice_adjustments_invoiceId_fkey" FOREIGN KEY ("invoiceId") REFERENCES public.monthly_invoices(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: invoice_adjustments invoice_adjustments_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_adjustments
    ADD CONSTRAINT "invoice_adjustments_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: invoice_credit_notes invoice_credit_notes_invoiceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_credit_notes
    ADD CONSTRAINT "invoice_credit_notes_invoiceId_fkey" FOREIGN KEY ("invoiceId") REFERENCES public.monthly_invoices(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: invoice_credit_notes invoice_credit_notes_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_credit_notes
    ADD CONSTRAINT "invoice_credit_notes_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: languages languages_workspaceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.languages
    ADD CONSTRAINT "languages_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES public."Workspace"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: late_cancellation_attempts late_cancellation_attempts_serviceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.late_cancellation_attempts
    ADD CONSTRAINT "late_cancellation_attempts_serviceId_fkey" FOREIGN KEY ("serviceId") REFERENCES public.services(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: late_cancellation_attempts late_cancellation_attempts_workspaceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.late_cancellation_attempts
    ADD CONSTRAINT "late_cancellation_attempts_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES public."Workspace"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: merchant_pushes merchant_pushes_merchantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.merchant_pushes
    ADD CONSTRAINT "merchant_pushes_merchantId_fkey" FOREIGN KEY ("merchantId") REFERENCES public.merchants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: merchant_pushes merchant_pushes_workspaceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.merchant_pushes
    ADD CONSTRAINT "merchant_pushes_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES public."Workspace"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: merchant_quota_topups merchant_quota_topups_merchantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.merchant_quota_topups
    ADD CONSTRAINT "merchant_quota_topups_merchantId_fkey" FOREIGN KEY ("merchantId") REFERENCES public.merchants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: merchant_quota_topups merchant_quota_topups_workspaceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.merchant_quota_topups
    ADD CONSTRAINT "merchant_quota_topups_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES public."Workspace"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: merchants merchants_workspaceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.merchants
    ADD CONSTRAINT "merchants_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES public."Workspace"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: message_attachments message_attachments_conversationMessageId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message_attachments
    ADD CONSTRAINT "message_attachments_conversationMessageId_fkey" FOREIGN KEY ("conversationMessageId") REFERENCES public.conversation_messages(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: messages messages_chatSessionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT "messages_chatSessionId_fkey" FOREIGN KEY ("chatSessionId") REFERENCES public.chat_sessions(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: monthly_invoices monthly_invoices_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.monthly_invoices
    ADD CONSTRAINT "monthly_invoices_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: offers offers_categoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.offers
    ADD CONSTRAINT "offers_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES public.categories(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: offers offers_workspaceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.offers
    ADD CONSTRAINT "offers_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES public."Workspace"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: order_items order_items_orderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT "order_items_orderId_fkey" FOREIGN KEY ("orderId") REFERENCES public.orders(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: order_items order_items_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT "order_items_productId_fkey" FOREIGN KEY ("productId") REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: order_items order_items_serviceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT "order_items_serviceId_fkey" FOREIGN KEY ("serviceId") REFERENCES public.services(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: orders orders_customerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT "orders_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES public.customers(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: orders orders_workspaceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT "orders_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES public."Workspace"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: password_resets password_resets_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.password_resets
    ADD CONSTRAINT "password_resets_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: payment_details payment_details_orderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_details
    ADD CONSTRAINT "payment_details_orderId_fkey" FOREIGN KEY ("orderId") REFERENCES public.orders(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: paypal_transactions paypal_transactions_adminUserId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.paypal_transactions
    ADD CONSTRAINT "paypal_transactions_adminUserId_fkey" FOREIGN KEY ("adminUserId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: paypal_transactions paypal_transactions_invoiceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.paypal_transactions
    ADD CONSTRAINT "paypal_transactions_invoiceId_fkey" FOREIGN KEY ("invoiceId") REFERENCES public.monthly_invoices(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: paypal_transactions paypal_transactions_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.paypal_transactions
    ADD CONSTRAINT "paypal_transactions_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: playground_comments playground_comments_todoId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.playground_comments
    ADD CONSTRAINT "playground_comments_todoId_fkey" FOREIGN KEY ("todoId") REFERENCES public.playground_todos(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: products products_workspaceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT "products_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES public."Workspace"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: push_campaign_recipients push_campaign_recipients_campaignId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.push_campaign_recipients
    ADD CONSTRAINT "push_campaign_recipients_campaignId_fkey" FOREIGN KEY ("campaignId") REFERENCES public.push_campaigns(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: push_campaign_recipients push_campaign_recipients_customerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.push_campaign_recipients
    ADD CONSTRAINT "push_campaign_recipients_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES public.customers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: push_campaign_recipients push_campaign_recipients_workspaceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.push_campaign_recipients
    ADD CONSTRAINT "push_campaign_recipients_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES public."Workspace"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: push_campaigns push_campaigns_createdByUserId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.push_campaigns
    ADD CONSTRAINT "push_campaigns_createdByUserId_fkey" FOREIGN KEY ("createdByUserId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: push_campaigns push_campaigns_merchantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.push_campaigns
    ADD CONSTRAINT "push_campaigns_merchantId_fkey" FOREIGN KEY ("merchantId") REFERENCES public.merchants(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: push_campaigns push_campaigns_merchantPushId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.push_campaigns
    ADD CONSTRAINT "push_campaigns_merchantPushId_fkey" FOREIGN KEY ("merchantPushId") REFERENCES public.merchant_pushes(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: push_campaigns push_campaigns_workspaceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.push_campaigns
    ADD CONSTRAINT "push_campaigns_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES public."Workspace"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: reminder_locks reminder_locks_workspaceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reminder_locks
    ADD CONSTRAINT "reminder_locks_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES public."Workspace"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: sales sales_workspaceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT "sales_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES public."Workspace"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: search_conversations search_conversations_workspaceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.search_conversations
    ADD CONSTRAINT "search_conversations_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES public."Workspace"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: secure_tokens secure_tokens_workspaceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.secure_tokens
    ADD CONSTRAINT "secure_tokens_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES public."Workspace"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: services services_workspaceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT "services_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES public."Workspace"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: soft_delete_audit_logs soft_delete_audit_logs_workspaceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.soft_delete_audit_logs
    ADD CONSTRAINT "soft_delete_audit_logs_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES public."Workspace"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: support_attachments support_attachments_messageId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.support_attachments
    ADD CONSTRAINT "support_attachments_messageId_fkey" FOREIGN KEY ("messageId") REFERENCES public.support_messages(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: support_messages support_messages_ticketId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.support_messages
    ADD CONSTRAINT "support_messages_ticketId_fkey" FOREIGN KEY ("ticketId") REFERENCES public.support_tickets(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: support_tickets support_tickets_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.support_tickets
    ADD CONSTRAINT "support_tickets_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: support_tickets support_tickets_workspaceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.support_tickets
    ADD CONSTRAINT "support_tickets_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES public."Workspace"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: tourist_apartments tourist_apartments_workspaceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tourist_apartments
    ADD CONSTRAINT "tourist_apartments_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES public."Workspace"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tourist_castles tourist_castles_workspaceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tourist_castles
    ADD CONSTRAINT "tourist_castles_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES public."Workspace"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tourist_churches tourist_churches_workspaceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tourist_churches
    ADD CONSTRAINT "tourist_churches_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES public."Workspace"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tourist_events tourist_events_workspaceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tourist_events
    ADD CONSTRAINT "tourist_events_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES public."Workspace"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tourist_excursions tourist_excursions_workspaceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tourist_excursions
    ADD CONSTRAINT "tourist_excursions_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES public."Workspace"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tourist_hotels tourist_hotels_workspaceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tourist_hotels
    ADD CONSTRAINT "tourist_hotels_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES public."Workspace"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tourist_photos tourist_photos_workspaceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tourist_photos
    ADD CONSTRAINT "tourist_photos_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES public."Workspace"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tourist_refuges tourist_refuges_workspaceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tourist_refuges
    ADD CONSTRAINT "tourist_refuges_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES public."Workspace"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tourist_restaurants tourist_restaurants_workspaceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tourist_restaurants
    ADD CONSTRAINT "tourist_restaurants_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES public."Workspace"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tourist_ski_facilities tourist_ski_facilities_workspaceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tourist_ski_facilities
    ADD CONSTRAINT "tourist_ski_facilities_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES public."Workspace"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tourist_sports_facilities tourist_sports_facilities_workspaceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tourist_sports_facilities
    ADD CONSTRAINT "tourist_sports_facilities_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES public."Workspace"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tourist_venues tourist_venues_workspaceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tourist_venues
    ADD CONSTRAINT "tourist_venues_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES public."Workspace"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tourist_viewpoints tourist_viewpoints_workspaceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tourist_viewpoints
    ADD CONSTRAINT "tourist_viewpoints_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES public."Workspace"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: two_factor_reset_tokens two_factor_reset_tokens_createdByAdminId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.two_factor_reset_tokens
    ADD CONSTRAINT "two_factor_reset_tokens_createdByAdminId_fkey" FOREIGN KEY ("createdByAdminId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: two_factor_reset_tokens two_factor_reset_tokens_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.two_factor_reset_tokens
    ADD CONSTRAINT "two_factor_reset_tokens_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: usage usage_clientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usage
    ADD CONSTRAINT "usage_clientId_fkey" FOREIGN KEY ("clientId") REFERENCES public.customers(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: usage usage_workspaceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usage
    ADD CONSTRAINT "usage_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES public."Workspace"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: whatsapp_queue whatsapp_queue_conversationMessageId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.whatsapp_queue
    ADD CONSTRAINT "whatsapp_queue_conversationMessageId_fkey" FOREIGN KEY ("conversationMessageId") REFERENCES public.conversation_messages(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: whatsapp_queue whatsapp_queue_customerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.whatsapp_queue
    ADD CONSTRAINT "whatsapp_queue_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES public.customers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: whatsapp_queue whatsapp_queue_pushCampaignId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.whatsapp_queue
    ADD CONSTRAINT "whatsapp_queue_pushCampaignId_fkey" FOREIGN KEY ("pushCampaignId") REFERENCES public.push_campaigns(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: whatsapp_queue whatsapp_queue_pushCampaignRecipientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.whatsapp_queue
    ADD CONSTRAINT "whatsapp_queue_pushCampaignRecipientId_fkey" FOREIGN KEY ("pushCampaignRecipientId") REFERENCES public.push_campaign_recipients(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: whatsapp_queue whatsapp_queue_workspaceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.whatsapp_queue
    ADD CONSTRAINT "whatsapp_queue_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES public."Workspace"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: whatsapp_settings whatsapp_settings_workspaceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.whatsapp_settings
    ADD CONSTRAINT "whatsapp_settings_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES public."Workspace"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: whatsapp_webhook_events whatsapp_webhook_events_workspaceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.whatsapp_webhook_events
    ADD CONSTRAINT "whatsapp_webhook_events_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES public."Workspace"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: workspace_business_hours workspace_business_hours_workspaceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_business_hours
    ADD CONSTRAINT "workspace_business_hours_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES public."Workspace"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: workspace_calling_functions workspace_calling_functions_workspaceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_calling_functions
    ADD CONSTRAINT "workspace_calling_functions_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES public."Workspace"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: workspace_environment_variables workspace_environment_variables_workspaceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_environment_variables
    ADD CONSTRAINT "workspace_environment_variables_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES public."Workspace"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: workspace_invitations workspace_invitations_invitedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_invitations
    ADD CONSTRAINT "workspace_invitations_invitedById_fkey" FOREIGN KEY ("invitedById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: workspace_invitations workspace_invitations_workspaceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workspace_invitations
    ADD CONSTRAINT "workspace_invitations_workspaceId_fkey" FOREIGN KEY ("workspaceId") REFERENCES public."Workspace"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict 8TF43pPyANHAPOQiP0Kj2eR7EU8stHHT8pzI3fgYZUdOBtTjNfdrkPmHiwJU0D2

